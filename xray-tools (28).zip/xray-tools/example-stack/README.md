# example-stack - a .NET web app, a database and a Python worker, connected

A working example for `SERVICES_GUIDE.md` (in the tools folder): read it for the why of every line.

```bat
copy .env.example .env
notepad .env
docker compose -f compose.postgres.yml up -d --build
```
Open http://localhost:8080/db - the web app shows how many rows the worker has written. MySQL instead:
`compose.mysql.yml` (put DB_ROOT_PASSWORD in .env too). Stop: `docker compose -f compose.postgres.yml down`
(the data stays; `down -v` deletes it).

| Folder / file | What |
|---|---|
| `web/` | a tiny ASP.NET Core 8 app: `Dockerfile` (from source), `Dockerfile.published` (from a published folder), `.dockerignore` |
| `worker/` | a tiny Python program that writes a row every 2 s, + its Dockerfile |
| `db/postgres-init/`, `db/mysql-init/` | SQL run on the database's first start |
| `compose.postgres.yml`, `compose.mysql.yml` | the whole system |
| `.env.example` | passwords and per-machine values - copy to `.env`, never commit `.env` |
