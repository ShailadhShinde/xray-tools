-- Runs ONCE: when the database container starts with an EMPTY data volume (the first start).
-- Every *.sql / *.sql.gz / *.sh file in this folder runs, in name order, in the database MYSQL_DATABASE names.
CREATE TABLE IF NOT EXISTS detections (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    label      VARCHAR(100) NOT NULL,
    score      FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
