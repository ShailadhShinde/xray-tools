-- Runs ONCE: when the database container starts with an EMPTY data volume (the first start).
-- Every *.sql / *.sql.gz / *.sh file in this folder runs, in name order (01-..., 02-...).
-- To load your existing database instead: put its dump here (02-data.sql), or restore it later (see the guide).
CREATE TABLE IF NOT EXISTS detections (
    id         SERIAL PRIMARY KEY,
    label      TEXT NOT NULL,
    score      REAL,
    created_at TIMESTAMPTZ DEFAULT now()
);
