// A tiny web app that stands in for your dashboard: it reads the same database the worker writes to.
//   /     -> "web is up"
//   /db   -> how many rows the worker has written, read through the connection string
// The connection string comes from appsettings.json ("ConnectionStrings": {"Default": ...}); in Docker the
// env var ConnectionStrings__Default replaces it (env vars win over appsettings.json).
using System.Data.Common;
using MySqlConnector;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "web is up");

app.MapGet("/db", async (IConfiguration cfg) =>
{
    var kind = cfg["Database:Kind"] ?? "postgres";                 // postgres or mysql
    var cs = cfg.GetConnectionString("Default");
    await using DbConnection con = kind == "mysql" ? new MySqlConnection(cs) : new NpgsqlConnection(cs);
    await con.OpenAsync();
    await using var cmd = con.CreateCommand();
    cmd.CommandText = "SELECT COUNT(*) FROM detections";
    var rows = Convert.ToInt64(await cmd.ExecuteScalarAsync());
    return Results.Ok(new { database = kind, server = con.DataSource, detections = rows });
});

app.Run();
