"""A tiny worker that stands in for your ML program: it writes one row into the database every 2 seconds.
Where the database is comes from env vars (compose sets them), so the same code runs on your PC and in Docker:
    DB_KIND      postgres or mysql
    DB_HOST      in compose: the database's SERVICE NAME (db); on your PC: localhost
    DB_PORT      5432 (Postgres) / 3306 (MySQL) - the port INSIDE the network, not the one published on the PC
    DB_NAME, DB_USER, DB_PASSWORD
"""
import os
import time

KIND = os.getenv("DB_KIND", "postgres")
CFG = dict(host=os.getenv("DB_HOST", "localhost"), port=int(os.getenv("DB_PORT", "5432" if KIND == "postgres" else "3306")),
           user=os.getenv("DB_USER", "app"), password=os.getenv("DB_PASSWORD", ""))
NAME = os.getenv("DB_NAME", "app")


def connect():
    if KIND == "mysql":
        import pymysql
        return pymysql.connect(database=NAME, autocommit=True, **CFG)
    import psycopg2
    con = psycopg2.connect(dbname=NAME, **CFG)
    con.autocommit = True
    return con


def main():
    for attempt in range(30):                  # the database may still be starting: try again for a minute
        try:
            con = connect()
            break
        except Exception as e:
            print(f"database not reachable yet ({e.__class__.__name__}): retry in 2 s", flush=True)
            time.sleep(2)
    else:
        raise SystemExit("no database after 60 s - check DB_HOST / DB_PORT / the password")
    print(f"connected to {KIND} at {CFG['host']}:{CFG['port']}/{NAME}", flush=True)
    n = 0
    while True:
        with con.cursor() as cur:
            cur.execute("INSERT INTO detections (label, score) VALUES (%s, %s)", ("car", 0.9))
        n += 1
        if n % 10 == 1:
            print(f"wrote {n} rows", flush=True)
        time.sleep(2)


if __name__ == "__main__":
    main()
