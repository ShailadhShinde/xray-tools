#!/usr/bin/env python3
"""
xray_naive.py - check a requirements file for Linux BEFORE building, and write a naive Dockerfile that builds.

For every line of the requirements file it asks pip (dry run: nothing is installed, only the package index is read)
whether a ready-made Linux package (a "wheel") exists for the Python version of the image:
  OK          a prebuilt Linux wheel exists                       -> nothing to do
  COMPILED    only the source exists: pip compiles it in the build -> gcc + Python headers (+ a -dev library)
  MISSING     no file at all for Linux / this Python               -> change the pin (versions that do exist are listed)
  WINDOWS     a Windows-only package (pyreadline3, pywin32 ...)    -> left out of the Linux requirements
  INDEX       torch==2.8.0+cu126 style pins                        -> PyTorch's index is added
  SOURCE      only the source exists, but it is pure Python        -> builds without a compiler

and WHAT KIND each package is (from the file pip picks): pure wheel / binary wheel / HEAVY binary wheel (>100 MB) /
sdist (source: it downloads the source and looks for C / C++ / Cython / Rust files = compiler needed), the download
size, and for GPU packages where their CUDA libraries come from (own nvidia-* pip packages, or the system / base
image) - which decides python-slim vs an nvidia/cuda base.

Then it writes into runs/NAME/naive/:
  naive-check.txt              the table above, with the reason for every line, + the KIND and GPU tables
  naive-check.json             the same as data
  requirements.docker.txt      the requirements as the build installs them (Windows-only out, PyTorch index in,
                               each handled line with a comment)
  Dockerfile.naive             sections (base, apt libraries, frameworks, other packages + a compiler only where
                               needed, the CUDA wheels' library folders, code), each line with its reason - decided
                               from the tables
  Dockerfile.naive.dockerignore

The whole file is also checked TOGETHER, the way the build installs it (one pip install). A pip freeze comes from a PC
where packages were installed in several steps, so it can hold lines pip refuses to install together (torch +cu126 and
newer nvidia-* pins, a torchaudio of another torch). Those lines are installed in section 3c, AFTER the others, exactly
as pinned, with --no-deps - the way that PC got them; nothing is left out, no pin is changed. What they need that is not
in the file is added right after, without changing any version installed before (-c).

With --static (the Step 1 map), section 6 handles the files the code reads from your PC (a model on the Desktop):
copied into the image (up to 500 MB, or --copy ENV_NAME) or mounted at run time (--mount ENV_NAME), with the env var
set to the path inside the container. naive-check.txt then lists every env var (value in your code -> value in the
container), the code changes needed (a Windows path written without an env var), and the build and run commands.
Copy the three Docker files into the project folder (the tool never overwrites the project's own files).

  python xray_naive.py --project "C:\\...\\Solution" --requirements requirement.txt --entry main.py --name worker
       [--python 3.12] [--gpu | --cpu] [--static runs\\worker\\worker.json] [--copy ENV_NAME | --mount ENV_NAME]

Needs internet access to the package index (pip reads it). Standard library only.
"""
import argparse
import concurrent.futures
import json
import os
import re
import subprocess
import sys
import tempfile

VERSION = "0.4.7"
HERE = os.path.dirname(os.path.abspath(__file__))

# Linux platform tags of the CPU the image runs on (pip matches the listed tags exactly; pure-Python "any" wheels
# always match). x86_64 = Intel / AMD PCs and servers; aarch64 = ARM: Jetson, Raspberry Pi, ARM cloud servers


def platforms(arch):
    return ([f"linux_{arch}"] + ([f"manylinux1_{arch}", f"manylinux2010_{arch}"] if arch == "x86_64" else []) +
            [f"manylinux2014_{arch}"] + [f"manylinux_2_{n}_{arch}" for n in range(5, 40)])


ARCH = {"name": "x86_64"}
PLATFORMS = platforms("x86_64")
PY_KNOWN = ["3.8", "3.9", "3.10", "3.11", "3.12", "3.13"]     # the Pythons a pin is also checked for when it fails
WINDOWS_ONLY = {"pywin32", "pypiwin32", "pywinpty", "pyreadline3", "pyreadline", "wmi", "comtypes",
                "windows-curses", "pywinauto", "winshell", "pywin32-ctypes", "win10toast", "pythonnet-win"}
# big C/Fortran packages: if only their source exists for this Python, compiling usually fails (or takes an hour)
HEAVY = {"numpy", "scipy", "pandas", "scikit-learn", "scikit-image", "matplotlib", "torch", "torchvision",
         "torchaudio", "tensorflow", "opencv-python", "opencv-contrib-python", "opencv-python-headless",
         "onnxruntime", "onnxruntime-gpu", "numba", "llvmlite", "pyarrow", "h5py", "shapely", "grpcio", "tokenizers"}
NET_ERR = r"ProxyError|NewConnectionError|Max retries|403 Forbidden|SSLError|Read timed out|ConnectionError|" \
          r"Temporary failure in name resolution|Could not fetch URL"
# compiled packages that also need a system library (Debian / Ubuntu package names)
DEV_LIBS = {
    "psycopg2": ("libpq-dev", "or use psycopg2-binary (prebuilt, no compiler)"),
    "mysqlclient": ("default-libmysqlclient-dev pkg-config", ""),
    "pycairo": ("libcairo2-dev pkg-config", ""),
    "pygobject": ("libgirepository1.0-dev libcairo2-dev pkg-config", ""),
    "python-ldap": ("libldap2-dev libsasl2-dev", ""),
    "pyaudio": ("portaudio19-dev", ""),
    "dlib": ("cmake", "takes a long time to compile"),
    "h5py": ("libhdf5-dev pkg-config", ""),
    "lxml": ("libxml2-dev libxslt1-dev", ""),
    "pillow": ("libjpeg-dev zlib1g-dev", ""),
    "gssapi": ("libkrb5-dev", ""),
    "pykerberos": ("libkrb5-dev", ""),
    "pyodbc": ("unixodbc-dev", ""),
    "pycurl": ("libcurl4-openssl-dev libssl-dev", ""),
    "python-snappy": ("libsnappy-dev", ""),
    "cryptography": ("libssl-dev libffi-dev cargo", "an old version: newer ones have wheels"),
    "cffi": ("libffi-dev", ""),
}


def canon(n):
    return re.sub(r"[-_.]+", "-", str(n)).lower()


def parse_requirements(path):
    """[(line_no, raw, name, spec)] + index options (-i / --extra-index-url / -f) + notes"""
    reqs, opts, notes = [], [], []
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        lines = fh.read().splitlines()
    for no, raw in enumerate(lines, 1):
        line = raw.split(" #", 1)[0].strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("-"):
            m = re.match(r"^(--extra-index-url|--index-url|-i|--find-links|-f)[ =](\S+)", line)
            if m:
                opts.append(("--extra-index-url" if m.group(1) in ("--extra-index-url",) else
                             "--index-url" if m.group(1) in ("--index-url", "-i") else "--find-links", m.group(2)))
            else:
                notes.append(f"line {no}: '{line}' - not checked (pip option / other file)")
            continue
        if "@" in line and ("file:" in line or "://" in line):
            reqs.append((no, line, canon(line.split("@")[0].strip()), "LOCAL"))
            continue
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*(.*)$", line)
        if not m:
            notes.append(f"line {no}: '{line}' - not understood, not checked")
            continue
        reqs.append((no, line, canon(m.group(1)), m.group(3).strip()))
    return reqs, opts, notes


REPORT = {"ok": True}       # pip older than 22.2 has no --report: then the KIND table is left out


def pip_version():
    """(major, minor) of the pip that does the checks, or None"""
    try:
        out = subprocess.run([sys.executable, "-m", "pip", "--version"], capture_output=True, text=True,
                             timeout=60).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.match(r"pip (\d+)\.(\d+)", out or "")
    return (int(m.group(1)), int(m.group(2))) if m else None


def pip_dry(req, py, only_binary, opts, cu_index, want=None):
    """run pip install --dry-run for one requirement on Linux / py: (ok, text); the file pip picked + its metadata
    go into want["pick"] when a dict is given"""
    with tempfile.TemporaryDirectory() as tmp:
        cmd = [sys.executable, "-m", "pip", "install", "--dry-run", "--quiet", "--no-deps", "--ignore-installed",
               "--disable-pip-version-check", "--no-input", "--target", os.path.join(tmp, "t"),
               "--python-version", py, "--implementation", "cp", "--abi", "cp" + py.replace(".", ""),
               "--abi", "abi3", "--abi", "none"]
        for p in PLATFORMS:
            cmd += ["--platform", p]
        if only_binary:
            cmd += ["--only-binary=:all:"]
        for k, v in opts:
            cmd += [k, v]
        if cu_index:
            cmd += ["--extra-index-url", cu_index]
        rep = os.path.join(tmp, "report.json")
        if want is not None and REPORT["ok"]:
            cmd += ["--report", rep]
        cmd += req if isinstance(req, list) else [req]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        except subprocess.TimeoutExpired:
            return None, "pip timed out"
        out = (r.stdout + r.stderr).strip()
        if r.returncode != 0 and "no such option: --report" in out:
            REPORT["ok"] = False
            return pip_dry(req, py, only_binary, opts, cu_index, want)
        if r.returncode == 0:
            try:
                with open(rep, encoding="utf-8") as fh:
                    want["all"] = json.load(fh)["install"]
                    want["pick"] = want["all"][0]
            except (OSError, ValueError, KeyError, IndexError, TypeError):
                pass
            return True, out
        if re.search(NET_ERR, out):     # an index could not be read: "not found" would be a guess
            bad = re.findall(r"(https?://[^\s'\"]+|/whl/\S+)", out)
            return None, "could not read the package index" + (f" ({bad[0]})" if bad else "")
        return False, out


def resolve_together(results, py, opts, got=None):
    """install the whole file at once (dry run, WITH dependencies), like the build does: two lines that cannot be
    installed together (torch pins its own nvidia-* versions, torchaudio must match torch ...) only show up here.
    -> (ok True / False / None = not checked, pip's explanation lines); got["names"] = every package it installs"""
    reqs = [r["raw"].split(" #")[0].strip() for r in results          # every line the build installs first
            if r["status"] in ("OK", "UNCHECKED") and not r.get("later")]
    if len(reqs) < 2 and got is None:
        return True, []
    idx = sorted({r["index"] for r in results if r.get("index")})
    with tempfile.TemporaryDirectory() as tmp:
        cmd = [sys.executable, "-m", "pip", "install", "--dry-run", "--ignore-installed",
               "--disable-pip-version-check", "--no-input", "--target", os.path.join(tmp, "t"),
               "--python-version", py, "--implementation", "cp", "--abi", "cp" + py.replace(".", ""),
               "--abi", "abi3", "--abi", "none", "--only-binary=:all:"]
        for p in PLATFORMS:
            cmd += ["--platform", p]
        for k, v in opts:
            cmd += [k, v]
        for u in idx:
            if ("--extra-index-url", u) not in opts:
                cmd += ["--extra-index-url", u]
        rep = os.path.join(tmp, "report.json")
        if got is not None and REPORT["ok"]:
            cmd += ["--report", rep]
        try:
            r = subprocess.run(cmd + reqs, capture_output=True, text=True, timeout=900)
        except subprocess.TimeoutExpired:
            return None, ["pip timed out"]
        if r.returncode == 0 and got is not None:
            try:
                with open(rep, encoding="utf-8") as fh:
                    got["names"] = {canon(i["metadata"]["name"]) for i in json.load(fh)["install"]}
            except (OSError, ValueError, KeyError, TypeError):
                pass
    if r.returncode == 0:
        return True, []
    out = (r.stdout + r.stderr).strip()
    if re.search(NET_ERR, out) and "conflict" not in out.lower():
        return None, ["the package index could not be read"]
    keep = [ln.rstrip() for ln in out.splitlines()
            if re.search(r"Cannot install|conflict is caused by|depends on|requested|No matching distribution|"
                         r"ResolutionImpossible|Could not find a version", ln)]
    return False, keep[:30] or out.splitlines()[-15:]


SKIP = ("WINDOWS", "LOCAL", "MISSING", "DROPPED")


def pin_of(raw):
    m = re.search(r"==\s*([\w.+*]+)", raw or "")
    return m.group(1) if m else None


def set_req(r, raw, why, py, opts, index=None):
    """replace one requirement line by a fixed one and check it again"""
    old = r["raw"]
    m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*(.*)$", raw)
    new = check_one((r["line"], raw, r["name"], m.group(3).strip() if m else ""), py, opts, index)
    if index and not new.get("index"):
        new["index"] = index
    wp = r.get("wheel_pythons")
    r.clear()
    r.update(new)
    r["fixed"] = f"was {old}: {why}"
    if wp is not None:              # what the ORIGINAL pin has wheels for (other_pythons) stays in the report
        r["wheel_pythons"], r["orig_raw"] = wp, old


def autofix(results, py, opts):
    """lines that cannot be built as they are, and have only one way to work: fixed, and listed in the report"""
    fixes = []
    # a package listed twice: pip cannot install two versions - keep the line that installs (the newer one if both)
    by = {}
    for r in results:
        by.setdefault(r["name"], []).append(r)
    for name, rs in by.items():
        if len(rs) > 1:
            good = [r for r in rs if r["status"] not in SKIP] or rs
            keep = max(good, key=lambda r: vkey(pin_of(r["raw"]) or "0"))
            for r in rs:
                if r is not keep:
                    r.update(status="DROPPED", why=f"{name} is listed twice, line {keep['line']} ({keep['raw']}) is kept")
                    fixes.append(f"line {r['line']}: {r['raw']}  LEFT OUT - {r['why']}")
    for r in results:
        pin = pin_of(r["raw"])
        # a pin that has no file for Linux / this Python at all: the nearest version that has one
        if r["status"] == "MISSING" and r.get("alts") and pin and "*" not in pin:
            above = [v for v in r["alts"] if vkey(v) >= vkey(pin)]
            v = above[0] if above else r["alts"][-1]
            old, raw = r["raw"], re.sub(r"==\s*[\w.+*]+", "==" + v, r["raw"].split(" #")[0].strip(), count=1)
            set_req(r, raw, f"no file for Linux / Python {py}", py, opts)
            fixes.append(f"line {r['line']}: {old} -> {raw} (that version has no file for Linux / Python {py}; "
                         "the nearest version that has one)")
        # a path on the PC the file was made on (pip freeze of a conda / local install): install it by name
        elif r["status"] == "LOCAL":
            old, name = r["raw"], r["raw"].split("@")[0].strip()
            set_req(r, name, "a path on the PC the file comes from", py, opts)
            fixes.append(f"line {r['line']}: {old} -> {name} (a path on the PC the file was made on; installed by "
                         "name, newest version)")
    return fixes


def resolve_and_split(results, py, opts, fixes, got=None):
    """install the whole file together, like the build does. When pip refuses because one line pins a version that
    another line (or its dependency) does not accept - typical for a pip freeze from a PC where packages were
    installed in several steps, e.g. torch first and newer nvidia-* versions later - the line with FEWER dependencies
    moves to a second pip step with --no-deps: installed exactly as the file pins it, after the others, the same way
    that PC got it. Nothing is left out and no pin is changed."""
    for _ in range(15):
        ok, why = resolve_together(results, py, opts, got)
        if ok is not False:
            return ok, why
        text = "\n".join(why)
        req = {canon(n) for n in re.findall(r"The user requested ([A-Za-z0-9._-]+)", text)}
        live = {r["name"]: r for r in results if r["status"] in ("OK", "UNCHECKED") and not r.get("later")}
        moved = False
        for line in why:
            m = re.match(r"\s*([A-Za-z0-9._-]+) ([\w.+!-]+) depends on ([A-Za-z0-9._-]+)(.*)$", line.strip())
            if not m:
                continue
            dep, x = canon(m.group(1)), canon(m.group(3))
            if x not in req or x not in live:
                continue
            r = live[x]
            if dep in live and live[dep].get("ndeps") is not None and r.get("ndeps") is not None and \
                    live[dep]["ndeps"] < r["ndeps"]:
                r = live[dep]            # e.g. torchvision (3 dependencies) instead of torch (15)
            if r.get("later"):
                continue
            r["later"] = line.strip()
            fixes.append(f"line {r['line']}: {r['raw']}  INSTALLED IN A SECOND STEP, exactly this version - pip says: "
                         f"{line.strip()}")
            moved = True
        if not moved:
            return ok, why
    return resolve_together(results, py, opts, got)


def dep_applies(dep, py, extras=()):
    """does one Requires-Dist line apply on Linux x86_64 / Python py (with these extras asked for)?"""
    if ";" not in dep:
        return True
    marker = dep.split(";", 1)[1].strip()
    try:
        from pip._vendor.packaging.markers import Marker     # pip's own copy of 'packaging': pip is needed anyway
        m = Marker(marker)
    except Exception:
        return "extra" not in marker
    env = {"python_version": py, "python_full_version": py + ".0", "implementation_version": py + ".0",
           "sys_platform": "linux", "platform_system": "Linux", "platform_machine": ARCH["name"], "os_name": "posix",
           "implementation_name": "cpython", "platform_python_implementation": "CPython"}
    try:
        return any(m.evaluate(dict(env, extra=e)) for e in [""] + list(extras))
    except Exception:
        return "extra" not in marker


def later_needs(results, py, step1):
    """what the second-step lines need that nothing else installs (--no-deps skips it): {name: entry}.
    step1 = every package the first pip steps install (pip's report), or an empty set when unknown"""
    infile = {r["name"] for r in results}
    need = {}
    for r in results:
        if not r.get("later"):
            continue
        m = re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]*\[([^\]]*)\]", r["raw"])
        extras = [canon(x) for x in m.group(1).split(",")] if m else []
        for dep in r.get("requires") or []:
            if not dep_applies(dep, py, extras):
                continue
            mm = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)\s*(\[[^\]]*\])?\s*\(?([^);]*)\)?", dep.split(";")[0].strip())
            if not mm:
                continue
            n = canon(mm.group(1))
            if n in infile or n in step1:
                continue
            e = need.setdefault(n, {"name": mm.group(1), "extras": "", "specs": [], "who": []})
            e["extras"] = e["extras"] or (mm.group(2) or "")
            for sp in mm.group(3).replace(" ", "").split(","):
                if sp and sp not in e["specs"]:
                    e["specs"].append(sp)
            if r["name"] not in e["who"]:
                e["who"].append(r["name"])
    for e in need.values():
        e["req"] = e["name"] + e["extras"] + ",".join(e["specs"])
    return need


# pip found a source file but running its setup on this PC failed / pip found no file at all
PREP_FAILED = re.compile(r"metadata-generation-failed|subprocess-exited-with-error|Getting requirements to build|"
                         r"Preparing metadata|egg_info")
NO_MATCH = re.compile(r"No matching distribution found|Could not find a version that satisfies")


def prep_error(out):
    """the package's own error line from a failed metadata step ('Error: pg_config executable not found.')"""
    for line in (out or "").splitlines():
        m = re.match(r"\s*(?:[A-Za-z]*Error|ERROR):\s*(.+)", line)
        if m and not re.search(r"metadata-generation-failed|subprocess-exited-with-error|Command errored",
                               m.group(1)):
            return line.strip()[:160]
    return ""


def project_python(project):
    """the Python version the project itself names -> ('3.10', where it was found) or (None, None). A virtual
    environment inside the project comes first: it is what the code really runs on (PyCharm makes venv/ or .venv/)"""
    def rd(*parts):
        try:
            with open(os.path.join(project, *parts), encoding="utf-8", errors="replace") as fh:
                return fh.read()
        except OSError:
            return ""
    for d in ("venv", ".venv", "env", ".env", "virtualenv"):
        m = re.search(r"^\s*version(?:_info)?\s*=\s*(\d+)\.(\d+)", rd(d, "pyvenv.cfg"), re.M)
        if m:
            return f"{m.group(1)}.{m.group(2)}", f"{d}/pyvenv.cfg (the virtual environment in the project)"
    checks = [(".python-version", r"^\s*(?:python-|cpython-)?(\d+)\.(\d+)", ".python-version (pyenv)"),
              ("runtime.txt", r"^\s*python-(\d+)\.(\d+)", "runtime.txt"),
              ("Pipfile", r"python_(?:full_)?version\s*=\s*[\"'](\d+)\.(\d+)", "Pipfile"),
              ("environment.yml", r"^\s*-\s*python\s*[=<>~]*\s*(\d+)\.(\d+)", "environment.yml (conda)"),
              ("environment.yaml", r"^\s*-\s*python\s*[=<>~]*\s*(\d+)\.(\d+)", "environment.yaml (conda)"),
              ("Dockerfile", r"^\s*FROM\s+(?:\S+/)?python:(\d+)\.(\d+)", "the project's Dockerfile (FROM python:X.Y)")]
    for f, rx, where in checks:
        m = re.search(rx, rd(f), re.M | re.I)
        if m:
            return f"{m.group(1)}.{m.group(2)}", where
    for f, rx in (("pyproject.toml", r"requires-python\s*=\s*[\"']([^\"']+)"),
                  ("setup.py", r"python_requires\s*=\s*[\"']([^\"']+)"),
                  ("setup.cfg", r"python_requires\s*=\s*(\S+)")):
        m = re.search(rx, rd(f))
        if m:
            try:
                from pip._vendor.packaging.specifiers import SpecifierSet
                ok = [v for v in PY_KNOWN if SpecifierSet(m.group(1)).contains(v + ".0")]
            except Exception:       # pip's packaging missing or an odd spec: not evidence
                ok = []
            if ok:
                return ok[-1], f"{f} ({m.group(1).strip()}: the newest Python it allows)"
    return None, None


def other_pythons(results, py, opts, jobs=8):
    """the pins that have no Linux wheel for py: which other Python versions DO have a Linux wheel for that exact
    line (-> r['wheel_pythons'])"""
    bad = [r for r in results if r["status"] in ("MISSING", "COMPILED")]
    todo = [(r, v) for r in bad for v in PY_KNOWN if v != py]
    if not todo:
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, jobs)) as ex:
        oks = list(ex.map(lambda rv: pip_dry(rv[0]["raw"].split(";")[0].strip(), rv[1], True, opts,
                                             rv[0].get("index"))[0], todo))
    for r in bad:
        r["wheel_pythons"] = []
    for (r, v), ok in zip(todo, oks):
        if ok:
            r["wheel_pythons"].append(v)


def python_lines(results, py):
    """report lines: for each pin without a Linux wheel for py, the Pythons that have one; a Python that covers all"""
    bad = [r for r in results if "wheel_pythons" in r]
    if not bad:
        return []
    T = [f"OTHER PYTHON VERSIONS - the lines above with no Linux wheel for Python {py}, checked for "
         f"{', '.join(v for v in PY_KNOWN if v != py)}:"]
    for r in bad:
        T.append(f"  line {r['line']}: {r.get('orig_raw') or r['raw']:<34} " + (("Linux wheels for Python " +
                                                                            ", ".join(r["wheel_pythons"]) +
                                                                            (f" (the build uses {r['raw']})"
                                                                             if r.get("orig_raw") else ""))
                                                          if r["wheel_pythons"] else
                                                          "no Linux wheel for any of them (source only: compiled in "
                                                          "the build, or change the pin)"))
    some = [r for r in bad if r["wheel_pythons"]]
    common = [v for v in PY_KNOWN if v != py and some and all(v in r["wheel_pythons"] for r in some)]
    if common:
        T.append(f"  -> Python {common[-1]} has a Linux wheel for every line above that has one anywhere. It is a "
                 f"choice, not a fix: the "
                 f"project must run on {common[-1]} (its venv on your PC), and every other line must have one too - "
                 f"run again with --python {common[-1]} to check them all.")
    T.append("")
    return T


def available_versions(name, py, opts, cu_index):
    """the versions that DO have a Linux wheel for this Python (pip lists them when asked for an impossible one)"""
    ok, out = pip_dry(f"{name}==0.0.0.dev0", py, True, opts, cu_index)
    m = re.search(r"\(from versions: ([^)]*)\)", out or "")
    if not m or m.group(1).strip() == "none":
        return []
    return [v.strip() for v in m.group(1).split(",")]


def vkey(v):
    """'2.0.2' -> (2, 0, 2) for sorting (pre-releases sort before the release)"""
    parts = []
    for x in re.split(r"[.+]", v):
        m = re.match(r"(\d+)(.*)", x)
        parts.append((int(m.group(1)), 0 if m.group(2) else 1) if m else (0, 0))
    return parts


def nearest(vs, spec):
    """the versions closest above the pinned one (and the newest)"""
    m = re.search(r"==\s*([\w.+]+)", spec or "")
    final = [v for v in vs if not re.search(r"(a|b|rc|dev)\d*$", v)] or vs
    if not m:
        return final[-4:]
    pin = vkey(m.group(1))
    above = [v for v in sorted(final, key=vkey) if vkey(v) >= pin]
    pick = above[:3] + ([final[-1]] if final and final[-1] not in above[:3] else [])
    return pick or final[-4:]


HEAVY_MB = 100     # a wheel bigger than this (download size) is listed as HEAVY
# source files in an sdist that need a build tool, and which one
SRC_LANG = [(r"\.pyx$|\.pxd$", "Cython -> C"), (r"\.(c|h)$", "C"), (r"\.(cpp|cc|cxx|hpp|hh)$", "C++"),
            (r"(^|/)Cargo\.toml$", "Rust (needs cargo)"), (r"\.(f|f90|f95|for)$", "Fortran (needs gfortran)"),
            (r"(^|/)CMakeLists\.txt$", "CMake"), (r"\.(cu|cuh)$", "CUDA (needs nvcc)")]
# GPU packages that load CUDA / cuDNN BY NAME from outside their own wheel (the base image, or NVIDIA's pip wheels the
# loader must find). Most are also recognized from their metadata (extras that install CUDA wheels); this list covers
# the ones whose metadata does not say it.
SYSTEM_CUDA = {"onnxruntime-gpu", "cupy-cuda11x", "cupy-cuda12x", "cupy-cuda13x", "tensorrt", "paddlepaddle-gpu",
               "faiss-gpu"}
# NVIDIA's CUDA libraries as pip wheels: nvidia-cublas-cu12, nvidia-cuda-runtime (CUDA 13 names have no -cuNN), and the
# cuda-toolkit meta package; nvidia-ml-py is the NVML Python binding, not a CUDA library
CUDA_WHEEL = re.compile(r"^(nvidia-(?!ml-py)|cuda-toolkit$)")
# after the install: every folder NVIDIA's wheels put libraries in, registered with the Linux loader (any layout)
CUDA_REGISTER = ("RUN python3 -c \"import pathlib, site; print('\\n'.join(sorted({str(f.parent) for s in "
                 "site.getsitepackages() for f in pathlib.Path(s, 'nvidia').rglob('*.so*')})))\" \\\n"
                 "    > /etc/ld.so.conf.d/cuda-wheels.conf && ldconfig")


def cuda_major_of(reqs):
    """The CUDA major version NVIDIA's wheels in these requirement lines are built for: the -cu12 / -cu13 in a name,
    or the version of the wheels that follow CUDA's own numbering (nvidia-cuda-runtime~=13.0, cuda-toolkit==13.0.3).
    Others (nvidia-cufft 12.x, nvidia-curand 10.x) carry their library's own version - not CUDA's."""
    best = None
    for r in reqs:
        name = canon(re.split(r"[ ;<>=~!\[(]", r)[0])
        m = re.search(r"-cu(1\d)$", name)
        v = int(m.group(1)) if m else None
        if v is None and re.match(r"^(nvidia-cuda-runtime|nvidia-cuda-nvrtc|nvidia-nvjitlink|cuda-toolkit)$", name):
            m = re.search(r"(?:==|~=|>=)\s*(\d+)", r)
            v = int(m.group(1)) if m else None
        if v and (best is None or v > best):
            best = v
    return best


def url_size(url):
    """download size in bytes (HTTP HEAD), or None"""
    try:
        import urllib.request
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "xray-naive"})
        with urllib.request.urlopen(req, timeout=20) as r:
            n = r.headers.get("Content-Length")
            return int(n) if n else None
    except Exception:
        return None


def sdist_sources(url, size):
    """which compiled languages an sdist contains: [] = pure Python, None = could not look"""
    if not url or (size or 0) > 60 * 1024 * 1024:
        return None
    try:
        import io
        import tarfile
        import urllib.request
        import zipfile
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "xray-naive"}),
                                    timeout=60) as r:
            data = r.read()
        if url.split("#")[0].endswith(".zip"):
            names = zipfile.ZipFile(io.BytesIO(data)).namelist()
        else:
            names = tarfile.open(fileobj=io.BytesIO(data)).getnames()
    except Exception:
        return None
    names = [n for n in names if not re.search(r"(^|/)(tests?|docs?|examples?|benchmarks?)/", n)]
    return sorted({lang for pat, lang in SRC_LANG for n in names if re.search(pat, n, re.I)})


def wheel_files(url, size=None):
    """{path: (crc32, size)} of the files in a wheel, read from the zip's table of contents (at the END of the file)
    with HTTP Range requests - some KB, not the whole wheel (a wheel under 1 MB is read whole). None when the index
    does not allow it."""
    import struct
    import urllib.request
    small = 1024 * 1024

    def get(rng):
        req = urllib.request.Request(url, headers={"Range": rng, "User-Agent": "xray-naive"} if rng else
                                     {"User-Agent": "xray-naive"})
        with urllib.request.urlopen(req, timeout=60) as r:
            if r.status == 206:
                total = re.search(r"/(\d+)$", r.headers.get("Content-Range") or "")
                return r.read(), int(total.group(1)) if total else None
            data = r.read(small + 1)         # no range: only a small file is read whole, a big one is not downloaded
            return (data, len(data)) if len(data) <= small else (None, None)
    try:
        if size and size <= small:
            tail, total = get(None)
        else:
            try:
                tail, total = get("bytes=-65558")
            except urllib.error.HTTPError as e:     # 416: the file is smaller than the range asked for
                if e.code != 416:
                    return None
                tail, total = get(None)
        if not tail or not total:
            return None
        i = tail.rfind(b"PK\x05\x06")           # end of central directory
        if i < 0:
            return None
        _s, _d, _c, _n1, n, cd_size, cd_off, _cl = struct.unpack("<IHHHHIIH", tail[i:i + 22])
        if 0xFFFFFFFF in (cd_size, cd_off) or n == 0xFFFF:      # zip64
            j = tail.rfind(b"PK\x06\x06", 0, i)
            if j < 0:
                return None
            n, cd_size, cd_off = struct.unpack("<QQQ", tail[j + 32:j + 56])
        start = total - len(tail)
        if cd_off >= start:
            cd = tail[cd_off - start:cd_off - start + cd_size]
        else:
            cd, _t = get(f"bytes={cd_off}-{cd_off + cd_size - 1}")
            if not cd:
                return None
        files, pos = {}, 0
        while pos + 46 <= len(cd) and cd[pos:pos + 4] == b"PK\x01\x02":
            crc, _cs, size, ln, lx, lc = struct.unpack("<IIIHHH", cd[pos + 16:pos + 34])
            name = cd[pos + 46:pos + 46 + ln].decode("utf-8", "replace")
            pos += 46 + ln + lx + lc
            if not name.endswith("/"):
                files[name] = (crc, size)
        return files or None
    except Exception:
        return None


def same_files(results, keep_names):
    """two lines whose wheels contain the SAME file with different content (opencv-python + opencv-python-headless both
    write cv2/; pymongo + bson both write bson/): pip installs both into one folder, and the one installed last
    overwrites the other's files - a mixed package that may not work. One of them is kept:
    the one named with --keep, else the one with the most files in the shared folders (it has what the other has),
    else the bigger wheel. -> report lines"""
    live = [r for r in results if r["status"] not in SKIP and r.get("files")]
    owners = {}
    for r in live:
        for path, (crc, size) in r["files"].items():
            top = path.split("/")[0]
            if size and not top.endswith((".dist-info", ".data")):
                owners.setdefault(path, []).append((r, crc))
    parent = {id(r): id(r) for r in live}

    def root(x):
        while parent[x] != x:
            x = parent[x]
        return x
    shared = {}
    for path, rs in owners.items():
        if len({id(r) for r, _c in rs}) > 1 and len({c for _r, c in rs}) > 1:     # same path, different content
            ids = sorted({id(r) for r, _c in rs})
            for x in ids[1:]:
                parent[root(x)] = root(ids[0])
            shared.setdefault(ids[0], set()).add(path)
    groups = {}
    for r in live:
        groups.setdefault(root(id(r)), []).append(r)
    out = []
    keep_names = {canon(k) for k in keep_names}
    for g in groups.values():
        if len(g) < 2:
            continue
        paths = set().union(*(shared.get(id(r), set()) for r in g))
        tops = sorted({x.split("/")[0] for x in paths})
        inside = lambda r: sum(1 for x in r["files"] if x.split("/")[0] in tops)
        named = [r for r in g if r["name"] in keep_names]
        keep = named[0] if named else max(g, key=lambda r: (inside(r), (r.get("k") or {}).get("size") or 0,
                                                             -r["line"]))
        how = ("you chose --keep" if named else
               f"it has the most files there ({inside(keep)} against " +
               ", ".join(str(inside(r)) for r in g if r is not keep) + ")")
        for r in g:
            if r is keep:
                continue
            r.update(status="DROPPED", why=f"installs the same files as line {keep['line']} {keep['raw']} "
                                           f"({len(paths)} files in {', '.join(t + '/' for t in tops)}): both in one image "
                                           f"= the one installed last overwrites the other; kept line {keep['line']}, "
                                           f"{how}; to keep this one instead: --keep {r['name']}")
            out.append(f"line {r['line']}: {r['raw']}  LEFT OUT - {r['why']}")
    return out


def classify(pick, name, raw):
    """what kind of file pip picked: pure wheel / binary wheel / heavy / sdist (+ what building it needs),
    the download size, and where a GPU package gets CUDA from"""
    info = pick.get("download_info") or {}
    url = info.get("url", "")
    fname = url.split("#")[0].rstrip("/").split("/")[-1]
    meta = pick.get("metadata") or {}
    size = url_size(url) if url.startswith("http") else None
    k = {"file": fname, "version": meta.get("version", ""), "size": size}
    if fname.endswith(".whl"):
        tags = fname[:-4].split("-")[-3:]          # python tag, abi tag, platform tag
        if tags[-1] == "any":
            k["kind"], k["compiler"] = "pure wheel", "no"
            k["what"] = "Python code only: the same file works on any OS / CPU"
        else:
            heavy = size and size > HEAVY_MB * 1024 * 1024
            k["kind"] = ("HEAVY " if heavy else "") + "binary wheel" + (" (abi3)" if tags[1] == "abi3" else "")
            k["compiler"] = "no"
            k["what"] = "compiled C/C++ code (.so files) already built for Linux" + \
                (" - one file for every Python 3 version" if tags[1] == "abi3" else f" - for {tags[0]} only")
    else:
        langs = sdist_sources(url, size)
        k["kind"], k["langs"] = "sdist (source)", langs
        if langs == []:
            k["compiler"], k["what"] = "no", "source, but Python only: pip builds it without a compiler"
        elif langs:
            k["compiler"] = "YES"
            k["what"] = "source with " + ", ".join(langs) + " code: pip compiles it during the build"
        else:
            k["compiler"], k["what"] = "probably", "source: could not look inside - assume it needs a compiler"
    # GPU: does it bring CUDA itself (nvidia-* pip packages), offer it as an extra, or need it from the system?
    deps = meta.get("requires_dist") or []
    nv = [d for d in deps if CUDA_WHEEL.match(canon(re.split(r"[ ;<>=~!\[(]", d)[0]))]
    hard = [re.split(r"[ ;<>=~!\[]", d)[0] for d in nv if "extra" not in d]
    k["nv_reqs"] = [d.split(";")[0].strip() for d in nv if "extra" not in d]
    k["nv_pkgs"] = sorted({canon(h) for h in hard})
    rt = " ".join(d.lower().replace("_", "-") for d in nv if "extra" not in d)
    m = re.search(r"nvidia-cuda-runtime-cu1\d\s*==\s*(\d+)\.(\d+)", rt)
    if m:
        k["cuda_ver"] = f"{m.group(1)}.{m.group(2)}"
    m = re.search(r"cuda-toolkit(?:\[[^\]]*\])?\s*==\s*(\d+)\.(\d+)", rt)       # CUDA 13 era: cuda-toolkit[...]==13.0.3
    if m and not k.get("cuda_ver"):
        k["cuda_ver"] = f"{m.group(1)}.{m.group(2)}"
    m = re.search(r"\+cu(\d+)(\d)$", meta.get("version", ""))
    if m and not k.get("cuda_ver"):
        k["cuda_ver"] = f"{m.group(1)}.{m.group(2)}"
    extra = sorted({m for d in nv for m in re.findall(r'extra\s*==\s*["\']([^"\']+)', d)})
    if extra:
        k["cuda_extras"] = extra
    k["cuda_major"] = cuda_major_of(nv) or (int(k["cuda_ver"].split(".")[0]) if k.get("cuda_ver") else None)
    asked = re.match(r"^[A-Za-z0-9._-]+\[([^\]]*)\]", raw)
    asked = [canon(e.strip()) for e in asked.group(1).split(",") if e.strip()] if asked else []
    have = {canon(e) for e in (meta.get("provides_extra") or [])}
    if asked and [e for e in asked if e not in have]:
        k["extra_missing"] = [e for e in asked if e not in have]
    if hard:
        k["cuda"] = "own"
        k["gpu"] = f"brings its own CUDA libraries as pip packages ({len(hard)}: " + \
            ", ".join(sorted({canon(h).replace("nvidia-", "").replace("-cu12", "").replace("-cu11", "")
                              for h in hard})[:6]) + ")"
    elif extra and set(extra) & set(asked):
        k["cuda"] = "own"
        k["nv_pkgs"] = sorted({canon(re.split(r"[ ;<>=~!\[]", d)[0]) for d in nv
                               if any(re.search(r'extra\s*==\s*["\']' + e + '["\']', d) for e in asked)})
        k["gpu"] = "brings its own CUDA libraries as pip packages (through the extra [" + ",".join(
            sorted(set(extra) & set(asked))) + "])"
    elif extra:
        k["cuda"] = "system"
        k["gpu"] = "needs CUDA from the system - or write it as " + name + "[" + ",".join(extra) + \
            "] and pip installs the CUDA libraries too"
    elif name in SYSTEM_CUDA:
        k["cuda"] = "system"
        k["gpu"] = "needs CUDA + cuDNN from the SYSTEM: the base image, or NVIDIA's pip wheels registered with the loader" + \
            (" (this version has no [cuda,cudnn] extra)" if name == "onnxruntime-gpu" else "")
    return k


def cuda_size(k, py, opts, cu_index):
    """download size of the nvidia-* pip packages a GPU package pulls in (they are not in its own wheel)"""
    reqs = k.pop("nv_reqs", None)
    if not reqs:
        return
    want = {}
    ok, _ = pip_dry(reqs, py, True, opts, cu_index, want)
    if ok and want.get("all"):
        sizes = [url_size((i.get("download_info") or {}).get("url", "")) for i in want["all"]]
        k["cuda_size"] = sum(n or 0 for n in sizes)


def check_one(item, py, opts, index=None):
    no, raw, name, spec = item
    res = {"line": no, "raw": raw, "name": name, "spec": spec}
    if spec == "LOCAL":
        res.update(status="LOCAL", why="a local file path (pip freeze of a conda / local install): remove the line "
                                       "or write name==version")
        return res
    if name in WINDOWS_ONLY or re.search(r"sys_platform\s*==\s*['\"]win32", raw):
        res.update(status="WINDOWS", why="Windows-only: not needed on Linux, left out")
        return res
    m = re.search(r"\+cu(\d+)", raw)
    cu_index = f"https://download.pytorch.org/whl/cu{m.group(1)}" if m else index
    res["index"] = cu_index
    req = raw.split(";")[0].strip()
    want = {}
    ok, out = pip_dry(req, py, True, opts, cu_index, want)
    if ok:
        res.update(status="OK", why="prebuilt Linux wheel")
        md = (want.get("pick") or {}).get("metadata") or {}
        res["ndeps"] = len([x for x in md.get("requires_dist") or [] if "extra ==" not in x])
        res["requires"] = list(md.get("requires_dist") or [])
        if want.get("pick"):
            res["k"] = classify(want["pick"], name, raw)
            cuda_size(res["k"], py, opts, cu_index)
            url = ((want["pick"].get("download_info") or {}).get("url") or "").split("#")[0]
            if url.startswith("http") and url.endswith(".whl"):
                res["files"] = wheel_files(url, res["k"].get("size"))
        return res
    if ok is None:
        res.update(status="UNCHECKED", why=f"could not reach the package index: {out[-160:]}")
        return res
    ok2, out2 = pip_dry(req, py, False, opts, cu_index, want)
    if ok2 and want.get("pick"):
        res["k"] = classify(want["pick"], name, raw)
        if res["k"]["compiler"] == "no" and name not in HEAVY:
            res.update(status="SOURCE", why="no wheel, only the source - but it is Python only: pip builds it "
                                            "without a compiler")
            return res
    if ok2 and name in HEAVY:
        vs = available_versions(name, py, opts, cu_index)
        res["alts"] = nearest(vs, spec) if vs else []
        res.update(status="MISSING", why=f"no prebuilt Linux wheel for Python {py}, only the source - compiling "
                                         f"{name} usually fails or takes very long" +
                   (f"; versions WITH a wheel: {', '.join(nearest(vs, spec))} - change the pin" if vs else ""))
        return res
    if ok2 is None:
        res.update(status="UNCHECKED", why=out2)
        return res
    if ok2:
        lib = DEV_LIBS.get(name)
        res.update(status="COMPILED", dev=(lib[0] if lib else ""),
                   why="no prebuilt Linux wheel for Python " + py + ": pip compiles it during the build (gcc + "
                       "Python headers" + (f" + {lib[0]}" if lib else "") + ")" + (f"; {lib[1]}" if lib and lib[1]
                                                                                    else ""))
        vs = available_versions(name, py, opts, cu_index)
        if vs:
            res["why"] += f"; versions WITH a wheel (no compiler needed): {', '.join(nearest(vs, spec))}"
        return res
    if PREP_FAILED.search(out2 or "") and not NO_MATCH.search(out2 or ""):
        # pip FOUND the source, but preparing it ran its setup.py on THIS PC, which lacks what it asks for
        # (psycopg2: pg_config of PostgreSQL). The file exists: the image build compiles it, with the -dev library
        lib = DEV_LIBS.get(name)
        err = prep_error(out2)
        mod = re.search(r"No module named '([\w.]+)'", err or "")
        res.update(status="COMPILED", dev=(lib[0] if lib else ""),
                   why=f"no prebuilt Linux wheel for Python {py}, only the source - and pip could not prepare it on "
                       f"this PC" + (f" ({err})" if err else "") + ": that is a check on your PC; inside the image the "
                       "build compiles it (gcc + Python headers" + (f" + {lib[0]}" if lib else "") + ")" +
                       (f"; {lib[1]}" if lib and lib[1] else "") +
                       (f"; its setup.py imports {mod.group(1)} before pip installs anything - if the build fails the "
                        f"same way: install {mod.group(1).split('.')[0]} first, then this line with "
                        "--no-build-isolation" if mod else ""))
        vs = available_versions(name, py, opts, cu_index)
        if vs:
            res["why"] += f"; versions WITH a wheel (no compiler needed): {', '.join(nearest(vs, spec))}"
        return res
    vs = available_versions(name, py, opts, cu_index)
    res["alts"] = nearest(vs, spec) if vs else []
    res.update(status="MISSING", why=f"no file for Linux / Python {py} at all" +
               (f"; versions that exist: {', '.join(nearest(vs, spec))} - change the pin" if vs else
                " - check the name, or the package is not on this index"))
    return res


def mb(n):
    return "?" if not n else f"{n / 1048576:,.0f} MB" if n >= 1048576 else f"{max(1, n // 1024)} KB"


def kind_table(results, py, d=None):
    """the KIND section of naive-check.txt: what each package is, its size, compiler yes/no, GPU / CUDA source"""
    rows = [r for r in results if r.get("k")]
    if not rows:
        return (["(KIND table left out: pip older than 22.2 cannot report what it picked - "
                 "'python -m pip install -U pip' and run again)", ""] if not REPORT["ok"] else []) + \
            (["WHICH BASE IMAGE, AND WHY"] + ["  " + x for x in d["why_base"]] + [""] if d else [])
    rows.sort(key=lambda r: -(r["k"].get("size") or 0))
    w = max(len(r["name"]) for r in rows) + 2
    T = [f"WHAT KIND OF PACKAGE EACH ONE IS (the file pip picks for Linux, Python {py}; size = download, installed "
         "is about 2x)", f"  {'package':<{w}}{'version':<16}{'kind':<26}{'size':>9}  compiler",
         "  " + "-" * (w + 60)]
    for r in rows:
        k = r["k"]
        T.append(f"  {r['name']:<{w}}{k.get('version', '')[:15]:<16}{k['kind']:<26}{mb(k.get('size')):>9}  "
                 f"{k['compiler']}")
        if k.get("cuda_size"):
            T.append(f"  {'  + its nvidia-* CUDA packages':<{w + 42}}{mb(k['cuda_size']):>9}  no   (pulled in by "
                     f"{r['name']}, not in its own file)")
    total = sum((r["k"].get("size") or 0) + (r["k"].get("cuda_size") or 0) for r in rows)
    T.append(f"  {'total download':<{w + 42}}{mb(total):>9}   (other dependencies of these packages are not "
             "counted)")
    T += ["", "  pure wheel        Python code only - works on any OS / CPU, nothing to compile",
          "  binary wheel      compiled C/C++ (.so files), already built for Linux + this Python - nothing to compile",
          "  (abi3)            one binary file that works for every Python 3 version",
          f"  HEAVY             a binary wheel over {HEAVY_MB} MB (usually it carries big C++ / CUDA libraries)",
          "  sdist (source)    no wheel for Linux + this Python: pip builds it in the image - compiler YES if it "
          "has C / C++ / Cython / Rust code"]
    odd = [r for r in rows if r["k"].get("compiler") != "no"]
    for r in odd:
        T.append(f"     {r['name']}: {r['k']['what']}")
    for r in rows:
        if r["k"].get("extra_missing"):
            T.append(f"  NOTE {r['raw']}: this version has no extra [{','.join(r['k']['extra_missing'])}] - pip "
                     "ignores it (installs nothing more)")
    gpu = [r for r in rows if r["k"].get("gpu")]
    if gpu:
        T += ["", "GPU - WHERE EACH GPU PACKAGE GETS ITS CUDA LIBRARIES FROM (the driver always comes from the host)"]
        T += [f"  {r['name']}: {r['k']['gpu']}" for r in gpu]
    if d and d.get("why_base"):
        T += ["", "WHICH BASE IMAGE, AND WHY (Dockerfile.naive section 1)"] + ["  " + x for x in d["why_base"]]
    if d and d.get("notes"):
        T += [""] + ["  NOTE " + x for x in d["notes"]]
    return T + [""]


def base_ways(d, gpu, py):
    """comment lines for section 1: the other ways it could be done, and why this one"""
    L = []
    if gpu:
        on_base = d["base"].startswith("nvidia/")
        L += ["# How CUDA (libcudart, cuBLAS, cuDNN ...) gets into an image - only from INSIDE the image, so it runs on",
              "# every PC that has an NVIDIA driver:",
              "#   a) the base image: nvidia/cuda:<CUDA>-cudnn-runtime-<Ubuntu> = NVIDIA's apt packages in /usr/local/cuda"
              + ("   <- USED HERE" if on_base else ""),
              "#   b) NVIDIA's pip wheels (CUDA 12: nvidia-cublas-cu12 ...; CUDA 13: nvidia-cublas ...): torch depends on",
              "#      them; a package with an extra that installs them gets them through it on python:X-slim -",
              "#      onnxruntime-gpu[cuda,cudnn], tensorflow[and-cuda] (X-Ray Step 4: --gpu-base pip)"
              + ("" if on_base else "   <- USED HERE"),
              "#   c) from your PC: does not work - Windows has .dll files, a Linux container needs .so files, and",
              "#      another PC has other folders. Only the DRIVER comes from the PC: --gpus all mounts libcuda.so and",
              "#      nvidia-smi in."]
        if on_base and not any("-devel" in x for x in d["why_base"]):       # not said above yet
            L += ["# runtime, not devel: -devel adds the CUDA compiler nvcc + headers (about 5 GB) - needed only to COMPILE",
                  "# CUDA code (a package with .cu files and no prebuilt wheel). -base has only libcudart (too little)."
                  if "-devel" not in d["base"] else
                  "# devel: a package here has CUDA source code (.cu) and no wheel - nvcc compiles it during pip install."]
    else:
        L += ["# Other Python bases: python:X (full Debian with compilers, about 1 GB), python:X-alpine (musl: the usual",
              "# Linux wheels do not install, numpy & co. would be compiled), ubuntu + apt python3 (no pip in it)."]
    L += [f"# Python {d['pyv']}: " + ("the Python of this Ubuntu (apt python3)" if d.get("venv") else
                                      f"--python {py} (default 3.12)") +
          ". Use the version the project runs with on its PC (python --version there)."]
    return L


def gpu_from_static(path):
    try:
        with open(path, encoding="utf-8") as fh:
            st = json.load(fh)
    except (OSError, ValueError):
        return None
    return any(f.get("category") == "gpu_usage" for f in st.get("facts", []))


# system libraries a pip package loads when it RUNS (Debian / Ubuntu names; GLIB = the right glib for the OS)
RUNTIME_APT = {
    "opencv-python": (["libgl1", "GLIB", "libx11-6", "libxcb1"], "cv2 loads OpenGL (libGL.so.1), glib, and X11 for "
                                                                  "its windows (imshow)"),
    "opencv-contrib-python": (["libgl1", "GLIB", "libx11-6", "libxcb1"], "cv2 loads OpenGL, glib and X11 (windows)"),
    "opencv-python-headless": (["GLIB"], "cv2 (headless: no windows) still loads glib"),
    "lightgbm": (["libgomp1"], "OpenMP runtime"),
    "pyzbar": (["libzbar0"], "the zbar barcode library"),
    "python-magic": (["libmagic1"], "the libmagic file-type library"),
    "pyaudio": (["libportaudio2"], "the PortAudio library"),
    "pytesseract": (["tesseract-ocr"], "calls the tesseract program"),
    "ffmpeg-python": (["ffmpeg"], "calls the ffmpeg program"),
    "pdf2image": (["poppler-utils"], "calls pdftoppm (poppler)"),
    "psycopg2": (["libpq5"], "the PostgreSQL client library (psycopg2-binary brings its own)"),
    "mysqlclient": (["libmariadb3"], "the MySQL / MariaDB client library"),
    "pycairo": (["libcairo2"], "the cairo library"),
}
# packages that go into the first pip layer: big, change rarely, must match each other
FRAMEWORKS = {"torch", "torchvision", "torchaudio", "tensorflow", "tensorflow-cpu", "onnxruntime", "onnxruntime-gpu",
              "jax", "jaxlib", "paddlepaddle", "paddlepaddle-gpu", "tensorrt"}
# nvidia-* pip package -> its folder in site-packages/nvidia/ (what onnxruntime & co. load by name)
def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:2]) or (0,)


def decide(results, py, gpu):
    """every Dockerfile.naive decision, with its reason: base image, apt libraries, compilers, pip groups,
    LD_LIBRARY_PATH"""
    live = [r for r in results if r["status"] not in SKIP]
    names = {r["name"] for r in live}
    known = [r for r in live if r.get("k")]
    own = [r for r in known if r["k"].get("cuda") == "own"]
    system = [r for r in known if r["k"].get("cuda") == "system"]
    # load CUDA by name: extras that install CUDA wheels (read from the metadata), or the SYSTEM_CUDA list
    loads_system = [r for r in known if r["name"] in SYSTEM_CUDA or r["k"].get("cuda_extras")]
    comp = [r for r in live if r["status"] == "COMPILED"]
    langs = set()
    for r in comp:
        langs |= set((r.get("k") or {}).get("langs") or ["C"])
    nvcc = "CUDA (needs nvcc)" in langs
    ort = next((r for r in live if r["name"] == "onnxruntime-gpu"), None)
    ort_v = vtuple((ort.get("k") or {}).get("version") or ort["spec"]) if ort else None
    torch_cuda = next((r["k"]["cuda_ver"] for r in own if r["k"].get("cuda_ver")), None)
    d = {"why_base": [], "notes": [], "apt": [], "ld": False, "venv": False}
    if not gpu:
        d.update(base=f"python:{py}-slim", os="debian", pyv=py)
        d["why_base"].append(f"CPU image: python:{py}-slim = Debian + Python {py} only (about 120 MB). Every library "
                             "the packages need is added below, each with its reason.")
    elif nvcc:
        d.update(base="nvidia/cuda:12.8.1-cudnn-devel-ubuntu24.04", os="ubuntu24.04", pyv="3.12", venv=True)
        d["why_base"] += [", ".join(r["name"] for r in comp if "CUDA (needs nvcc)" in ((r.get("k") or {}).get("langs")
                                                                                       or []))
                          + " contains CUDA source code (.cu): compiling it needs nvcc, the GPU compiler. Only the "
                          "-devel images have it (about 9 GB). Look for a version with a prebuilt wheel first."]
    elif own:
        d.update(base=f"python:{py}-slim", os="debian", pyv=py)
        d["why_base"] += [", ".join(r["name"] for r in own) + " bring" + ("s" if len(own) == 1 else "") +
                          " the CUDA libraries as pip packages (nvidia-*). The driver (libcuda.so) comes from the "
                          "host: --gpus all mounts it in.",
                          f"So the base needs no CUDA: python:{py}-slim. An nvidia/cuda base would be a SECOND copy "
                          "of the same libraries (about 3 GB more, no speed gain)."]
    elif system or not known:
        # the CUDA major the packages' own metadata asks for (onnxruntime-gpu 1.31: nvidia-cuda-runtime~=13.0)
        major = max([r["k"]["cuda_major"] for r in system if r["k"].get("cuda_major")] or [12])
        if ort_v and ort_v < (1, 19):
            d.update(base="nvidia/cuda:11.8.0-cudnn8-runtime-ubuntu22.04", os="ubuntu22.04", pyv="3.10", venv=True)
        elif major >= 13:
            ub = "22.04" if py == "3.10" else "24.04"
            d.update(base=f"nvidia/cuda:13.0.3-cudnn-runtime-ubuntu{ub}", os=f"ubuntu{ub}",
                     pyv="3.10" if py == "3.10" else "3.12", venv=True)
        elif py == "3.10":
            d.update(base="nvidia/cuda:12.8.1-cudnn-runtime-ubuntu22.04", os="ubuntu22.04", pyv="3.10", venv=True)
        else:
            d.update(base="nvidia/cuda:12.8.1-cudnn-runtime-ubuntu24.04", os="ubuntu24.04", pyv="3.12", venv=True)
        if known:
            d["why_base"] += [", ".join(r["name"] for r in system) + (" needs" if len(system) == 1 else " need") +
                              " CUDA + cuDNN from the system, and no "
                              "package here brings them: the nvidia/cuda cudnn-runtime image has them (" +
                              d["base"] + ")." + (" onnxruntime-gpu < 1.19 is built for CUDA 11.8 + cuDNN 8." if
                                                  d["pyv"] == "3.10" and ort_v and ort_v < (1, 19) else ""),
                              "The tag, part by part: cudnn = cuDNN included (libcudnn.so.9 / .so.8); runtime = the "
                              "libraries only (-devel adds the compiler nvcc + headers, about 5 GB more, only for "
                              "compiling CUDA code; -base has only libcudart); " + d["os"].replace("ubuntu", "Ubuntu ") +
                              f" = its Python is {d['pyv']}." + (" CUDA 12.8 runs on every current RTX card, RTX 50xx "
                                                                 "too; it needs NVIDIA driver 570 or newer." if
                                                                 d["base"].startswith("nvidia/cuda:12.8") else
                                                                 " CUDA 13: " + ", ".join(r["name"] for r in system
                                                                 if (r["k"].get("cuda_major") or 0) >= 13) +
                                                                 " is built for it (its own requirements say so); "
                                                                 "it needs NVIDIA driver 580 or newer, and runs on "
                                                                 "RTX 20xx / GTX 16xx and newer (CUDA 13 dropped older "
                                                                 "GPUs)." if d["base"].startswith("nvidia/cuda:13")
                                                                 else "")]
            alt = [f"{r['name']}[{','.join(r['k']['cuda_extras'])}]" for r in system if r["k"].get("cuda_extras")]
            if alt:       # extras that install NVIDIA's CUDA wheels, read from the package's own metadata
                d["why_base"].append("Smaller alternative: python-slim + " + ", ".join(alt) + " (pip installs only the "
                                     "CUDA parts these need) + their folders registered with the loader.")
        else:
            d["why_base"].append("GPU image, package kinds unknown (pip could not report them): nvidia/cuda "
                                 "cudnn-runtime is the safe base.")
    else:
        d.update(base=f"python:{py}-slim", os="debian", pyv=py)
        d["why_base"].append("--gpu was given, but no package here uses CUDA (torch, onnxruntime-gpu, ...): "
                             f"python:{py}-slim. If the app reaches the GPU some other way, tell X-Ray (Step 2 shows "
                             "GPU use).")
    if d["os"].startswith("ubuntu") and d["pyv"] != py:
        d["notes"].append(f"the base has Python {d['pyv']}, the check ran for {py}: run xray_naive.py again with "
                          f"--python {d['pyv']} so the versions are checked for the Python that is really in the image")
    if gpu and torch_cuda and vtuple(torch_cuda) < (12, 8):
        d["notes"].append(f"torch here is built for CUDA {torch_cuda}: its own GPU code stops at RTX 40xx, so it "
                          "does not run on RTX 50xx (Blackwell, sm_120) cards, whatever CUDA the base image has - those "
                          "need a cu128 or newer torch. RTX 20xx / 30xx / 40xx are fine.")
    if ort_v and ort_v < (1, 19) and torch_cuda and vtuple(torch_cuda) >= (12, 0):
        d["notes"].append("onnxruntime-gpu < 1.19 is built for CUDA 11.8 + cuDNN 8, torch brings CUDA 12 + cuDNN 9: "
                          "onnxruntime falls back to the CPU - use onnxruntime-gpu 1.19 or newer")
    # where Python packages live in this base
    d["site"] = (f"/opt/venv/lib/python{d['pyv']}/site-packages" if d["venv"] else
                 f"/usr/local/lib/python{d['pyv']}/site-packages")
    glib = "libglib2.0-0t64" if d["os"] == "ubuntu24.04" else "libglib2.0-0"
    if d["venv"]:
        d["apt"].append((["python3", "python3-venv"], "the nvidia/cuda image has no Python"))
    for n in sorted(names):
        if n in RUNTIME_APT:
            pk, why = RUNTIME_APT[n]
            d["apt"].append(([glib if x == "GLIB" else x for x in pk], f"{n}: {why}"))
    # compilers: only for the packages pip builds from source, removed again in the same RUN
    if comp:
        tools = (["build-essential", "python3-dev"] if d["os"].startswith("ubuntu") else
                 ["gcc", "libc6-dev"] + (["g++"] if langs & {"C++", "CMake"} else []))
        keep = []
        if "CMake" in langs:
            tools.append("cmake")
        if "Rust (needs cargo)" in langs:
            tools.append("cargo")
        if "Fortran (needs gfortran)" in langs:
            keep.append("gfortran")
        dev = sorted({x for r in comp for x in r.get("dev", "").split() if x})
        d["compile"] = {"tools": tools, "keep": keep + dev, "langs": sorted(langs),
                        "who": [(r["name"], ", ".join((r.get("k") or {}).get("langs") or ["C (could not look inside)"]))
                                for r in comp]}
    # the CUDA wheels' folders: a package that loads CUDA by name + CUDA pip wheels installed + no CUDA in the base
    nv = sorted({p for r in own for p in r["k"].get("nv_pkgs", [])})
    if loads_system and nv and not d["base"].startswith("nvidia/"):
        d["ld"] = True
        d["ld_why"] = (", ".join(r["name"] for r in loads_system) + " opens libcudart / libcublas / libcudnn by NAME. "
                       "NVIDIA's pip wheels (from " + ", ".join(r["name"] for r in own) + ") put the libraries INSIDE "
                       "the image, in folders the loader does not search by itself. Nothing comes from the host except "
                       "the driver (libcuda.so), which --gpus all mounts in.")
    # pip groups
    first = [r for r in live if not r.get("later")]
    d["frameworks"] = [r for r in first if r["name"] in FRAMEWORKS or
                       (r.get("k") or {}).get("kind", "").startswith("HEAVY")]
    d["rest"] = [r for r in first if r not in d["frameworks"]]
    d["later"] = [r for r in live if r.get("later")]
    return d


def check_by_hand(d, gpu, bar):
    """comments: each choice of this Dockerfile, checked by hand inside the built image. Python is asked where
    things are, so the lines fit this image's layout (venv or not)"""
    L = bar("CHECK BY HAND - inside the built image:  docker run --rm -it --entrypoint bash IMAGE" +
            ("   (+ --gpus all)" if gpu else ""))
    L += ["# each line shows one choice above at work" + (" (Python is the venv's, /opt/venv)" if d["venv"] else ""),
          '#   python -c "import sys, site; print(sys.executable, sys.version.split()[0], site.getsitepackages())"',
          "#   pip list                                    the packages of step 3"]
    apt = list(dict.fromkeys(x for pk, _w in d["apt"] for x in pk))
    if apt:
        L.append("#   dpkg -l " + " ".join(apt) + "    the system libraries (ii = installed)")
    if d.get("compile"):
        L.append("#   which gcc || echo no compiler               removed again in the same RUN as pip")
    if d["ld"]:
        L += ["#   cat /etc/ld.so.conf.d/cuda-wheels.conf     the CUDA wheel folders of step 4",
              "#   ldconfig -p | grep -E 'libcudnn|libcublas'  the loader finds them by name"]
    elif gpu and d["base"].startswith("nvidia/"):
        L.append("#   echo $LD_LIBRARY_PATH; ldconfig -p | grep -E 'libcudnn|libcublas'    CUDA from the base image")
    if gpu:
        L.append("#   nvidia-smi                                  the GPU (only with docker run --gpus all)")
    L += ["#   ls -la /app                                 the code of step 5",
          "#   env | sort                                  the env vars the container starts with",
          '#   all at once, from your PC:  docker run --rm' + (" --gpus all" if gpu else "") +
          ' -v "TOOLS_FOLDER:/x:ro" --entrypoint "" IMAGE python /x/xray_look.py --image']
    return L


COPY_MAX_MB = 500      # a file from the PC up to this size is copied into the image by default; bigger: mounted


def outside_files(static_path, project, name, copy, mount=()):
    """files the code reads from the PC, outside the project (from the Step 1 map, with xray_runfile's rules): where
    each one is inside the container, and whether it is COPIED into the image or KEPT OUTSIDE (mounted with -v)"""
    try:
        sys.path.insert(0, HERE)
        import xray_runfile as rf
        with open(static_path, encoding="utf-8") as fh:
            st = json.load(fh)
    except (ImportError, OSError, ValueError):
        return None
    p = rf.plan(st, project, name, None, None, 180)
    items = []
    for host, cont, _mode, _why in p.get("mounts_all", p["mounts"]):
        if "PC_PATHS" in _why:      # a test file the code names by its PC path: mounted at run time, never baked
            continue
        envs = [(n, v) for n, v, _w in p["env"] if v == cont or v.startswith(cont + "/")]
        hn = host.replace("\\", "/").rstrip("/")
        used = set()
        for f in st.get("facts", []):        # every file the code reads in that folder (model.onnx, model.onnx.block ...)
            sub = str(f.get("subject", "")).replace("\\", "/")
            if f.get("category") in ("model_file", "data_file_read", "config_file") and \
                    f.get("required_at_runtime") != "no" and sub.lower().startswith(hn.lower() + "/") and "<" not in sub:
                rel = sub[len(hn) + 1:]
                if "/" not in rel:
                    used.add(rel)
        used |= {v[len(cont):].lstrip("/") for _n, v in envs if v != cont}
        here = sorted(x for x in used if os.path.isfile(os.path.join(host, x)))   # only files that exist on this PC
        size = sum(os.path.getsize(os.path.join(host, x)) for x in here)
        names = {n for n, _v in envs}
        if "all" in mount or names & set(mount):
            cp, why = False, "you chose --mount"
        elif "all" in copy or names & set(copy):
            cp, why = True, "you chose --copy"
        elif not here:
            cp, why = False, "not found on this PC, so it cannot be copied"
        elif size <= COPY_MAX_MB * 1048576:
            cp, why = True, f"small ({mb(size)}): copied, so the image runs on its own"
        else:
            cp, why = False, f"big ({mb(size)}): kept outside so the image stays small"
        items.append({"host": host, "cont": cont, "ctx": cont.rsplit("/", 1)[-1], "env": envs, "copy": cp,
                      "why": why, "files": here, "missing": sorted(used - set(here))})
    return {"items": items, "outs": [(n, v) for n, v, _w in p["env"] if v.startswith("/xout/")],
            "env": p["env"], "cpu": p["env_cpu"], "other": p["env_optional"], "gui": p["gui"], "gpu": p["gpu"],
            "changes": rf.code_changes(st, project)}


def write_files(out_dir, results, opts, py, gpu, entry, reqname, d, o=None):
    os.makedirs(out_dir, exist_ok=True)
    idx = sorted({r["index"] for r in results if r.get("index")})
    # requirements.docker.txt: the same lines, Windows-only and local paths out, PyTorch index in
    L = [f"# written by xray_naive.py {VERSION} from {reqname} - see naive-check.txt"]
    L += [f"{k} {v}" for k, v in opts]
    L += [f"--extra-index-url {u}" for u in idx if ("--extra-index-url", u) not in opts]
    for r in results:
        if r["status"] in ("WINDOWS", "LOCAL"):
            L.append(f"# {r['raw']}    <- {r['status'].lower()}: left out")
        elif r["status"] == "DROPPED":
            L.append(f"# {r['raw']}    <- left out: {r['why']}")
        elif r.get("later"):
            L.append(f"{r['raw']}    # second pip step, --no-deps (Dockerfile.naive 3c): {r['later']}")
        elif r.get("fixed"):
            L.append(f"{r['raw']}    # fixed by xray_naive, {r['fixed']}")
        elif r["status"] == "MISSING":
            L.append(f"{r['raw']}    # <- MISSING for Linux/Python {py}: change this pin (naive-check.txt)")
        else:
            L.append(r["raw"])
    for e in d.get("later_needs") or []:
        L.append(f"# + {e['req']}    <- not in your file: needed by {', '.join(e['who'])} (second step), added in "
                 "Dockerfile.naive 3c")
    with open(os.path.join(out_dir, "requirements.docker.txt"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(L) + "\n")

    def bar(title):
        return ["", "# " + "=" * 100, "# " + title, "# " + "=" * 100]

    def desc(r):
        k = r.get("k") or {}
        if not k:
            return r["status"].lower()
        t = f"{k['kind']}, {mb(k.get('size'))}"
        if k.get("cuda_size"):
            t += f" + {mb(k['cuda_size'])} nvidia-* CUDA packages"
        if k.get("extra_missing"):
            t += f"  (the extra [{','.join(k['extra_missing'])}] does not exist in this version: pip ignores it)"
        return t

    def pip_run(rs, pre="RUN ", post=None):
        ix = [f"--extra-index-url {u}" for u in sorted({r["index"] for r in rs if r.get("index")})
              if ("--extra-index-url", u) not in opts]
        head = " ".join(["pip install --no-cache-dir"] + [f"{k} {v}" for k, v in opts] + ix)
        lines = [pre + head + " \\"] + [f"        '{r['raw'].split(' #')[0]}' \\" for r in rs]
        if post:
            lines += post
        else:
            lines[-1] = lines[-1][:-2]
        return lines

    w = max([len(r["raw"]) for r in results] + [10]) + 2
    D = [f"# Naive Dockerfile written by xray_naive.py {VERSION} from {reqname}.",
         "# It only has to BUILD and RUN; every line says why it is there (details: naive-check.txt).",
         "# X-Ray Steps 2-4 then watch the real run and make it small. It runs as root, so you can apt-get inside "
         "when you explore."]
    D += bar("1. BASE IMAGE")
    D += ["# " + x for x in d["why_base"]] + ["# NOTE: " + x for x in d["notes"]]
    D += base_ways(d, gpu, py)
    D += [f"FROM {d['base']}", "# prints reach the log at once; Python writes no .pyc files",
          "ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1",
          "# apt asks no questions during the build (otherwise: 'debconf: unable to initialize frontend' in the log).",
          "# ARG, not ENV: it exists only while building, not in the running container.",
          "ARG DEBIAN_FRONTEND=noninteractive"]
    if d["apt"]:
        D += bar("2. SYSTEM LIBRARIES the packages load when they RUN (apt)")
        D += ["# A compiled package finds a library it needs in one of three places:",
              "#   - inside its own wheel (opencv_python.libs/: FFmpeg, Qt ...): nothing to install",
              f"#   - the system folders (/usr/lib/{ARCH['name']}-linux-gnu): installed with apt-get - the lines below",
              "#   - folders registered with the loader (section 4: NVIDIA's CUDA wheels) or named in LD_LIBRARY_PATH",
              "# Decided from: the package NAMES in your requirements (what each is known to load). After the X-Ray run",
              "# the slim plan keeps only what was really loaded; xray_look.py --image lists anything still missing.",
              "# apt-get update downloads the package list (about 40 MB); rm -rf /var/lib/apt/lists/* deletes it again in",
              "# the same RUN, so it is not in the image. 'debconf: delaying package configuration, since apt-utils is not",
              "# installed' in the log is normal."]
        D += [f"#   {' '.join(pk):<40} <- {why}" for pk, why in d["apt"]]
        D += ["RUN apt-get update && apt-get install -y --no-install-recommends \\",
              "        " + " ".join(dict.fromkeys(x for pk, _ in d["apt"] for x in pk)) + " \\",
              " && rm -rf /var/lib/apt/lists/*"]
    if d["venv"]:
        D += ["# Ubuntu's python3 (installed above with apt) has no pip, and Ubuntu refuses pip installs into it",
              "# ('externally-managed-environment': apt owns those files). A virtual environment = a folder with its own",
              "# python, pip and site-packages (/opt/venv/lib/pythonX/site-packages). Its bin folder first on PATH, so",
              "# 'python' and 'pip' below and in the running container mean the venv's - nothing is copied.",
              "RUN python3 -m venv /opt/venv", "ENV PATH=/opt/venv/bin:$PATH"]
    D += ["", "WORKDIR /app"]
    if d["frameworks"]:
        D += bar("3a. BIG FRAMEWORKS - their own layer, first: Docker reuses it while the lines below change")
        D += ["# Docker keeps every RUN as a layer and reuses it when the lines above it did not change. Big packages",
              "# that rarely change go first: editing 3b later rebuilds from 3b on, without downloading these again.",
              "# Chosen by: a known big framework (torch, tensorflow, onnxruntime ...) or a wheel over "
              f"{HEAVY_MB} MB - not by what the program uses."]
        D += [f"#   {r['raw']:<{w}} {desc(r)}" for r in d["frameworks"]]
        D += pip_run(d["frameworks"])
    rest = d["rest"]
    if rest or results:
        D += bar("3b. THE OTHER PACKAGES")
        c = d.get("compile")
        if c:
            D += ["#   compiled from source by pip (no wheel for Linux + this Python) - the compiler is installed for "
                  "this RUN only:"]
            D += [f"#     {n:<{w - 2}} {lang}" for n, lang in c["who"]]
            D += [f"#   compiler: {' '.join(c['tools'])}" +
                  (f";  kept (their runtime part is needed): {' '.join(c['keep'])}" if c["keep"] else "")]
            D += ["#   Other ways: a version that HAS a wheel for Linux + this Python (best: no compiler at all - "
                  "naive-check.txt lists them),", "#   or a full / -devel image that keeps the compiler (much bigger)."]
        elif rest:
            D.append(f"#   nothing to compile: every package has a prebuilt wheel for Linux + Python {d['pyv']} - "
                     "no compiler in the image")
        groups = [("prebuilt binary wheels (compiled code, nothing to compile)", lambda k: "binary" in k.get("kind", "")),
                  ("pure Python", lambda k: k.get("kind") == "pure wheel" or (k.get("kind", "").startswith("sdist")
                                                                              and k.get("compiler") == "no")),
                  ("not classified", lambda k: not k)]
        shown = {r["name"] for r in rest if r["status"] == "COMPILED"}
        for title, f in groups:
            rs = [r for r in rest if r["name"] not in shown and f(r.get("k") or {})]
            shown |= {r["name"] for r in rs}
            if rs:
                D.append(f"#   {title}: " + ", ".join(r["name"] for r in rs))
        out = [r for r in results if r["status"] in SKIP]
        D += [f"#   FIXED: {r['raw']}  ({r['fixed']})" for r in results if r.get("fixed") and r["status"] not in SKIP]
        for r in out:
            D.append(f"#   LEFT OUT ({r['status']}): {r['raw']}" + (f"  - {r['why']}" if r["status"] == "DROPPED" else "") +
                     ("   <- change the pin, see naive-check.txt" if r["status"] == "MISSING" else ""))
        if rest:
            if c:
                pre = ["RUN apt-get update && apt-get install -y --no-install-recommends " +
                       " ".join(c["tools"] + c["keep"]) + " \\"]
                post = [" && apt-get purge -y --auto-remove " + " ".join(c["tools"]) +
                        " && rm -rf /var/lib/apt/lists/*"]
                D += pre + pip_run(rest, pre=" && ", post=post)
            else:
                D += pip_run(rest)
    if d["later"]:
        D += bar("3c. LINES PIP WILL NOT INSTALL TOGETHER WITH THE OTHERS - installed second, exactly as pinned")
        D += ["# Each of these pins a version another package does not accept (pip's reason on the right). Your file",
              "# comes from a PC where packages were installed in several steps, so it has these exact versions working",
              "# together. Installing them AFTER the others with --no-deps gives the same: nothing left out, no pin changed.",
              "# pip check below prints the mismatch in the build log - information only, the build goes on."]
        D += [f"#   {r['raw']:<{w}} {r['later']}" for r in d["later"]]
        post = []
        if d.get("later_needs"):
            ns = d["later_needs"]
            D += ["# --no-deps also skips what these packages need. Already installed above: everything else they need.",
                  "# Not in your file and not installed above - added right after, with their own dependencies; -c (the",
                  "# versions installed so far) keeps every version above exactly as it is:"]
            D += [f"#   {e['req']:<{w}} needed by {', '.join(e['who'])}" for e in ns]
            add = pip_run([{"raw": e["req"], "index": None} for e in ns], pre="")
            add[0] = add[0].replace("pip install --no-cache-dir", "pip install --no-cache-dir -c /tmp/xray-installed.txt", 1)
            for u in sorted({r["index"] for r in d["later"] if r.get("index")}):
                if ("--extra-index-url", u) not in opts and f"--extra-index-url {u}" not in add[0]:
                    add[0] = add[0].replace(" \\", f" --extra-index-url {u} \\", 1)
            add[-1] += " \\"
            post = [" && pip freeze > /tmp/xray-installed.txt \\", " && (" + add[0]] + add[1:] + \
                ['     || echo "xray_naive: they could not be added without changing a version installed above - see pip"'
                 ") \\"]
        second = pip_run(d["later"], post=post + [" && (pip check || true)"])
        second[0] = second[0].replace("pip install --no-cache-dir", "pip install --no-cache-dir --no-deps", 1)
        D += second
    if d["ld"]:
        D += bar("4. THE CUDA LIBRARY FOLDERS - tell the Linux loader where the pip wheels put them")
        D += ["# Linux finds a library a program asks for BY NAME (libcudnn.so.9) in: the folders written into the",
              "# library that asks (RPATH - torch uses this for its own nvidia-* wheels), then LD_LIBRARY_PATH, then the",
              "# folders registered in /etc/ld.so.conf.d (ldconfig), then the standard folders (/lib, /usr/lib/...).",
              "# Not found: an import fails ('cannot open shared object file'), or onnxruntime silently runs on the CPU."]
        D += ["# " + x.strip() for x in re.findall(r".{1,110}(?:\s|$)", d["ld_why"])]
        D += ["# The folders are found AFTER the install, whatever the layout: CUDA 12 wheels use one folder per",
              "# library (nvidia/cublas/lib ...), CUDA 13 wheels one shared folder (nvidia/cu13/lib), cuDNN / NCCL their",
              "# own. Written to /etc/ld.so.conf.d and registered with ldconfig = a permanent LD_LIBRARY_PATH.",
              CUDA_REGISTER]
    elif gpu and d["base"].startswith("nvidia/"):
        D += bar("4. LD_LIBRARY_PATH - nothing to add")
        D += ["# The nvidia/cuda base already sets LD_LIBRARY_PATH=/usr/local/cuda/lib64 (libcudart, libcublas, libcufft ...)",
              f"# and has cuDNN in /usr/lib/{ARCH['name']}-linux-gnu, a folder Linux always searches. The driver (libcuda.so)",
              "# comes from the host: --gpus all mounts it in."]
    D += bar("5. THE CODE (all of it - X-Ray finds out what is really used)")
    D += ["COPY . ."]
    if o and (o["items"] or o["outs"]):
        D += bar("6. FILES OUTSIDE THE PROJECT - the code reads them from your PC (found in the Step 1 map)")
        D += ["# A container cannot see C:\\ or D:\\. Each file is either COPIED into the image (the image grows by its size",
              "# and runs anywhere on its own) or KEPT OUTSIDE and mounted with -v when the container starts (the image stays",
              "# small, the file can change without a rebuild). Choose: xray_naive.py ... --copy ENV_NAME (or --copy all).",
              "# Either way the env var below points at the same path inside the container."]
        was = {n: w for n, _v, w in o["env"]}
        for it in o["items"]:
            names = ", ".join(n for n, _v in it["env"]) or "(no env var)"
            D.append(f"#   {names}: your code's default {code_default(was.get(it['env'][0][0], '')) if it['env'] else ''}"
                     " is a path on your PC - in the container it is the path below")
            D.append(f"#     {it['host']}  ->  {it['cont']}   " +
                     (f"COPIED into the image ({it['why']})" if it["copy"] else
                      f"KEPT OUTSIDE ({it['why']}): docker run -v \"{it['host']}:{it['cont']}:ro\""))
            if it["copy"]:
                D.append(f"# xray-build-context: {it['ctx']}={it['host']}")
                D.append(f"COPY --from={it['ctx']} " + json.dumps((it["files"] or ["."]) + [it["cont"] + "/"]))
            D += [f"ENV {n}={json.dumps(v)}" for n, v in it["env"]]
        if o["outs"]:
            D.append("# files the program writes: /xout (mount a folder there to keep them: -v \"%CD%\\out:/xout\")")
            D += [f"ENV {n}={json.dumps(v)}" for n, v in o["outs"]] + ["RUN mkdir -p /xout"]
        if o["other"]:
            D.append("# other settings the code reads keep its defaults (change one at run time: -e NAME=value): " +
                     ", ".join(f"{n}={d}" for n, d, _s in o["other"]))
    if o and o["changes"]:
        D += bar("CODE CHANGES NEEDED - a Windows / PC path written in the code: no Docker setting can fix it")
        for i, c in enumerate(o["changes"], 1):
            D += [f"#   {i}. {c['where']}", f"#      now:       {c['now'] or ''}",
                  f"#      change to: {c['new'] or '(by hand: ' + c['note'] + ')'}"]
        D.append("#   then run xray_static.py + xray_naive.py again: the new env var gets its container path here")
    D += check_by_hand(d, gpu, bar)
    D += [f'CMD ["python", "{entry}"]']
    with open(os.path.join(out_dir, "Dockerfile.naive"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(D) + "\n")
    with open(os.path.join(out_dir, "Dockerfile.naive.dockerignore"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join([".git/", ".venv/", "venv/", "env/", ".idea/", ".vscode/", "**/__pycache__/",
                            "**/*.pyc", "logs/", "runs/", "*.log"]) + "\n")
    return d["base"]


def code_default(why):
    """xray_runfile's note 'was C:\\x.onnx' / 'output file; was out.csv - kept in ...' -> the code's default value"""
    m = re.search(r"was (.*?)(?: - kept in .*|: ask for .*)?$", why or "")
    return m.group(1) if m else (why or "")


def run_help(o, a, gpu):
    """naive-check.txt: the files outside the project (copied or mounted), and the exact build and run commands"""
    img, T = f"{a.name}-naive", ["", "FILES OUTSIDE THE PROJECT, AND HOW TO BUILD + RUN THIS IMAGE"]
    if o is None:
        return T + ["  (run with --static runs\\NAME\\NAME.json: then the files your code reads from your PC are handled "
                    "here - copied into the image or mounted - with their env vars)"]
    T += ["  A container is Linux: C:\\... and D:\\... do not exist in it. Every env var your code reads:"]
    for n, v, w in o["env"]:
        T += [f"    {n:<16} your code: {code_default(w)}", f"    {'':<16} -> in the container: {v}" +
              ("  (an output: mount a folder at /xout to keep it)" if v.startswith("/xout/") else
               "  (Dockerfile.naive sets it)")]
    for n, v, w in o["cpu"]:
        T.append(f"    {n:<16} your code: {code_default(w)}  -> used as it is (X-Ray's CPU run sets {v})")
    for n, d, _site in o["other"]:
        T.append(f"    {n:<16} your code: {d or '(no default)'}  -> used as it is")
    T.append("    to change one when you run the image: docker run ... -e NAME=value ...   (or --env-file FILE with "
             "NAME=value lines)")
    if o["changes"]:
        T += ["  CODE CHANGES NEEDED - a Windows / PC path written in the code without an env var (no Docker setting "
              "can fix it):"]
        for i, c in enumerate(o["changes"], 1):
            T += [f"    {i}. WHERE:     {c['where']}", f"       NOW:       {c['now'] or ''}",
                  f"       CHANGE TO: {c['new'] or '(by hand: ' + c['note'] + ')'}"]
        T.append("    The old value stays the default, so it still runs the same on your PC. Then run xray_static.py "
                 "and xray_naive.py again.")
    else:
        T.append("  CODE CHANGES NEEDED: none - every path from your PC is read through an env var")
    T.append("  Files your code reads from your PC:")
    import xray_runfile as rf            # next to this file (outside_files already loaded it)
    for it in o["items"]:
        names = ", ".join(n for n, _v in it["env"]) or "(no env var)"
        T += [f"    {names}: {it['host']}  ->  {it['cont']}  " + ("COPIED into the image: " + ", ".join(
            it["files"] or ["the whole folder"]) if it["copy"] else "KEPT OUTSIDE, mounted at run time") +
              f"  ({it['why']})"]
        if it["missing"]:
            T.append(f"      not on this PC, so not copied: {', '.join(it['missing'])}")
        for f in it["files"]:                 # a video: which codec - OpenCV's Linux wheel cannot read every one
            if f.lower().endswith(rf.VIDEO_EXT):
                c = rf.video_codec(os.path.join(it["host"], f))
                if c:
                    T.append(f"      video {f}: {c}" + (f" - {rf.CODEC_NOTE[c]}" if c in rf.CODEC_NOTE else ""))
    if o["items"]:
        T.append(f"    To switch: run xray_naive.py again with --copy ENV_NAME / --mount ENV_NAME (or all). Without "
                 f"them: files up to {COPY_MAX_MB} MB are copied, bigger ones stay outside.")
    ctx = "".join(f' --build-context "{it["ctx"]}={it["host"]}"' for it in o["items"] if it["copy"])
    mounts = "".join(f' -v "{it["host"]}:{it["cont"]}:ro"' for it in o["items"] if not it["copy"])
    T += ["  build (in the project folder; build-naive.bat from xray_runfile.py does the same):",
          f"    docker build -f Dockerfile.naive{ctx} -t {img} .",
          "  run it on its own (X-Ray's run files add the tracing on top of the same mounts):",
          f"    docker run --rm{' --gpus all' if gpu else ''}{mounts}" + (' -v "%CD%\\out:/xout"' if o["outs"] else "")
          + f" {img}"]
    if o["gui"]:
        T.append("  the code opens windows (cv2.imshow): a container has no screen - X-Ray's runs switch them off; "
                 "on its own, switch them off the way your code allows")
    return T


def main(argv=None):
    for _s in (sys.stdout, sys.stderr):
        if hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="check requirements for Linux before building; write a naive Dockerfile")
    ap.add_argument("--project", required=True, help="the project folder")
    ap.add_argument("--requirements", required=True, help="requirements file (name inside the project, or a path)")
    ap.add_argument("--entry", default="main.py", help="the file the container starts (CMD)")
    ap.add_argument("--name", required=True, help="short name: files go to runs/NAME/naive/")
    ap.add_argument("--python", help="Python version of the image (default: the one the project names - its venv, "
                                     ".python-version, pyproject.toml ... - else 3.12)")
    ap.add_argument("--arch", choices=("x86_64", "aarch64"), default="x86_64",
                    help="the CPU of the machine the image runs on: x86_64 = Intel / AMD (default), aarch64 = ARM "
                         "(Jetson, Raspberry Pi, ARM cloud servers)")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--gpu", action="store_true", help="GPU image (nvidia/cuda base)")
    g.add_argument("--cpu", action="store_true", help="CPU image (python:X base)")
    ap.add_argument("--static", help="the Step 1 map: GPU yes/no is taken from it when --gpu/--cpu is not given")
    ap.add_argument("--jobs", type=int, default=8, help="parallel pip checks (default 8)")
    ap.add_argument("--copy", action="append", default=[], metavar="ENV_NAME",
                    help="a file the code reads from your PC (needs --static): COPY it into the image (repeatable; "
                         "all = every one). Default: copied when up to 500 MB, else mounted at run time")
    ap.add_argument("--mount", action="append", default=[], metavar="ENV_NAME",
                    help="keep this file outside the image: mounted at run time (repeatable; all = every one)")
    ap.add_argument("--keep", action="append", default=[], metavar="PACKAGE",
                    help="two lines install the same files (opencv-python + opencv-python-headless): keep this one "
                         "(repeatable). Default: the one that has the most files there")
    a = ap.parse_args(argv)
    global PLATFORMS
    ARCH["name"], PLATFORMS = a.arch, platforms(a.arch)
    found_py, found_where = project_python(a.project)
    if a.python:
        py_from = "--python" + (f"; the project's {found_where} says {found_py}" if found_py and found_py != a.python
                                else "")
    else:
        a.python = found_py or "3.12"
        py_from = (f"from {found_where}" if found_py else
                   "the default - the project names no Python version (no venv, .python-version, pyproject.toml ...)")
    req_path = a.requirements if os.path.isfile(a.requirements) else os.path.join(a.project, a.requirements)
    if not os.path.isfile(req_path):
        sys.exit(f"requirements file not found: {req_path}")
    gpu = True if a.gpu else False if a.cpu else bool(gpu_from_static(a.static)) if a.static else None
    if gpu is None:
        gpu = False
        print("  (no --gpu / --cpu / --static: writing a CPU Dockerfile; add --gpu for a GPU image)")
    reqs, opts, notes = parse_requirements(req_path)
    seen = {}
    for no, raw, name, spec in reqs:
        if name in seen:
            pass        # handled by autofix: one line is kept, the other left out (listed in the report)
        seen.setdefault(name, no)
    print(f"xray_naive {VERSION}: checking {len(reqs)} requirements for Linux {a.arch}, Python {a.python} "
          f"(pip dry run, nothing is installed) ...", flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, a.jobs)) as ex:
        results = list(ex.map(lambda it: check_one(it, a.python, opts), reqs))
    other_pythons(results, a.python, opts, a.jobs)
    fixes = autofix(results, a.python, opts)
    fixes += same_files(results, a.keep)
    print("  ... and the whole file together, with dependencies, as the build installs it", flush=True)
    got = {}
    together, why_not = resolve_and_split(results, a.python, opts, fixes, got)
    needs = later_needs(results, a.python, got.get("names") or set())
    if needs:
        fixes.append("ADDED after the second step (--no-deps skips what those lines need; these are not in your file and "
                     "nothing else installs them): " + "; ".join(f"{e['req']} (needed by {', '.join(e['who'])})"
                                                                for e in needs.values()))
    out_dir = os.path.join(HERE, "runs", a.name, "naive")
    d = decide(results, a.python, gpu)
    d["later_needs"] = list(needs.values())
    o = outside_files(a.static, a.project, a.name, a.copy, a.mount) if a.static else None
    base = write_files(out_dir, results, opts, a.python, gpu, a.entry, os.path.basename(req_path), d, o)
    groups = {}
    for r in results:
        groups.setdefault(r["status"], []).append(r)
    T = [f"X-Ray naive check {VERSION} - {req_path}", f"for: Linux {a.arch}, Python {a.python} ({py_from}), "
         f"{'GPU' if gpu else 'CPU'} image (base {base})"]
    here = f"{sys.version_info[0]}.{sys.version_info[1]}"
    if not found_py and here != a.python:
        T.append(f"  (this PC runs xray_naive with Python {here}. The project's own Python is the one its venv uses "
                 f"(PyCharm: Settings > Python Interpreter). If that is not {a.python}, run again with --python X.Y: "
                 "versions and wheels depend on it)")
    if a.arch == "aarch64" and gpu:
        T.append("  (ARM + GPU: a Jetson needs one of NVIDIA's L4T base images (nvcr.io/nvidia/l4t-...), not the "
                 "nvidia/cuda base this file names - change the FROM line)")
    T.append("")
    pv = pip_version()
    if pv and pv < (24, 2) and sys.version_info[:2] != vtuple(a.python):
        T += [f"WARNING: your pip ({'.'.join(map(str, pv))}, running on Python {sys.version_info[0]}.{sys.version_info[1]}) "
              f"checks 'Requires-Python' against Python {sys.version_info[0]}.{sys.version_info[1]}, not {a.python}:",
              f"  packages made only for some Python versions may show up as MISSING, or with another version than the "
              "build installs.", "  Fix: python -m pip install -U pip   then run xray_naive.py again.", ""]
    if fixes:
        T += ["HANDLED SO THE BUILD WORKS (requirements.docker.txt and Dockerfile.naive; your own file is unchanged) - "
              "read them once:"]
        T += ["  " + x for x in fixes]
        if any(r.get("later") for r in results):
            T += ["  Why a second step: a Docker build installs the whole file with ONE pip install, and in one install",
                  "  pip will not put a package next to a version another package rejects. Your file comes from a PC",
                  "  where packages were installed in several steps (pip only warns there), so that PC has exactly these",
                  "  versions. Dockerfile.naive does the same: first everything else, then these lines with --no-deps.",
                  "  Whether the program works with them (the GPU too): the X-Ray Step 2 run, or xray_look.py --image."]
        T.append("")
    if together is False:
        T += ["CANNOT BE INSTALLED TOGETHER, and there is no single right fix - pip's reason (Linux / Python " +
              a.python + "):"]
        T += ["    " + x.strip() for x in why_not] + [""]
    elif together is None:
        T += ["NOT CHECKED: the whole file together (" + "; ".join(why_not) + ") - single lines were checked", ""]
    titles = [("MISSING", "NOT AVAILABLE for Linux / this Python - change these pins (the build fails otherwise)"),
              ("COMPILED", "COMPILED during the build - the Dockerfile installs a compiler (+ the -dev libraries)"),
              ("WINDOWS", "WINDOWS-ONLY - left out of requirements.docker.txt"),
              ("LOCAL", "LOCAL PATHS - left out (write name==version instead)"),
              ("UNCHECKED", "NOT CHECKED - the package index could not be reached"),
              ("SOURCE", "SOURCE ONLY, but pure Python - builds without a compiler"),
              ("OK", "OK - a prebuilt Linux wheel exists")]
    for st, title in titles:
        rs = groups.get(st, [])
        if not rs:
            continue
        T.append(f"{title} ({len(rs)}):")
        if st == "OK":
            T.append("  " + ", ".join(r["raw"] for r in rs))
        else:
            T += [f"  line {r['line']}: {r['raw']}\n      {r['why']}" for r in rs]
        T.append("")
    T += python_lines(results, a.python)
    T += kind_table(results, a.python, d)
    idx = sorted({r["index"] for r in results if r.get("index")})
    if idx:
        T.append("EXTRA INDEX added to requirements.docker.txt: " + ", ".join(idx) + " (+cuNNN pins exist only there)")
    T += notes
    T += run_help(o, a, gpu)
    T += ["", f"Files written to {out_dir}:", "  Dockerfile.naive, Dockerfile.naive.dockerignore, requirements.docker.txt",
          "Copy them into the project folder, then build (build-naive.bat from xray_runfile.py)."]
    with open(os.path.join(out_dir, "naive-check.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(T) + "\n")
    with open(os.path.join(out_dir, "naive-check.json"), "w", encoding="utf-8") as fh:
        json.dump({"tool": "xray-naive", "version": VERSION, "python": a.python, "python_from": py_from, "arch": a.arch,
                   "gpu": gpu, "base": base,
                   "requirements": [{k: v for k, v in r.items() if k != "files"} for r in results]}, fh, indent=1)
    print("\n".join(T))
    return 1 if groups.get("MISSING") or together is False else 0


if __name__ == "__main__":
    sys.exit(main())
