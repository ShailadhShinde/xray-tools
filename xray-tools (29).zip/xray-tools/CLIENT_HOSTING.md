# Client Hosting Walkthrough

Your whole solution in one compose file (anpr, middle and toll from the combined image, the dashboard, MySQL), then one closed-off copy of it for every client on one server, behind one proxy. Each client gets its own network, database, files and passwords, and one address with a password for people and a key for machines. `xray_clients.py` writes and runs all of it. Every command is below, with what you should see after it.

<form class="fill" id="fill" autocomplete="off">
<p class="fill-head"><strong>Your values</strong> <span>Type them once: every command on this page uses them. They stay in this browser.</span></p>
<label for="f-root">Hosting folder on the server<input id="f-root" data-token="D:\hosting" value="D:\hosting" spellcheck="false"></label>
<label for="f-server">Server address people type<input id="f-server" data-token="192.168.1.50" value="192.168.1.50" spellcheck="false"></label>
<label for="f-client">Client name<input id="f-client" data-token="client-a" value="client-a" spellcheck="false"></label>
<label for="f-web">Dashboard service:port inside<input id="f-web" data-token="dashboard:8080" value="dashboard:8080" spellcheck="false"></label>
<label for="f-api">API service:port inside (empty: none)<input id="f-api" data-token="middle:5014" data-flag=" --api " data-svc="middle" value="middle:5014" spellcheck="false"></label>
<button type="reset">Back to the examples</button>
</form>

*Tested* on a Linux machine with Docker 29, with the combined image of three test programs, an ASP.NET dashboard image and MySQL 8.4:
- **Clients:** four at once, reached by port, by name and by plain http.
- **No interruption:** 432 requests to one client while another started and joined the proxy, none failed.
- **Isolation:** one client's key gets 401 at another client's address. One client's containers cannot resolve or reach another client's (connection timed out). One client's database refuses the other client's password.
- **Daily work:** password and key changes take effect at once, without a restart. `update`, `remove`, backup, restore and a database password change all worked.

Not tested here: Windows as the server (the commands are written for it; the differences are in section 14) and the GPU (the test machine has none).

---

## 0. The picture

```text
 client-a's people (browser)      client-a's software               client-b's people
  https://192.168.1.50:8441        X-API-Key: <its key>               https://192.168.1.50:8442
  + user name + password           https://192.168.1.50:8441/middle/   + user name + password
 ============|===============================|===================================|========  the server:
             v                               v                                   v           only 8441-8460 open
 +------------------------------ proxy (Caddy, container clients-proxy-caddy-1) -------------------------+
 |  8441 = client-a, 8442 = client-b ...  checks the password or the key, then sends the request on      |
 +-------------|-----------------------------------------------------------------|------------------------+
               v  network client-a_net                                            v  network client-b_net
   dashboard  middle  anpr  toll  db                                  dashboard  middle  anpr  toll  db
   D:\hosting\clients\client-a\  .env  *.env  data\                    D:\hosting\clients\client-b\  ...
   volume client-a_dbdata (its database)                              volume client-b_dbdata
               \____________ the same images, the same models (read-only), one GPU ____________/
```

Per client, the tool makes these separate:

- **Network:** `client-a_net`. Containers of other clients cannot reach it, by name or by IP.
- **Database:** `client-a_dbdata`, with its own passwords.
- **Files:** `data\`, everything its programs write.
- **Settings:** `.env` and the programs' env files.
- **Way in:** a port (8441) or a name, with a user name and password for people and an API key for machines.

Shared by all clients:

- the images
- the read-only folders (models, the database's first-start scripts)
- the GPU
- the proxy

Only the proxy has ports open to the network. No client container publishes a port.

---

## 1. Today, first: one compose file for the whole solution

This file (the *system compose*) describes your solution once. It is the template: the tool makes every client's copy from it. Write it, run it once on its own, then never run it for a client by hand.

### 1.1 Where its parts come from

| Part | From |
|---|---|
| anpr, middle, toll | `compose.combined.yml` that `xray_combine.py` wrote: per program its `image`, `working_dir`, `command`, `volumes` (COMBINE_GUIDE.md 6) |
| each program's settings | its `run.env` (X-Ray wrote it): becomes `anpr.env`, `middle.env`, `toll.env` next to the compose file |
| db | the official `mysql:8.4` image; its tables and stored procedures from your current database (1.4) |
| dashboard | your dashboard image (DOTNET_WALKTHROUGH.html), its connection string pointing to `db` |

Give the images a version before you start, so each client can move to a new one on its own later:

```bat
docker tag mep-combined mep-combined:1.0
docker tag YOUR-DASHBOARD-IMAGE dashboard:1.0
docker images
```

### 1.2 The file

`D:\hosting\system\compose.yml`, the layout *tested* above. Change the names marked "your code" to the names your programs read with `os.getenv(...)`.

```yaml
name: mep
services:
  db:
    image: mysql:8.4
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_ROOT_PASSWORD:?set DB_ROOT_PASSWORD in .env}
      MYSQL_DATABASE: mep
      MYSQL_USER: mep
      MYSQL_PASSWORD: ${DB_PASSWORD:?set DB_PASSWORD in .env}
      TZ: Asia/Kolkata
    volumes:
      - dbdata:/var/lib/mysql                      # the database itself: per client (client-a_dbdata ...)
      - ./db/init:/docker-entrypoint-initdb.d:ro   # tables + stored procedures, run on the FIRST start (1.4)
    healthcheck:                                   # "healthy" = MySQL answers
      test: ["CMD-SHELL", "mysqladmin ping -h 127.0.0.1 -uroot -p\"$$MYSQL_ROOT_PASSWORD\" --silent"]
      interval: 5s
      timeout: 3s
      retries: 30
      start_period: 60s

  anpr:
    image: mep-combined:${MEP_VERSION:?set MEP_VERSION in .env}
    working_dir: /app/anpr                         # from compose.combined.yml
    command: ["python", "main.py"]                 # from compose.combined.yml
    restart: unless-stopped
    env_file: anpr.env
    volumes:
      - ./data/anpr-output:/xout/output            # what it WRITES: every client its own
      - ../models:/models:ro                       # what it only READS: shared (:ro)
    deploy:                                        # the GPU (remove these 6 lines on a PC without one)
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: all
              capabilities: [gpu]
    healthcheck:                                   # "healthy" = something listens on 5011
      test: ["CMD", "python", "-c", "import socket; socket.create_connection(('127.0.0.1', 5011), 3)"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 120s                           # loading the model: failures in this time do not count

  middle:
    image: mep-combined:${MEP_VERSION}
    working_dir: /app/middle
    command: ["python", "main.py"]
    restart: unless-stopped
    env_file: middle.env
    environment:
      ANPR_URL: http://anpr:5011/pr                # your code's name; the address: the SERVICE name + its port
      DB_HOST: db                                  # your code's names for the database
      DB_NAME: mep
      DB_USER: mep
      DB_PASSWORD: ${DB_PASSWORD}                  # the password from .env - never written twice
    depends_on:
      anpr:
        condition: service_healthy
      db:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "python", "-c", "import socket; socket.create_connection(('127.0.0.1', 5014), 3)"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 30s

  toll:
    image: mep-combined:${MEP_VERSION}
    working_dir: /app/toll
    command: ["python", "main.py"]
    restart: unless-stopped
    env_file: toll.env
    environment:
      MIDDLE_URL: http://middle:5014/mid           # your code's name
    depends_on:
      middle:
        condition: service_healthy

  dashboard:
    image: dashboard:${DASH_VERSION:?set DASH_VERSION in .env}
    restart: unless-stopped
    environment:
      ConnectionStrings__Main: "Server=db;Port=3306;Database=mep;Uid=mep;Pwd=${DB_PASSWORD}"   # your appsettings name
      TZ: Asia/Kolkata
    # ports: ["8090:8080"]                         # only to open it on THIS PC while testing - clients never get it
    depends_on:
      db:
        condition: service_healthy

volumes:
  dbdata:
```

Rules this file follows (keep them when you change it):

- **Programs reach each other by service name:** `http://anpr:5011/pr`, `Server=db`. That means no IP addresses, no `host.docker.internal`, and the port INSIDE the container. On the client's network each name leads to that client's own program.
- **Every password once, in `.env`:** programs get it through `${DB_PASSWORD}`. If the same password also stood in `middle.env` under another name, the tool would give it two different new values and middle could not log in.
- **No `container_name`, no `ports`:** the tool removes them for clients anyway, because two clients cannot share a container name or a port. Without them the system can also run next to your office containers.
- **Read-only mounts are shared:** what a program only reads gets `:ro`. Without `:ro` a folder counts as written to, and every client gets its own, which starts empty.

### 1.3 depends_on: what it does and what it does not

| `condition:` | waits until | use it for |
|---|---|---|
| `service_started` (also the short form `depends_on: [db]`) | the container has started - the program in it may still be loading | something that retries by itself |
| `service_healthy` | the other service's `healthcheck` passes | a database, an API another program calls at its start |
| `service_completed_successfully` | a one-time job has finished with exit code 0 | a database migration before the API |

Things to know:

- **Only at start-up:** it orders `docker compose up` (and `xray_clients.py start`). If middle crashes later, nothing waits; `restart: unless-stopped` starts middle again. A program that calls another should retry when the call fails. It should not stop.
- **Waiting for "healthy" needs a healthcheck** on the service it waits for. MySQL has `mysqladmin ping`. For the Flask programs, a socket check works in the slim image: no curl needed, and Python is there (*tested*). A check that calls a route would fail with 404 on a route like `/`, so use the socket check.
- **`start_period`** is the time the program needs to get ready. For anpr that is loading the model. Failed checks in that time do not count. Make it longer if the model loads slower: if anpr is not healthy then, middle and toll do not start, and `start` says so.
- **`restart: true`** under a dependency (`db: {condition: service_healthy, restart: true}`) restarts middle when compose restarts db, for example after a change. It does nothing when db crashes and Docker restarts it.
- **One-way order:** `docker compose up -d middle` also starts anpr and db, because middle depends on them. `docker compose stop db` does not stop middle.

### 1.4 The database's tables and stored procedures

MySQL runs the files in `./db/init` (`.sql`, `.sql.gz`, `.sh`, in name order) **once: on the first start, when the database volume is empty**. Every new client therefore gets its tables and the stored procedure middle calls. Later starts ignore the folder.

Take them from your current database, structure only (no rows):

- **MySQL Workbench:** Server > Data Export > tick the schema > "Dump Structure Only" > tick "Dump Stored Procedures and Functions" > "Export to Self-Contained File" > save as `D:\hosting\system\db\init\01-schema.sql`.
- **Command line:**

  ```bat
  mysqldump -h YOUR-DB-HOST -u root -p --no-data --routines --triggers --databases mep > D:\hosting\system\db\init\01-schema.sql
  ```

Then open the file and search for `DEFINER=`. A procedure made by a user that does not exist in the new database cannot be called. Replace each one with `DEFINER=`root`@`localhost`` or delete the clause. `DELIMITER //` blocks work in these files (*tested*).

### 1.5 The settings files

`D:\hosting\system\.env`: what compose itself reads for `${...}`. The values here are only the template's: every client gets new passwords (section 4).

```text
DB_ROOT_PASSWORD=template-root-password
DB_PASSWORD=template-app-password
MEP_VERSION=1.0
DASH_VERSION=1.0
```

`anpr.env`, `middle.env`, `toll.env`: each program's own settings, from its `run.env`. Take out every database password line (the program now gets `DB_PASSWORD` from the compose file), and every address of another program (now in `environment:` with the service name). Keep cameras, options and `TZ=IST-5:30`.

### 1.6 Run it once on its own

```bat
cd /d D:\hosting\system
docker compose config -q
docker compose up -d --wait
docker compose ps
```

- `config -q` prints nothing when the file is right; otherwise it names the line.
- `up -d --wait` returns when every service is running and, where it has a healthcheck, healthy. On a first start MySQL needs 20-40 s to set itself up.

`docker compose ps` should show this:

```text
NAME               SERVICE     STATUS
mep-anpr-1         anpr        Up 40 seconds (healthy)
mep-dashboard-1    dashboard   Up 29 seconds
mep-db-1           db          Up 40 seconds (healthy)
mep-middle-1       middle      Up 29 seconds (healthy)
mep-toll-1         toll        Up 23 seconds
```

Two more checks:
- `docker compose logs --tail 5 toll`: its calls to middle answer.
- In the database, the procedure is there:

  ```bat
  docker compose exec db mysql -uroot -p -e "SHOW PROCEDURE STATUS WHERE Db='mep'"
  ```

Then take it down, its test database too:

```bat
docker compose down -v
```

---

## 2. The hosting folder (once)

```text
D:\hosting\
  xray_clients.py          from the tools folder (xray-tools)
  system\                  the template from section 1: compose.yml .env anpr.env middle.env toll.env db\init\
  models\                  what the programs only read (shared)
  proxy\                   made by the tool: the way in
  clients\                 made by the tool: one folder per client
```

Before the first client, check these once:

- **Python 3.8 or newer:** `python --version`. The tool needs nothing else.
- **Docker with compose v2:** `docker compose version`.
- **The images are on this machine:** `docker images` shows `mep-combined:1.0` and `dashboard:1.0`. From another PC, carry them over:

  ```bat
  docker save -o mep-1.0.tar mep-combined:1.0 dashboard:1.0
  docker load -i mep-1.0.tar
  ```

  `mysql:8.4` and `caddy:2` come from the internet the first time. Without internet, `docker pull` them on another PC and carry them over with `docker save` the same way.
- **The port range is free:** Windows keeps some port ranges for itself (Hyper-V, WSL). Run this (no admin needed):

  ```bat
  netsh interface ipv4 show excludedportrange protocol=tcp
  ```

  If a listed range covers any of 8441-8460, pick another range of 20 ports and give it to the FIRST `add` as `--ports 9441-9460`. It cannot change once a client has a port.
- **The firewall lets other PCs in:** only an administrator can open it, once (Windows Defender Firewall, inbound, TCP 8441-8460):

  ```bat
  netsh advfirewall firewall add rule name="clients-proxy" dir=in action=allow protocol=TCP localport=8441-8460
  ```

- **Docker starts by itself:** the clients run only while Docker runs. In Docker Desktop: Settings > General > "Start Docker Desktop when you sign in". The containers (`restart: unless-stopped`) come back with Docker. Docker Desktop runs only while a user is signed in. A server that must run when nobody is signed in is better on Linux with Docker Engine (section 14).

---

## 3. Add the first client

```bat
cd /d D:\hosting
python xray_clients.py add client-a --system system\compose.yml --web dashboard:8080 --api middle:5014 --server 192.168.1.50
```

| Part | Means |
|---|---|
| `client-a` | the client's name: small letters, digits and `-`, starting with a letter. It names the folder, network, volumes and containers (`client-a-db-1`), and it is the user name for the dashboard |
| `--system` | the system compose from section 1 |
| `--web SERVICE:PORT` | what people open in a browser. The service's name in the system compose and the port it listens on INSIDE its container (8080 for an ASP.NET dashboard), not a published port. One per client |
| `--api SERVICE:PORT` | what software outside calls, with a key. Repeatable. Only for calls from OUTSIDE: anpr, middle and toll call each other inside the client's network, so they need nothing here |
| `--server` | the address the client's people type to reach this server: its IP, or its name. The proxy's certificate is made for it |
| `--port` | its port; default: the next free one of 8441-8460 |
| `--ports FIRST-LAST` | with the first client only: another range than 8441-8460 (section 2) |
| `--host NAME` instead of `--server` | a DNS name for this client (`client-a.yourcompany.com`) pointing to this server; then ports 80 and 443 instead of a port of its own. `--tls public` (the default with `--host`) gets a real certificate from Let's Encrypt, which needs the name reachable from the internet; `--tls internal` uses the proxy's own |
| `--tls off` | plain http: passwords and keys travel unencrypted. Only inside a network you trust |

What it prints:

```text
client-a: ready to start

  D:\hosting\clients\client-a
    compose.yml   the system's services, closed off: no ports, no container names, its own network
    .env          the system's settings, new secrets: DB_PASSWORD, DB_ROOT_PASSWORD
    data/         its files    ACCESS.txt   what to hand over    client.json   its settings for this tool
  D:\hosting\proxy\sites\client-a.caddy   its way in

  NOTE SHARED read-only by every client (models, settings, database first-start scripts): anpr: D:\hosting\models -> /models
  NOTE SHARED read-only by every client (models, settings, database first-start scripts): db: D:\hosting\system\db\init -> /docker-entrypoint-initdb.d

  Address:   https://192.168.1.50:8441
  ...
  PEOPLE (browser):
    open      https://192.168.1.50:8441/
    user      client-a
    password  <20 random characters>

  MACHINES (middle): every request with the header  X-API-Key: <the key>
    address   https://192.168.1.50:8441/middle/ + the program's own path  (its /x is https://192.168.1.50:8441/middle/x)
    key       <43 random characters>
```

What it made:

```text
D:\hosting\clients\client-a\
  compose.yml      the system compose, closed off (below)
  .env             the system's .env, every password made new
  anpr.env ...     each program's env file, a copy for this client
  data\            what its programs write (anpr-output ...), empty
  ACCESS.txt       address, user, password, key: what you hand over (section 7)
  client.json      its settings for the tool (port, address, what it exposes)
D:\hosting\proxy\
  compose.yml      the proxy, joined to every client's network
  Caddyfile        global settings + "import sites/*.caddy"
  proxy.json       the port range, the default address for IPs
  sites\client-a.caddy   client-a's way in: its port, the key check, the password check
```

How its `compose.yml` differs from the system compose:

| In the system compose | In the client's |
|---|---|
| `container_name: ...` | gone: every service is reached by its service name, as before |
| `ports: ...` | gone: the only way in is the proxy |
| the default network | `client-a_net`, made by the tool (`external: true`). Only the proxy joins it |
| `dashboard`, `middle` | also known on that network as `client-a-dashboard`, `client-a-middle` (the proxy sends there) |
| `./data/anpr-output` (written to) | `./data/anpr-output` in the client's folder: its own, empty at first |
| `../models:/models:ro` (read-only) | the same folder: shared |
| `env_file: anpr.env` | `./anpr.env`: the client's copy |
| volume `dbdata` | the same name; compose makes it `client-a_dbdata` |
| `${DB_PASSWORD}`, `${MEP_VERSION}` | unchanged: filled from the client's own `.env` |

The NOTE lines, and what to do:

| NOTE | Do |
|---|---|
| `container_name left out` | nothing |
| `SHARED read-only` | nothing, if every client should read the same files. If the files differ per client, make a copy per client and point that client's compose to it |
| `starts EMPTY - the system's folder has N file(s), not copied` | the tool does not copy what a program writes, because it may be your office's data. If the program needs those files (templates, settings), copy them with the command the NOTE prints |
| `is a copy of ... - edit it for this client` | a settings file mounted into a container (appsettings.json ...): edit it for this client |
| `uses the GPU` | section 11 |
| `extra_hosts host.docker.internal` | something on the server itself would be shared by every client: a database per client is safer |

---

## 4. The client's own settings

Open `D:\hosting\clients\client-a\.env` and the programs' env files.

- **Passwords:** every setting whose name ends in `PASSWORD`, `PWD`, `PASS`, `SECRET`, `TOKEN`, `API_KEY` or `PRIVATE_KEY` now has a new random value of 24 characters, with a comment above it.
  - **Leave as they are:** passwords of your own solution (`DB_PASSWORD`, `DB_ROOT_PASSWORD`). MySQL takes them at the client's first start.
  - **Put the client's real one:** a password of something outside your solution (a camera login, a mail server, a licence key). The tool cannot know it, so it made a random one, and the program cannot log in until you put the real one.
- **The client's own things:** camera addresses, site names, options. They are still the template's values.
- **Versions:** `MEP_VERSION`, `DASH_VERSION` choose which images this client runs (section 9).

Three kinds of addresses in these files:

| Address | Example | Per client |
|---|---|---|
| one program to another, inside | `http://anpr:5011/pr`, `Server=db` | unchanged: on the client's network the names lead to its own programs |
| something at the client's site, called FROM the server | `rtsp://CAMERA-ADDRESS:554/...` | the client's. The server must be able to reach it (a VPN to the client's site, or the camera reachable from outside). Check from inside the container: `docker compose exec anpr python -c "import socket; socket.create_connection(('CAMERA-ADDRESS', 554), 5)"` (no output = reachable) |
| something a BROWSER opens | a link in the dashboard to a picture or a page | the client's address: `https://192.168.1.50:8441/...`. The proxy forwards to the dashboard (and to `/middle/` with the key) and to nothing else. A link to another program's port does not work for the client |

A database password is changed **before the first start** of a client, or with section 9 afterwards. MySQL keeps the password it was given at the first start in the database itself, and later changes to `.env` do not reach it.

These files are the client's secrets: never in git, never in a chat, never in an e-mail.

---

## 5. Start it

```bat
python xray_clients.py start client-a
```

What happens, in this order:

1. The network `client-a_net` is made if it is missing.
2. On Linux: the folders the programs write to are handed to the user the program runs as (in the slim images uid 1000). Windows needs nothing.
3. `docker compose up -d --wait` in the client's folder: the services start in the `depends_on` order, and the tool waits until all are running and healthy, at most 300 s. If anpr takes longer, use `--wait 900`. A service that fails is shown with its last 20 lines.
4. 15 seconds later it looks again. A program that crashes right after its start (it looked "running" for a moment) is shown with its last lines.
5. The proxy:
   - first client: the proxy is started
   - any later client: the proxy joins the client's network and reloads its settings. The other clients keep running (*tested*: 432 requests to one client while another started, none failed).
6. On https, the proxy's root certificate is copied next to ACCESS.txt, as `caddy-root.crt`.

What you should see:

```text
starting client-a (docker compose up -d in D:\hosting\clients\client-a) ...
starting the proxy ...

client-a is running: https://192.168.1.50:8441
Hand over: ACCESS.txt + caddy-root.crt (in D:\hosting\clients\client-a)
Next:  python xray_clients.py test client-a
```

The same command applies every later change of the client's `.env` or `compose.yml`. Compose then recreates only the containers whose settings changed. A change in an env file changes every service that reads it.

---

## 6. Test it

```bat
python xray_clients.py test client-a
```

```text
client-a through the proxy - https://192.168.1.50:8441   (sent to this machine, as a browser would send it)
  OK   middle: no key             -> 401   (want 401)
  OK   middle: a wrong key        -> 401   (want 401)
  OK   middle: its key            -> 404   (want not 401 (the program's own answer))
  OK   dashboard: no password     -> 401   (want 401)
  OK   dashboard: a wrong one     -> 401   (want 401)
  OK   dashboard: its password    -> 200   (want not 401)

all as it should be
```

- **401:** the proxy stopped the request; it never reached the client's containers.
- **Its key:** anything but 401 means the key works and middle itself answered. 404 is middle saying "no such route" to `GET /`; your software calls its real routes (`/middle/mid`).
- **The test runs on the server itself:** it sends the requests to 127.0.0.1 with the client's address, as a browser would. It needs no DNS and no network to the client.
- **The real path:** to test it, add `--url https://192.168.1.50:8441`. Then the test goes through DNS and the network.

From a client's PC, open the address in a browser: it asks for the user name and password, then shows the dashboard.

---

## 7. Hand it over

Give the client two files from `D:\hosting\clients\client-a\`:

- **`ACCESS.txt`:** address, user name, password, API key, and a test line for curl. Hand it over through a password manager, or the password by another way than the address (in person, by phone). Then delete the file from the server. The proxy keeps only a hash of the password. The key is in `proxy\sites\client-a.caddy`, because the proxy needs it to compare. Keep the `proxy` folder for administrators only.
- **`caddy-root.crt`:** the proxy's own certificate authority, made for this server (`--tls internal`). Browsers trust the address only after this certificate is installed on that PC. It is a certificate, not a secret: it can be sent by e-mail. Valid for 10 years. The proxy renews the address's own certificate (12 hours) by itself.

Install `caddy-root.crt` on every PC that opens the address:

- **Windows, for the signed-in user (no admin rights needed):**

  ```bat
  certutil -user -addstore Root caddy-root.crt
  ```

  Windows asks "Do you want to install this certificate?": Yes. The same by clicking: double-click the file > Install Certificate > Current User > "Place all certificates in the following store" > Trusted Root Certification Authorities > Finish. Then restart Chrome or Edge (they use the Windows store).
- **Firefox:** Settings > Privacy & Security > Certificates > View Certificates > Authorities > Import > tick "Trust this CA to identify websites".
- **Software:**
  - curl: `--cacert caddy-root.crt` (*tested*: the address checks out, no `-k` needed)
  - Python requests: `verify="caddy-root.crt"`
  - .NET: the Windows store, as above

The client's PCs must also reach the server's address:
- **Same network:** its LAN IP, as `--server`.
- **From outside:** a VPN into your network, or a port forward on your router from a public address to the server's 8441. Then `--server` must be the address the client types. If the address changed, use `update --server` (section 9).

---

## 8. The next client

```bat
python xray_clients.py add client-b --system system\compose.yml --web dashboard:8080 --api middle:5014 --server 192.168.1.50
python xray_clients.py start client-b
python xray_clients.py test client-b
python xray_clients.py list
```

client-b gets port 8442, its own network, database, data and passwords. The proxy is not restarted. `list`:

```text
client         address                            people             machines               running
client-a       https://192.168.1.50:8441          dashboard:8080     /middle/               5/5
client-b       https://192.168.1.50:8442          dashboard:8080     /middle/               5/5
```

---

## 9. Everyday work

Run these in `D:\hosting`, or in the client's folder `D:\hosting\clients\client-a` (marked "in its folder"). Every action below was *tested*.

| To | Do |
|---|---|
| see all clients | `python xray_clients.py list` |
| see one client's containers | in its folder: `docker compose ps` |
| read a program's output | in its folder: `docker compose logs -f --tail 100 middle` |
| restart one program | in its folder: `docker compose restart middle` |
| stop / start a client | in its folder: `docker compose stop` / `python xray_clients.py start client-a` (its data stays) |
| apply a change of its `.env` or env files | `python xray_clients.py start client-a` |
| a new dashboard password | `python xray_clients.py password client-a`: active at once, the old one stops working, nothing restarts. The new one is in ACCESS.txt |
| a new API key | `python xray_clients.py key client-a`: the same |
| a new image version for ONE client | build and tag it (`mep-combined:1.1`). In that client's `.env`: `MEP_VERSION=1.1`. Then `start client-a`. Other clients keep 1.0. Wrong? Back to 1.0, `start` again. Move clients one by one |
| a change of the system compose (a new setting, a new service) | `python xray_clients.py update client-a`, then `start client-a`. It rewrites the client's `compose.yml` and keeps its `.env`, passwords and data; the old file stays as `compose.yml.before-update`. One client after another |
| the server's IP changed | `python xray_clients.py update client-a --server NEW-ADDRESS` for each client: active at once, ACCESS.txt shows the new address. Once the last client by port has moved, the proxy answers IP addresses with the new address's certificate; until then the tool names the clients still on the old one |
| change a client's database password | in its folder: `docker compose exec db mysql -uroot -p` (type its `DB_ROOT_PASSWORD` from its `.env`), then `ALTER USER 'mep'@'%' IDENTIFIED BY 'the-new-password';` and `exit`. Put the same in its `.env` as `DB_PASSWORD=...`, then `start client-a`: middle and the dashboard get the new one |
| look into a client's database | in its folder: `docker compose exec db mysql -uroot -p mep` |
| take a client off | `python xray_clients.py remove client-a`: off the proxy at once, stopped, its network removed. Its folder, data and database volume stay |
| delete a client for good | after a backup (section 10): in its folder `docker compose down -v` (deletes its database), then delete the folder `D:\hosting\clients\client-a` |

The tool writes these files: `proxy\Caddyfile`, `proxy\sites\*.caddy`, `proxy\compose.yml`, the clients' `compose.yml` and `client.json`. Change those through the tool; a hand edit is overwritten. Edit the clients' `.env` and env files freely.

---

## 10. Backups

Back up three things.

**Each client's database** (in its folder, in `cmd`). PowerShell's `>` changes the file's encoding, so use `cmd` for these two commands. Make the folder once (`mkdir D:\hosting\backups`), and copy the backups off this machine afterwards:

```bat
cd /d D:\hosting\clients\client-a
docker compose exec -T db sh -c "MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysqldump -uroot --single-transaction --routines --databases mep" > D:\hosting\backups\client-a.sql
```

Restoring is the other direction (the dump recreates the tables and the stored procedure; *tested*):

```bat
docker compose exec -T db sh -c "MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysql -uroot" < D:\hosting\backups\client-a.sql
```

`$MYSQL_ROOT_PASSWORD` is read inside the container, so the password is never typed or written to the command line.

**Each client's folder:** `D:\hosting\clients\client-a` (its `.env`, env files and `data\`).

**The proxy:** the `D:\hosting\proxy` folder, and the proxy's certificate authority, which lives in its volume. The `/.` copies the contents, so the same command can run again into the same folder:

```bat
cd /d D:\hosting\proxy
docker compose cp caddy:/data/caddy/. D:\hosting\backups\caddy-data
```

If that volume is lost (`docker compose down -v` in `proxy`, a new server), the proxy makes a NEW authority, and every client PC must install a new `caddy-root.crt`. So never use `down -v` in `proxy`. To put the backup back (on a new server: the clients added and started first), run these in `D:\hosting\proxy`. *Tested*: the same root certificate afterwards, and the old `caddy-root.crt` still checks out.

```bat
docker compose down -v
docker compose create
docker compose cp D:\hosting\backups\caddy-data\. caddy:/data/caddy
docker compose start
```

Restore one backup once to see that it works.

---

## 11. Limits per client and the GPU

**CPU and memory:** set limits in the system compose. Every client gets them, and one busy client cannot slow down the others beyond them:

```yaml
  middle:
    deploy:
      resources:
        limits:
          cpus: "2"
          memory: 2G
```

Check with `docker stats`: each container against its limit. A program that goes over its memory limit is stopped and started again by `restart: unless-stopped`; only that client's program is affected.

**Logs:** Docker keeps every line a program prints, unless told otherwise. Per service in the system compose:

```yaml
    logging:
      driver: json-file
      options: {max-size: "10m", max-file: "3"}
```

**The GPU:** every client runs its own anpr, and each loads its own copy of the model onto the card. The card's memory (12 GB on an RTX 3060) is shared by all of them, and Docker cannot limit it per container.
- **When it is full:** the next one to ask fails with `CUDA out of memory`, and that can be any client.
- **Measure:** after each client's start, `nvidia-smi` shows the memory per process. Clients that fit = (card memory - 1 GB) / one anpr's memory.
- **Limit it per framework:** each has its own memory switch (PyTorch, TensorFlow, ONNX Runtime). The switches are in MULTI_CLIENT_HOSTING.md, section 5.

---

## 12. When something is wrong

| You see | Why | Do |
|---|---|---|
| `add`: `docker compose cannot read the system compose` | an error in the system compose | `cd system` then `docker compose config`: it names the line |
| `add`: `has build: and no image:` | a client runs images, it does not build | give the service `image: NAME:VERSION`, build it once |
| `start`: a service `stopping again and again` + its last lines | the program fails: the lines say why | fix that, then `start` again: it starts failing containers fresh |
| ... `Access denied for user 'mep'` | the database was made with another password (the `.env` changed after the first start) | section 9, "change a client's database password" |
| ... `PermissionError` on a folder (Linux) | the folder belongs to another user than the program's | `start` again: it hands the folder over; or `sudo chown 1000:1000 FOLDER` |
| `start`: `did not start (healthy) within 300s` | a health check never passes: anpr still loading, or a program not listening on the port in its check | `docker compose ps` and `logs` in its folder; `start client-a --wait 900`; a longer `start_period` |
| `start`: `ports are not available ... :80` | ports 80/443 (only for clients with `--host`) are taken: IIS often has 80 | stop IIS's site on 80, or reach that client by a port instead |
| `start`: `... 8441 ... access permissions` (Windows) | the range is reserved by Windows | section 2, the port range |
| browser: "Your connection isn't private" (`NET::ERR_CERT_AUTHORITY_INVALID`) | `caddy-root.crt` is not installed on that PC | section 7 |
| browser: `ERR_SSL_PROTOCOL_ERROR`; curl: `tlsv1 alert internal error` | an IP address the proxy has no certificate for | use the address from ACCESS.txt; a changed server IP: section 9 |
| browser: `NET::ERR_CERT_COMMON_NAME_INVALID` | opened by another address than the one in ACCESS.txt (the server's name instead of its IP) | use the address in ACCESS.txt; for a name, add the client with `--host` |
| it keeps asking for the password | the user name is the client's name; or the password was changed | ACCESS.txt; `password client-a` gives a new one |
| `missing or wrong API key` (401) | the header is not exactly `X-API-Key`, the key has a space or a line break, or it was changed | copy it again from ACCESS.txt |
| `502 Bad Gateway` | the proxy reached nothing: the program is down, or `--web` / `--api` has the wrong port (it is the port INSIDE the container) | `list`; `docker compose ps` in its folder; `client.json` shows the ports |
| works on the server, times out from another PC | the firewall, or the PC cannot reach the server's network | section 2, the firewall; a VPN |
| connection refused on the port | the proxy is not running, or the client was removed | `cd proxy` then `docker compose ps`; `start` any client starts it |
| the dashboard opens but shows no data | its connection string or the database | EMPTY_DASHBOARD.md |
| middle cannot reach a camera at the client's site | the server has no route to the client's network | section 4, the socket check from inside the container |
| `CUDA out of memory` in one client's anpr | the GPU memory is full | section 11 |
| the stored procedure is missing in a client's database | the first-start scripts run only on an EMPTY database (they were added later) | in its folder: `docker compose exec -T db sh -c "MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysql -uroot mep" < D:\hosting\system\db\init\01-schema.sql` |
| `network client-a_net declared as external, but could not be found` | the client was started by hand before the tool made its network | `python xray_clients.py start client-a` |

---

## 13. What is separate and what is shared

Separate per client (*tested*):

- **Network:** a client's containers cannot resolve another client's names (`Name or service not known`). They cannot reach another client's container by IP either (connection timed out).
- **Database:** its own volume, its own passwords. One client's password is refused by another client's database.
- **Files:** its `data\` folder, its env files.
- **Way in:** its own key and password. Another client's key gets 401.

Shared:

- **The images and the read-only folders:** the same files for everyone, read-only.
- **The GPU, and CPU and memory** above the limits you set (section 11).
- **The proxy:** a client's containers can reach the proxy like anyone outside, and get the same 401 without another client's key and password.
- **The Docker engine:** whoever can run `docker` on the server can see and change every client. Keep the server for administrators.

---

## 14. Reference

### The commands

| Command | Does |
|---|---|
| `add NAME --system FILE --web S:P --api S:P --server ADDRESS [--port P] [--ports FIRST-LAST]` | a new client: folder, compose, env files with new passwords, network, its way in, ACCESS.txt |
| `start NAME [--wait SECONDS]` | up and healthy, checked again 15 s later, joined to the proxy; also applies changes |
| `test NAME [--url ADDRESS] [--password PW]` | through the proxy: no key / wrong key / its key, no password / wrong / its password |
| `list` | every client: address, what it exposes, containers running |
| `password NAME` / `key NAME` | a new dashboard password / API key, active at once |
| `update NAME [--system FILE] [--server ADDRESS]` | its compose made again from the system compose; a new server address |
| `remove NAME` | off the proxy, stopped, network removed; folder, data and database stay |
| `--root FOLDER` before the command | the hosting folder, when you run it from somewhere else |

### On a Linux server

- **Commands:** the same, with `python3` and `/` in paths. The hosting folder is for example `/srv/hosting`; type that above and every command changes.
- **Folders:** `start` gives the folders the programs write to to the program's user (uid 1000 in the slim images). It does this itself when run as root; otherwise it prints the `sudo chown` line to run. For the system compose run on its own (section 1.6): `sudo chown 1000:1000 data/anpr-output` first.
- **Docker starts at boot**, nobody needs to be signed in: `sudo systemctl enable --now docker`.
- **Firewall:** `sudo ufw allow 8441:8460/tcp`.
- **GPU:** the NVIDIA driver plus the NVIDIA Container Toolkit.

### How the tool works

- **The client's compose:** it reads the system compose with `docker compose config --format json --no-interpolate`, which keeps `${...}` and makes paths absolute. Then it writes the client's copy: no `container_name`, `ports` or `network_mode`; the network `NAME_net`; folders that are written to moved into the client's folder; read-only ones kept.
- **The proxy** is Caddy (`caddy:2`):
  - **Settings:** its `Caddyfile` imports one file per client from `sites/`. A change is applied with `caddy reload`, which keeps the open connections.
  - **Networks:** it joins each client's network with `docker network connect`, so it is not recreated when a client is added.
  - **Ports:** 8441-8460 are published once. 80 and 443 only once a client is reached by a name; that first time the proxy is recreated, and every client is unreachable for a few seconds.
- **Passwords and keys:**
  - The dashboard password is stored as a bcrypt hash (`caddy hash-password`).
  - The API key is compared with the `X-API-Key` header (case matters), and the client's path prefix (`/middle`) is removed before the request reaches middle.
  - Passwords and keys come from Python's `secrets`: 20 characters for a password, 43 for a key, 24 for a setting.
- **Certificates:**
  - **By port:** the proxy's own authority (`tls internal`). An address typed as an IP sends no name, so the proxy answers with the certificate of `default_sni` in `proxy.json`: the `--server` the clients by port share.
  - **By name:** each client's name has its own certificate.
