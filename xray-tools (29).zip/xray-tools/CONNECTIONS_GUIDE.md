# Connecting your programs - from `os.getenv` in the code to `open` on the network

One program calls another: the toll sends a plate to an API, the API calls a second API, the dashboard asks for a
result. On your PC each call went to an address you copied. In Docker each program has its own little machine, and
the call works only when BOTH ends are right. This guide follows one call from the code to the running containers:
what each piece means, what to write down, and what to look for.

The commands for your whole system (in the right order, with a check after each) are in SYSTEM_WALKTHROUGH.html.
This guide is the "why" behind them. Everything marked *tested* was run with a Flask API and a program that calls it,
in containers; the messages quoted are the real ones.

---

## 0. One call has two ends

```text
THE CALLER (the toll)                                  THE SERVER (the API)
---------------------------------------------------    ---------------------------------------------------
MID_URL = os.getenv("midurl", "http://192.168...")      app.run(host="0.0.0.0", port=5001)
                                                        @app.route("/predict", methods=["POST"])
docker run --name toll ...                              docker run --name api ...
           -e midurl=http://api:5001/predict                       --network system_net
           --network system_net
                      |                                                     ^
                      +-------------- http://api:5001/predict --------------+
                                      NAME    PORT    ROUTE
                                      (its    (the port it listens on INSIDE its container)
                                      --name)
```

- **The server's end** is WHERE it listens: the address (`0.0.0.0`) and the port, in its code or its command - and
  its routes.
- **The caller's end** is the ADDRESS it calls, read from an env var.
- They are set in different places. The caller's env var does not change how the server listens, and the other way
  round. Almost every "it does not connect" is one end wrong - section 7 finds which.

---

## 1. The caller's code: `os.getenv`

```python
MID_URL = os.getenv("midurl", "http://192.168.1.20:5001/predict")
```

- The first argument is the NAME looked up in the container's environment; the second is the DEFAULT, used only when
  that name is not set. In a container the default (an address of your PC or office network) is usually wrong for a
  program that now runs in Docker too, so the name gets a value: `-e midurl=http://api:5001/predict`.
- **The name must match exactly, upper and lower case.** Windows does not care; Linux does. *Tested:* with
  `-e MIDURL=...` set, `os.getenv("midurl")` returned `None` - the program used its default IP.
- **It is read once.** A line at the top of `constants.py` runs when the program starts. A new value needs the
  container started again (section 6).
- **An address built from parts** (`f"http://{API_HOST}:{API_PORT}/predict"`): each part is its own env var -
  `API_HOST=api`, `API_PORT=5001`.
- **A good habit:** print it once at the start, `print("sends to", MID_URL)`. The log then shows which address the
  program really uses (section 7).

**What X-Ray shows for this line** (*tested*). Step 1's report:
```text
TO RUN IT IN A CONTAINER, YOU PROVIDE
  env      -e midurl=http://192.168.1.20:5001/predict code default 'http://192.168.1.20:5001/predict' - an address:
           from a container, another container is called by its name (--name or service name) and the port it
           listens on inside, a program on this PC is host.docker.internal, another machine stays as it is
```
And the run.env that xray_runfile.py writes has the line, switched OFF:
```text
# other env vars the code reads (its default is used while the line stays off):
#   midurl: read at constants.py:3
# midurl=http://192.168.1.20:5001/predict
```
So it does not become a value by itself: until you remove the `# ` (and write the new address) or pass `-e`, the
program uses its default. For one program run alone that is often what you want. In the system, its `docker run`
line passes `-e midurl=http://api:5001/predict`, and `-e` wins over run.env (*tested*) - run.env stays as it is for
X-Ray's own test runs. (xray_static.py before 0.5.18 also listed such a default under CODE CHANGES NEEDED. It is not
one: the env var is the fix.)

---

## 2. The server's code: where it listens

Flask prints where it listens. *Tested*, the same API started two ways:

```text
 * Running on all addresses (0.0.0.0)       <- it listens on EVERY address of its container: right
 * Running on http://127.0.0.1:5001         <- the same server, as seen from inside its own container
 * Running on http://172.18.0.2:5001        <- the same server, at the container's address of today
```
```text
 * Running on http://127.0.0.1:5001         <- and nothing else: ONLY inside its own container - nobody gets in
```

**Which IP do you care about?** Only that `Running on all addresses (0.0.0.0)` is there. The `127.0.0.1` line is always
printed. The `172.x` address is new each time the container is created: never write it anywhere - the others use the
NAME.

**The caller's env var does not fix a server on 127.0.0.1.** *Tested:* with the caller's `midurl=http://api:5001/predict`
exactly right, it got `[Errno 111] Connection refused` until the API listened on `0.0.0.0`. The fix is on the server's
end: `app.run(host="0.0.0.0", port=5001)`, or - as the test API did - read it, `app.run(host=os.getenv("API_HOST",
"127.0.0.1"), ...)`, and start it with `-e API_HOST=0.0.0.0`.

| Server | Right for a container | The fix |
|---|---|---|
| Flask `app.run()` | `Running on all addresses (0.0.0.0)` | `app.run(host="0.0.0.0", port=...)` |
| uvicorn (FastAPI) | `Uvicorn running on http://0.0.0.0:8000` | `--host 0.0.0.0` |
| gunicorn | `Listening at: http://0.0.0.0:8000` | `-b 0.0.0.0:8000` |
| the .NET dashboard | `Now listening on: http://0.0.0.0:8080` (or `[::]`) | the image's default is right |

**Write down from each server:**
- its **PORT** - the number after the last `:` in the Running line (`5001`), the `port=` in its code;
- its **ROUTES** - `@app.route("/predict", methods=["POST"])` = the path `/predict`, called with POST.

---

## 3. Your table

A sheet of paper is enough. One row per program:

| Program | Name the others call (`--name`) | Listens on, inside | Routes | Calls (env var = address) |
|---|---|---|---|---|
| the API | `api` | 5001 | POST `/predict` | - |
| the toll | `toll` | - | - | `midurl` = `http://api:5001/predict` |
| the dashboard | `web` | 8080 | its pages | `AppSettings__ApiUrl` = `http://api:5001/predict` |

Every address in the last column is `http://` + a NAME from the second column + `:` + that program's port from the
third + a route from the fourth. This is the table the System Walkthrough asks for; it writes the commands from it.

---

## 4. The docker run line, piece by piece

```bat
docker run -d --name api --network system_net --restart unless-stopped ^
  --env-file "C:\...\xray-tools\runs\api\run.env" ^
  -e API_HOST=0.0.0.0 ^
  -p 15001:5001 ^
  api-naive
```

| Part | What it does |
|---|---|
| `-d` | in the background: the window is free again; `docker logs` shows its output |
| `--name api` | its NAME: what the other programs write in their addresses |
| `--network system_net` | the shared network, from the first second (`docker network create system_net` once) |
| `--restart unless-stopped` | back after a crash and when Docker starts |
| `--env-file run.env` | the program's own settings, one per line |
| `-e NAME=value` | one value; wins over the same name in the env file |
| `-p 15001:5001` | only to reach it from the PC (browser, Postman): PC port 15001 -> its port 5001 |
| `api-naive` | the image (build-naive made it) |

**The rules of an env file** (`--env-file`, X-Ray's run.env) - *tested*:

| You write | The program gets |
|---|---|
| `midurl=http://api:5001/predict` | `http://api:5001/predict` - right |
| `midurl="http://api:5001/predict"` | the quotes too: requests stops with `InvalidSchema: No connection adapters were found for '"http://api:5001/predict"'` |
| `B=value # a comment` | `value # a comment` - a comment after a value is part of the value |
| `C= spaced ` | ` spaced ` - the spaces too |
| `# D=off` | nothing: the line is off, the code's default counts |

One NAME=value per line, no quotes, no comment after a value. (Compose's `.env` is a different reader: it removes
quotes - that is why the .NET walkthrough's `.env` uses `'single quotes'` on purpose.)

---

## 5. Ports: inside the network, and from your PC

- **Inside the network** every container has its own addresses, so two programs can both listen on 5001. *Tested:*
  `http://api:5001` and `http://api2:5001` both answered `200`.
- **From your PC** each program needs its own PC port: `-p 15001:5001` for one, `-p 15002:5001` for the other.
  *Tested:* `http://localhost:15001` and `http://localhost:15002` both answered. A PC port used twice:
  `Bind for 0.0.0.0:15001 failed: port is already allocated`.
- **The other programs use the INSIDE port.** *Tested:* `http://api:15001` from the caller - `Connection refused`.
  The PC port is only for the browser, Postman, curl on the PC.
- A program only other containers call needs no `-p` at all - and is then not open to the office network either.

`docker ps` shows the mapping: `0.0.0.0:15001->5001/tcp` = PC port 15001 leads to its port 5001.

### 5.1 For now, without the network: IP addresses (*tested*)

Containers started without `--network` are all on Docker's default network. They reach each other by IP address
and the INSIDE port: `http://172.17.0.3:5011/pr`. That works, with four catches:

- **The addresses change.** A container gets the next free address when it starts. *Tested:* the same containers
  started again in another order (that is what a PC restart does) - every one had another address (api .4 -> .3,
  toll .5 -> .2), and a call went to the wrong program. After a PC restart, a Docker restart or a `docker rm` + `run`:
  look them up again.
- **Looking them up**, all at once:
  ```bat
  docker network inspect bridge -f "{{range .Containers}}{{.Name}} {{.IPv4Address}}{{println}}{{end}}"
  ```
  prints `anpr 172.17.0.3/16` per container - the address is the part before `/16`. (The older
  `docker inspect -f "{{.NetworkSettings.IPAddress}}" NAME` fails on Docker 29: `map has no entry for key "IPAddress"`.)
- **A program started with compose is on its own network** (`NAME_default`), and 172.17 addresses do not reach it.
  For now `network_mode: bridge` under the service puts it on the default network too (*tested*: reached at
  `172.17.0.2:8080`, its `ports:` still work). Or call it through its PC port from any container:
  `http://host.docker.internal:8090` (*tested*).
- **Your PC cannot open 172.17 addresses** (IIS, the browser, Postman): on Windows the containers live in Docker
  Desktop's own small Linux machine. A program something outside Docker calls needs `-p` (above).

With the network (section 4) the names never change - that is why it is the goal.

---

## 6. Changing a value

- `docker restart NAME` keeps the values it was created with. *Tested:* run.env changed, restart, `printenv` showed
  the old value.
- To change one: `docker rm -f NAME`, then its `docker run` line again (with the new `-e` or the edited run.env).
- To see what it has now: `docker exec NAME printenv midurl` (only that name - plain `printenv` shows passwords too).

---

## 7. After the network exists: what to look for, in this order

1. **The network:** `docker network ls` lists it.
2. **The programs:** `docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Networks}}"` - every program
   `Up`, every one on the network, PORTS only where you put `-p`.
3. **Each server's log** (`docker logs api`): `Running on all addresses (0.0.0.0)`.
4. **Each caller's address:** `docker exec toll printenv midurl` -> `http://api:5001/predict`: a NAME, the INSIDE port.
5. **The way there:** `docker exec toll python -c "import socket; socket.create_connection(('api', 5001), 5); print('open')"`
   -> `open`.
6. **The whole request:**
   `docker exec toll python -c "import requests; r = requests.post('http://api:5001/predict', json={}, timeout=5); print(r.status_code, r.reason)"`
   (*tested* answers):

   | Answer | Meaning |
   |---|---|
   | `200 OK` | right |
   | `405 METHOD NOT ALLOWED` | it got there; the route wants another method (a browser or a GET check on a POST route) - the network is fine |
   | `404 NOT FOUND` | it got there; the PATH is wrong - a typo, or one `/` more or less (`/predict/` gave 404) |
   | `500 INTERNAL SERVER ERROR` | it got there; the API failed inside - its log has the error |

7. **Both logs:** the caller prints its answers; Flask logs each request with the caller's address and the result:
   ```text
   172.18.0.3 - - [29/Oct/2026 06:37:22] "POST /predict HTTP/1.1" 200 -
   ```

---

## 8. The messages, and what they mean (*tested*)

| The caller says (requests / urllib) | Meaning | Where to look |
|---|---|---|
| `Failed to resolve 'api' ([Errno -2] Name or service not known)`, `gaierror(-2, ...)` | that NAME is not on the caller's network | `--name` and `--network` of both (section 4); run-naive.bat names a container `api-run`, not `api` |
| `[Errno 111] Connection refused` | the name answers, the port does not | the INSIDE port (not the PC port), or the server listens on 127.0.0.1 (section 2) |
| `Connection to 192.168.1.20 timed out`, `ConnectTimeout`, `timed out` | an address that leads nowhere | an old IP - the code's default is used (section 1) |
| `InvalidSchema: No connection adapters were found for '"http://...'`, `unknown url type: '"http'` | quotes around the value in the env file | section 4 |
| `405 METHOD NOT ALLOWED` | reached; another method | fine for the network (section 7) |
| `404 NOT FOUND` | reached; the path | the route (section 2) |
| the program still uses the old IP although you set the variable | the name's upper/lower case, or a changed value without a new container | sections 1 and 6 |
| the database gets the rows, the dashboard shows nothing | not a connection problem: what the rows contain (UTC times, paths) | EMPTY_DASHBOARD |
