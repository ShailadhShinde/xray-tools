# A .NET app in Docker, next to your ML images - what is the same, what is different

You already know how X-Ray turns a Python / ML project into a small image. A .NET dashboard or web API goes into
the same kind of box, but what goes in, and how, is different. This guide puts the two side by side.

It covers the Dockerfile line by line, requirements, compilers, secrets, `.dockerignore`, slow internet, and the
ports and addresses (who can reach what). It ends with the steps from `dotnet_check.py` to a running dashboard.

Every behaviour marked *tested* was run in containers for this guide; the messages quoted are the real ones.
Companion pages: DOTNET_WALKTHROUGH.html (the .NET steps to click through: a form writes your Dockerfile,
.dockerignore, compose.yml and .env), SERVICES_GUIDE (the whole system: .NET + database + ML in one compose), GUIDE.md
(X-Ray, step by step), MULTI_CLIENT_HOSTING (one server, many clients).

---

## 0. The picture: the same box, different contents

Both images are a small Linux system, a runtime, your program, and one line that starts it:

```text
ML image (Python)                              .NET image (a dashboard / web API)
---------------------------------------------  ---------------------------------------------
FROM python:3.11-slim  (GPU: nvidia/cuda)      FROM mcr.microsoft.com/dotnet/aspnet:8.0
apt-get: ffmpeg, libgomp1 ... (system libs)    (usually nothing)
pip install: torch, opencv, numpy ... (GBs)    (nothing: the packages are already DLLs in the publish folder)
COPY your .py files, models                    COPY the publish folder (DLLs, wwwroot, appsettings.json)
CMD ["python", "src/main.py"]                  ENTRYPOINT ["dotnet", "MyApp.dll"]
```

**The one big difference.** Python ships its SOURCE code and installs its libraries INSIDE the image while it is
built - so the Dockerfile has to know every package, and X-Ray has to find them (the code only says `import x`).

.NET is COMPILED before Docker sees it: "Publish" in Visual Studio (or `dotnet publish`) resolves every package and
writes it into the publish folder as a `.dll`. The Dockerfile only copies that folder onto a base image that has
the .NET runtime. Nothing is installed, nothing has to be found.

So most of X-Ray's work - which packages, which system libraries, CPU or GPU - simply does not exist for .NET. What
remains is checking that the compiled app fits Linux: `dotnet_check.py` does that in one read-only run.

---

## 1. Side by side

| | ML program (Python) | .NET app |
|---|---|---|
| What runs | `.py` source, read by `python` | a compiled `MyApp.dll`, run by `dotnet` (the .NET runtime) |
| The list of libraries | `requirements.txt` - often incomplete or too long; X-Ray finds the real list | the `.csproj` (`<PackageReference>`); after Publish `MyApp.deps.json` lists every package with its exact version |
| Where libraries come from | PyPI and torch's own index (pip), Debian (apt) | NuGet - only when you build from source; a publish folder already holds them |
| Installed when | `docker build` (pip install in the Dockerfile) | Publish, on your PC (or `dotnet publish` in the SDK stage) |
| Base image | `python:3.x-slim` (CPU), `nvidia/cuda` (GPU) | `dotnet/aspnet:8.0` (website / API), `dotnet/runtime:8.0` (console / worker); `dotnet/sdk:8.0` only to build - the KIND of program decides, not how it is hosted (section 13) |
| Typical size | base 190 MB; with torch and CUDA several GB (test project F3: 11.2 GB naive, 2.45 GB planned) | base about 320 MB + your publish folder (tens of MB; more when wwwroot holds photos or videos) |
| GPU | often (CUDA, `--gpus all`) | no - a dashboard never needs one |
| Compiler in the image | only during a pip install of a package with no ready wheel (gcc), removed in the same step | never: the SDK compiles in a separate stage; a publish folder needs none |
| Native (C / C++) parts | inside the pip wheels (opencv, torch `.so` files) - built for Linux | in `runtimes/<os>/native/` of the publish folder - sometimes Windows / macOS only (`dotnet_check` part 2) |
| Settings | `constants.py`, `.env`, `os.getenv` | `appsettings.json` + env vars that replace ANY key (`Section__Key`), no code change |
| Start line | `CMD ["python", "src/main.py"]` | `ENTRYPOINT ["dotnet", "MyApp.dll"]` - the `.dll`, not `MyApp.exe` |
| Listens on | what the code says (Flask: 127.0.0.1:5000 unless told otherwise) | port 8080 on every address (the .NET 8 image sets `ASPNETCORE_HTTP_PORTS=8080`) |
| Windows habits that break | `\` in paths, `C:\` paths, `cv2.imshow` windows | the same `\` and `C:\`, plus IIS / web.config, System.Drawing, Windows login |
| The checker | X-Ray: static map, naive build, a real run, the plan | `dotnet_check.py`: one read-only look at the folder |

**Why ML needs a real run and .NET does not.** Python decides at run time what it imports, which file it opens,
whether the GPU is there. Only a run shows it (X-Ray's Step 2). The .NET compiler already resolved every package
and every type before anything runs; what is left to check (versions, native files, settings, addresses) is
written in the publish folder.

---

## 2. How each Dockerfile is built, line by line

### 2.1 The ML Dockerfile (what X-Ray's plan writes)

A real one, from X-Ray's test project F3 (a video worker with torch and ffmpeg), shortened:

```dockerfile
FROM python:3.11-slim                                     # 1. Linux + Python
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1          #    no .pyc files; print() reaches the log at once
ARG DEBIAN_FRONTEND=noninteractive

RUN apt-get -o Acquire::Retries=5 update \
 && apt-get -o Acquire::Retries=5 install -y --no-install-recommends ffmpeg fonts-dejavu-core libgomp1 \
 && rm -rf /var/lib/apt/lists/*                            # 2. system libraries the run really loaded

WORKDIR /app
ARG PIP_DEFAULT_TIMEOUT=120                                # 3. slow internet (section 7)
ARG PIP_RETRIES=10
ARG PIP_RESUME_RETRIES=10
RUN --mount=type=cache,target=/root/.cache/pip pip install "pip>=25.1"
RUN --mount=type=cache,target=/root/.cache/pip pip install --extra-index-url https://download.pytorch.org/whl/cpu \
    torch==2.4.1+cpu onnxruntime==1.19.2 opencv-python-headless==4.10.0.84 numpy==2.0.2 ...
                                                           # 4. Python packages, each pinned to the version that ran
RUN useradd --create-home --uid 1000 app \
 && mkdir -p /data/output && chown -R app:app /data/output # 5. a user that is not root, and the folders it writes
COPY --chown=app:app src/ src/                             # 6. the code - last, it changes most often
COPY --chown=app:app weights/ weights/
USER app
CMD ["python", "src/main.py"]                              # 7. what runs
```

Why this order: Docker keeps every line as a **layer** and reuses it while the line and everything above it is
unchanged. So what changes least goes first (the base, system libraries, the big packages) and what changes most
goes last (your code). Edit a `.py` file and rebuild: only steps 6 and 7 run again - torch is not downloaded again.
X-Ray's Dockerfile.naive goes further and gives the biggest packages a pip line of their own (its part 3a).

### 2.2 The .NET Dockerfile from the PUBLISHED folder (a dashboard you publish in Visual Studio)

```dockerfile
ARG DOTNET_VERSION=8.0                                     # the "tfm" in MyApp.runtimeconfig.json: net8.0 -> 8.0
FROM mcr.microsoft.com/dotnet/aspnet:${DOTNET_VERSION}     # 1. Linux + the .NET runtime + ASP.NET Core
WORKDIR /app
COPY . .                                                   # 2. the whole publish folder (minus the .dockerignore lines)
EXPOSE 8080                                                #    a note only: the image listens on 8080
ENTRYPOINT ["dotnet", "MyApp.dll"]                         # 3. what runs
```

That is all. Compared with 2.1: no system libraries (the image has what ASP.NET Core needs), no package step (the
DLLs are in the folder), no compiler. The only additions are the ones `dotnet_check.py` asks for - a native library's
Linux build, the company's CA certificate, `libgdiplus` (SERVICES_GUIDE 2.4a, each tested).

The order rule is the same, it just has less to order: the base first, the app last.

### 2.3 The .NET Dockerfile from SOURCE (two stages)

```dockerfile
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build            # stage 1: the SDK = compiler + NuGet (about 1.2 GB)
WORKDIR /src
COPY *.csproj ./
RUN dotnet restore                                         # download the NuGet packages ("pip install" of .NET)
COPY . .
RUN dotnet publish -c Release -o /out -p:UseAppHost=false  # compile; writes the same kind of folder as Publish

FROM mcr.microsoft.com/dotnet/aspnet:8.0                   # stage 2: only the runtime - the image you keep
WORKDIR /app
COPY --from=build /out .                                   # only the compiled result crosses over
ENTRYPOINT ["dotnet", "MyApp.dll"]
```

Read it as two machines. The first has the compiler and builds. The second gets only the result, so the 1.2 GB
SDK never reaches the image you run.

ML does the same in one line when a package has to be compiled. X-Ray installs gcc, runs `pip install`, and removes
gcc again in the SAME `RUN`, so the compiler never becomes part of a layer. The idea is identical: tools for
building stay out of the image you run.

Same order rule: `COPY *.csproj` + `restore` before `COPY . .`, like `requirements.txt` before the code - editing a
`.cs` file does not download the packages again. (`example-stack/web/Dockerfile` is this file, with comments.)

### 2.4 The rules both follow

| Rule | ML | .NET |
|---|---|---|
| Rarely changing lines first, your code last | base, apt, pip, then `COPY src/` | base, then `COPY` (published); `restore` before `COPY . .` (source) |
| Clean up in the same `RUN` (a deleted file still fills the layer it was written in) | `rm -rf /var/lib/apt/lists/*` in the apt line | the same, if you add apt lines |
| Fixed versions | `torch==2.4.1+cpu`, `FROM python:3.11-slim` | `FROM aspnet:8.0` (8.0 = newest 8.0.x patch), packages fixed by the build |
| No secrets in the image | section 5 | section 5 |
| Not root | the plan adds user `app` | the image runs as root unless `USER app` (the user exists in the image); root is fine for a start |
| Writable folders are volumes | outputs, logs, videos | Logs, uploads, data-protection keys |

---

## 3. Requirements: how each side knows what to install

**ML.** The code says `import cv2`; the package is `opencv-python` (or `-headless`, or `-contrib` ...). The
requirements file comes from someone's PC: missing packages, extra ones, Windows-only pins. pip decides the versions
at build time, on Linux. That is why X-Ray needs four steps:
- a map of the imports (Step 1),
- a Linux check of every line of the requirements (`xray_naive.py`, with pip dry-runs),
- a run that records what was really loaded (Step 2),
- and a package scan that keeps only that (Steps 3 and 4).

**.NET.** The compiler resolved everything when you published. `MyApp.deps.json` names each package and version,
and each one is a `.dll` in the folder. There is nothing to decide at build time. What can still be missing on Linux
is exactly what `dotnet_check.py` part 2 lists:

1. **the runtime version**: the base image tag must match the app's (`net8.0` -> `aspnet:8.0`);
2. **native libraries for Linux**: a package that ships its C/C++ part only for Windows / macOS (SkiaSharp is the
   usual one);
3. **system libraries**: `libgdiplus` for an old System.Drawing.Common, `libfontconfig1` for some PDF / image packages;
4. **programs the app starts**: `ffmpeg.exe` has to become the Linux `ffmpeg`.

---

## 4. Compilers and build tools

**ML.** Most packages come as *wheels* - already compiled for Linux, nothing to build. When a package has no wheel for
Linux + your Python version, pip compiles it from source and needs `gcc` (sometimes `python3-dev`, or CUDA's `nvcc`).
`xray_naive.py` checks every requirement and lists these in `naive-check.txt`. The plan installs the compiler for
that one `RUN` and removes it again. The better fix is a version that has a wheel, and naive-check.txt names them.

**.NET.** The compiler is the SDK (C# compiler, NuGet, MSBuild): the `sdk` image, about 1.2 GB.
- **From source:** it is in stage 1 only (2.3).
- **From the publish folder:** Visual Studio already compiled on your PC, so no compiler is involved at all.
- **Native C/C++ parts** of a .NET package come already built for each OS, in `runtimes/linux-x64/native/` and so on.
  Nobody compiles them in Docker. If the Linux one is missing, you add the package that has it (SERVICES_GUIDE 2.4a).

---

## 5. Secrets and keys: where each side keeps them

The rule is the same on both sides: **everything COPY puts into an image can be read by anyone who has the image**.
That includes every layer, and a file deleted in a later line is still in the layer that added it. `docker history`
shows every `ARG` and `ENV` value. So passwords and keys never go into the Dockerfile or the image. They come at run
time: values from `.env` (compose reads it), files mounted read-only.

| What | ML program | .NET app | Into the container |
|---|---|---|---|
| database / API passwords | `.env`, or written in `constants.py` (X-Ray: a `secret` finding, code change) | `appsettings.json` `ConnectionStrings`, or web.config env vars (IIS) | an env var from `.env`: `ConnectionStrings__Default=...` (.NET reads it with no code change) |
| key / certificate files | `*.pem`, `*.key`, service-account JSON | the `.pfx` for HTTPS | mounted `:ro`; .NET: `Kestrel__Certificates__Default__Path` + `__Password` |
| licence | a licence file; a MAC address check | - | the file mounted; `mac_address:` in compose |
| keys the app makes itself | - | **data-protection keys** (they sign the login cookies) | a volume, so they survive a re-create (not secret to hide, but must persist) |
| development secrets | - | "user secrets" (`secrets.json` in your Windows profile) - only read in Development | never in an image; the same values as env vars |

`dotnet_check.py` prints passwords as `***`, flags a `.pfx` or a `keys/` folder that would go into the image, and
names the env var that replaces each appsettings value. X-Ray's map lists `secret` findings for ML code.

---

## 6. .dockerignore: what each side leaves out

`docker build` first sends the folder (the *build context*) to the builder; the `.dockerignore` lines are left out
of it. Three reasons: speed (less to send), size (less to COPY), safety (secrets and data never reach the image).

| Leave out | ML | .NET (publish folder) | .NET (source) |
|---|---|---|---|
| caches and build output | `__pycache__/`, `*.pyc`, `.venv/`, `venv/` | - | `**/bin/`, `**/obj/` (Windows build output that breaks `dotnet restore`), `.vs/`, `*.user` |
| builds for other systems | - | `runtimes/win*`, `runtimes/osx*` (Linux never loads them; keep `runtimes/linux*`, `runtimes/unix`) | - |
| data written at run time | `outputs/`, `logs/`, `runs/`, saved videos | `Logs/`, uploads, photos | the same |
| big inputs | datasets, test videos (mounted instead) | - | - |
| secrets | `.env`, `*.pem`, `*.key` | `*.pfx`, `keys/` | the same |
| old copies | - | `appsettings.Old.json`, `logo - Copy.png` (files under wwwroot can be downloaded by anyone) | the same |

X-Ray writes `Dockerfile.naive.dockerignore` and the plan's `Dockerfile.dockerignore`; `dotnet_check.py` prints the
lines for a .NET folder (part 9). Two details that hold for both: write names exactly as on disk, because `Logs/` and
`logs/` are different names. And a Dockerfile kept OUTSIDE the folder (`docker build -f`) reads
`<its name>.dockerignore` next to it - handy when every publish makes a new folder (tested).

---

## 7. Slow or unstable internet

Both sides download a lot while building. GUIDE 20 has the details. In short:

| Download | ML (X-Ray's Dockerfiles do this now) | .NET |
|---|---|---|
| packages | `ARG PIP_DEFAULT_TIMEOUT=120`, `PIP_RETRIES=10`, a pip that resumes a broken download, `--mount=type=cache` | from source only: NuGet retries + `--mount=type=cache` on restore and publish (`example-stack/web/Dockerfile`, tested) |
| system packages | `apt-get -o Acquire::Retries=5` | the same, if you add apt lines |
| base images | Docker Desktop > Settings > Docker Engine: `"max-concurrent-downloads": 1`, `"max-download-attempts": 10` | the same |

The NuGet lines in the SDK stage (tested with .NET 8):
```dockerfile
ENV NUGET_ENABLE_ENHANCED_HTTP_RETRY=true NUGET_ENHANCED_MAX_NETWORK_TRY_COUNT=10 \
    NUGET_ENHANCED_NETWORK_RETRY_DELAY_MILLISECONDS=2000
RUN --mount=type=cache,id=nuget,target=/root/.nuget/packages dotnet restore
COPY . .
RUN --mount=type=cache,id=nuget,target=/root/.nuget/packages dotnet publish -c Release -o /out -p:UseAppHost=false
```
The cache mount keeps what was downloaded OUTSIDE the image. Tested on the pip side: after a build broke off, the
next one said `Using cached numpy ... (16.3 MB)` and downloaded nothing. A publish folder needs no NuGet at all.

**A timeout is not the download time.** `PIP_DEFAULT_TIMEOUT` is how long pip waits when NO data comes. A slow but
steady download is never cut by it, so 120 s is plenty. 1000 only means waiting 17 minutes on a dead line before the
next try.

---

## 8. Ports, addresses, and who can reach what

The same rules for both. Everything below was tested with a Python server and the .NET test app in containers.

### 8.1 Three doors

```text
a client PC on the office network opens  http://SERVER-NAME:8080
   |
[3] the PC        the Windows firewall lets port 8080 in - or not
   |
[2] Docker        ports: "8080:8080"  =  PC port 8080 -> container port 8080
   |
[1] the program   listens on 0.0.0.0:8080 inside its container
```

1. **Where the program listens, inside its container**: an address and a port. `0.0.0.0` (also written `*`, `+`,
   `[::]`) = every network card of the container: anyone who can reach the container can connect. `127.0.0.1` /
   `localhost` = only programs in the SAME container.
2. **Which ports Docker opens on the PC** (`ports:` in compose, `-p` with docker run): `"8080:8080"` = PC port 8080
   leads to container port 8080. Without `ports:` there is no way in from outside Docker at all - other containers
   on the same network still connect directly.
3. **The PC itself**: the Windows firewall and the office network decide whether OTHER PCs reach that PC port.

A request has to pass all three. When something does not connect, find which door is shut (8.6).

### 8.2 Door 1: where the program listens - ML and .NET

| Program | Listens by default on | In a container you need |
|---|---|---|
| Flask `app.run()` | `127.0.0.1:5000` - only inside the container | `app.run(host="0.0.0.0", port=5000)` (X-Ray flags it: a `listen_port` on 127.0.0.1 = code change) |
| uvicorn (FastAPI) | `127.0.0.1:8000` | `uvicorn app:app --host 0.0.0.0 --port 8000` |
| gunicorn | `127.0.0.1:8000` | `gunicorn -b 0.0.0.0:8000 app:app` |
| .NET 8 image | every address, port 8080 (`ASPNETCORE_HTTP_PORTS=8080`) | nothing - unless the code or appsettings names `localhost` (`dotnet_check.py` part 3) |

*Tested.* A program listening on 127.0.0.1 inside a container, port published, called from the PC:
```text
curl: (56) Recv failure: Connection reset by peer
```
for a Python server and for the .NET app alike (`ASPNETCORE_URLS=http://localhost:8080`). On `0.0.0.0` both
answered. The .NET log says which one it is - check it first:
```text
Now listening on: http://localhost:8080      <- only inside its own container
Now listening on: http://0.0.0.0:8080        <- every address: right for a container
```
(`http://[::]:8080` means every address too: the same, written for IPv6.)

### 8.3 Door 2: what `ports:` really does

```yaml
services:
  web:                          # the dashboard
    ports:
      - "8080:8080"             # PC port 8080 -> container port 8080, on EVERY network card of the PC
  api:                          # an ML API only the dashboard calls
    # no ports: at all          # nothing outside Docker can reach it; web reaches it as http://api:8000
  admin:                        # a tool only for you, at the PC itself
    ports:
      - "127.0.0.1:9000:9000"   # only this PC (localhost); other PCs cannot
```

*Tested*, with exactly these three kinds:

| Who calls | Address | Result |
|---|---|---|
| another container in the same compose | `http://web:8080` (service name + CONTAINER port) | 200 |
| another container | `http://web:18120` (the PC port) | `Connection refused` - inside Docker the PC port means nothing |
| another container | `http://localhost:8080` | `Connection refused` - localhost is the caller itself |
| another container | `http://admin:8000` (published on 127.0.0.1) | 200 - publishing does not matter between containers |
| the PC itself | `http://localhost:18120` | 200 |
| via the PC's network address | `web` (published on all cards) | 200 |
| via the PC's network address | `admin` (published on 127.0.0.1) | `Couldn't connect to server` |

`docker compose ps` shows it: `0.0.0.0:18120->8080/tcp` (every card) against `127.0.0.1:18121->8000/tcp` (this PC
only). `EXPOSE` in a Dockerfile opens nothing: it is a note for people.

### 8.4 Who reaches what

| Who calls | The address they use | What it needs |
|---|---|---|
| the program itself, in the same container | `localhost:PORT` | nothing |
| another container in the same compose | `http://SERVICE:CONTAINER_PORT` | the program listens on 0.0.0.0; same network (same compose file, or a shared external network - SERVICES_GUIDE 4.7); **no** `ports:` |
| a browser on the PC that runs Docker | `http://localhost:PC_PORT` | `ports:` |
| a client PC on the office network (the dashboard's users) | `http://SERVER-NAME:PC_PORT` or `http://SERVER-IP:PC_PORT` | `ports:` without `127.0.0.1:`, and the Windows firewall lets that port in |
| a container calling a program on the PC (not in Docker, e.g. IIS) | `http://host.docker.internal:PORT` | the program on the PC listens where Docker reaches it (0.0.0.0 is safest); a Linux server needs `extra_hosts: ["host.docker.internal:host-gateway"]` |
| a container calling another machine on the office network | its IP or name, as the PC does | the same network path the PC has (Docker forwards through the PC) |
| a container calling the internet | as the PC does | the office proxy, if there is one, as env vars |

`SERVER-IP`: the PC's IPv4 address in `ipconfig`, on the office adapter.

### 8.5 The addresses you will see, and which to use

- **Container addresses (`172.18.0.3` ...)**: given anew on every re-create. Never write them into a setting - use
  the service name. Docker's own DNS answers it (tested: `web` resolved to `172.18.0.3`; tomorrow it may differ).
- **`0.0.0.0`**: as a LISTEN address = every card. As a destination it is wrong - call a name or a real address.
- **`127.0.0.1` / `localhost` in a container**: that container. A setting that says `localhost` for a database or
  an API is wrong in a container (both `dotnet_check.py` and X-Ray's map flag it).
- **`host.docker.internal`**: the PC that runs Docker (Docker Desktop provides the name).
- **The PC's LAN address**: what client PCs use. If the address can change (DHCP), use the PC's name.

### 8.6 "It does not connect" - find the shut door

Go from the inside out. The first step that fails is the door:

1. **Is the program listening, and where?** Its log: `Now listening on: http://0.0.0.0:8080` (.NET), `Running on
   http://127.0.0.1:5000` (Flask = wrong for a container). Or inside the container:
   `docker compose exec web bash -c "echo > /dev/tcp/127.0.0.1/8080 && echo open"` (the .NET image has bash but
   no curl - tested). Not open -> door 1 (the program, or its address).
2. **From another container:** `docker compose exec worker python -c "import urllib.request; print(urllib.request.urlopen('http://web:8080').status)"`.
   `Connection refused` -> the port: the CONTAINER port, not the PC port.
3. **From the PC:** `http://localhost:8080` in the browser. Fails while 2 works -> door 2 (`ports:`).
4. **From a client PC:** `http://SERVER-IP:8080`. Fails while 3 works -> door 3: the Windows firewall (no admin
   rights: ask IT for an inbound rule for that TCP port), or `ports:` starts with `127.0.0.1:`.

### 8.7 The client thing: open only the front door

- **Publish only what people open**: the dashboard (or the reverse proxy in front of it). The database, the ML APIs
  and the workers have no `ports:`. The dashboard reaches them by service name, and nobody on the network reaches
  them at all. A database you want to open with a tool on your own PC: `"127.0.0.1:5432:5432"`.
- **The dashboard on IIS, the ML API in Docker** (on the same PC): publish the API on this PC only,
  `"127.0.0.1:8000:8000"`. IIS calls `http://localhost:8000`; the office network cannot.
- **One network card only** (a PC in two networks): `"SERVER-IP:8080:8080"` publishes on that address alone.
- **Many clients on one server**: one proxy publishes 80/443, every client's API stays unpublished on its own network,
  and the proxy checks each client's key (MULTI_CLIENT_HOSTING).
- **HTTPS**: in front (the proxy, or IIS) or in the app (a mounted `.pfx`, SERVICES_GUIDE 2.2) - the ports rules stay
  the same.

---

## 9. Windows habits that break the same way on both sides

| Habit | ML (Python) | .NET | Fix |
|---|---|---|---|
| `\` in a path (`"out\\vehicle\\bus"`) | on Linux ONE folder named `out\vehicle\bus` (tested) | the same (`"Logs\\app.txt"` = one file name) | ML: `WIN_PATHS=1` with X-Ray's xray_inputs, no code change (GUIDE 17c); both: `/` or `os.path.join` / `Path.Combine` in the code |
| `C:\...` / `D:\...` in a setting | a folder no container has | the same | a Linux path in the env var + a volume; X-Ray maps PC paths (GUIDE 17b / 17c) |
| file names in another case | `Logo.PNG` asked as `logo.png`: not found | the same: 404 | the same case everywhere |
| windows on screen | `cv2.imshow`: `NO_WINDOWS=1` (GUIDE 16) | - | - |
| Windows-only APIs | `winreg`, `msvcrt` | the registry, event log, Windows login, System.Drawing 6+ | a code change; `dotnet_check.py` part 2 finds the .NET ones |

---

## 10. From dotnet_check to a running dashboard - what happens at each step

To do it, open **DOTNET_WALKTHROUGH.html** (in the tools folder): the same steps with your folders in the commands,
and a form that writes the four files from what `dotnet_check.py` found. This section says what happens behind each
step.

**Step 0 - Publish.** Visual Studio > Publish > Folder. In *Show all settings*: Configuration *Release*,
Deployment mode *Framework-dependent*, Target runtime *Portable*. (Self-contained or win-x64 works too, but
dotnet_check will ask you to look at it.) The result: a folder with `MyApp.dll`, `MyApp.runtimeconfig.json`,
`MyApp.deps.json`, `appsettings.json`, `wwwroot/`, `runtimes/`.

**Step 1 - Check it.**
```bat
python dotnet_check.py "D:\apps\myapp\publish-2026-06-19" > check.txt
notepad check.txt
```
It reads the files, runs nothing, and prints nine parts. Each finding says which file you write it into:

| Part | What it reads | It goes into |
|---|---|---|
| 1. app, version, end of support | runtimeconfig.json | Dockerfile `FROM` (and `DOTNET_ROLL_FORWARD`) |
| 2. Linux: Windows-only packages, native libraries | deps.json, `runtimes/` | Dockerfile (a Linux library stage, apt lines) |
| 3. port, HTTPS, web.config (IIS) | appsettings, web.config, the DLL's text | compose `ports:` and `environment:` |
| 4. database, addresses | appsettings, web.config, MyApp.dll.config, the DLL's text | compose `environment:` / `.env` |
| 5. data-protection keys | the DLL | compose `volumes:` |
| 6. programs, Windows paths, addresses the code names | the DLL's text | Dockerfile apt lines; compose `environment:` |
| 7. machine checks (MAC, name) | the DLL | compose `mac_address:` / `hostname:` |
| 8. the Dockerfile you have | the Dockerfile | - (a second run checks it) |
| 9. what goes into the image | every file of the folder | `Dockerfile.dockerignore` |

**Step 2 - One folder for the Docker files**, next to the publish folders, so it stays when you publish again:
```text
D:\apps\myapp\docker\
    Dockerfile                  (SERVICES_GUIDE 2.1 / 2.4a + what part 1, 2 and 6 asked for)
    Dockerfile.dockerignore     (the lines part 9 printed)
    compose.yml                 (ports, environment, volumes)
    .env                        (passwords - never in git)
```
A compose.yml for a dashboard:
```yaml
name: dashboard
services:
  web:
    build:
      context: ../publish-2026-06-19      # the published folder: change this line for each new publish
      dockerfile: ../docker/Dockerfile    # relative to the context
    ports:
      - "8080:8080"                       # people open http://SERVER-NAME:8080
    environment:
      ASPNETCORE_ENVIRONMENT: Production
      ConnectionStrings__Default: ${DB_CONNECTION}      # from .env
    volumes:
      - ./Logs:/app/Logs                  # what the app writes stays on the PC
      - dp-keys:/root/.aspnet/DataProtection-Keys     # logins survive a re-create
    restart: unless-stopped
volumes:
  dp-keys:
```

**Step 3 - Build: `docker compose build`.** Compose reads `compose.yml` and `.env` and sends the publish folder (minus
the ignore lines) to the builder. The first time, it downloads `aspnet:8.0`. Then it runs the Dockerfile line by line,
each line a layer, and names the image. This is what `build-naive.bat` / `build-slim.bat` do for an ML project.

**Step 4 - Start: `docker compose up -d`.** Compose creates the network `dashboard_default`, the volume `dp-keys`,
and the container, which runs `dotnet MyApp.dll`. Docker opens PC port 8080. `-d` = in the background.

**Step 5 - Check, from the inside out (8.6).**
```bat
docker compose ps
docker compose logs -f web
```
Look for `Now listening on: http://0.0.0.0:8080` and `Application started`. Then open
`http://localhost:8080` on the PC, then `http://SERVER-NAME:8080` from a client PC.

**Step 6 - A new version.** Publish into a new folder, change `context:` in compose.yml, then
`docker compose up -d --build`. Only the changed layers are built again. The old container is replaced; `Logs` and
`dp-keys` keep their content.

**Step 7 - Check the Dockerfile too.**
`python dotnet_check.py "D:\apps\myapp\publish-2026-06-19" --dockerfile "D:\apps\myapp\docker\Dockerfile"`. Part 8
then compares the image version and the .dll with the app. Part 9 reads `Dockerfile.dockerignore` next to the
Dockerfile, and the findings the Dockerfile already fixes are marked OK.

**The ML side, for comparison:** Step 1 map (`xray_static.py`) -> Dockerfile.naive (`xray_naive.py`) -> the run files
(`xray_runfile.py`) -> run-naive, run-step2 (a real run, traced) -> run-step3-4 (packages, the plan) -> build-slim,
run-slim -> the plan's `compose.yml`. More steps, because only a run shows what Python really needs.

---

## 11. Cheat sheet: the same command does the same thing on both sides

| You want | ML (X-Ray) | .NET |
|---|---|---|
| check before Docker | `xray_static.py`, `xray_naive.py` | `dotnet_check.py FOLDER` |
| build | `build-naive.bat`, `build-slim.bat` (they run `docker build`) | `docker compose build` |
| start / stop | `run-slim.bat`, or `docker compose up -d` / `down` | `docker compose up -d` / `down` |
| the log | `docker compose logs -f` | the same |
| a shell inside | `docker compose exec SERVICE bash` | the same (the .NET image has bash) |
| what is in the image | `xray_look.py --image` | `docker run --rm --entrypoint ls IMAGE -la /app` |
| image sizes | `compare-images.bat` | `docker images` |
| everything that could break on Linux | the needs report (`step2-needs.txt`) | the SUMMARY of `dotnet_check.py` |

---

## 12. web.config and IIS: what they did for the app, and what takes over in a container

On the old server IIS started the app (through the ASP.NET Core Module) and read `web.config` to know how. In a
container nothing reads `web.config`: Docker starts the app (`ENTRYPOINT`), and compose does the rest.
`dotnet_check.py` part 3 lists what the folder's `web.config` sets.

| In web.config / IIS | What it did | In the container |
|---|---|---|
| `<aspNetCore processPath="dotnet" arguments=".\MyApp.dll">` | how IIS starts the app | `ENTRYPOINT ["dotnet", "MyApp.dll"]` |
| `<environmentVariables>` | env vars IIS hands to the app | `environment:` in compose, a password from `.env` (12.1) |
| `hostingModel="inprocess"` / `outofprocess` | whether the app runs inside IIS's worker process | nothing: the app is the container's own process, Kestrel answers directly |
| `stdoutLogEnabled`, `stdoutLogFile=".\logs\stdout"` | the app's console output into files | `docker compose logs web` IS the console; log files the app writes itself: a volume |
| `requestTimeout` (out-of-process only, default 2 minutes) | IIS gave up on a slow request | no such limit in Kestrel: a long report keeps running (12.2) |
| `<requestLimits maxAllowedContentLength="...">` | the biggest upload IIS let through | Kestrel's own limit, 30,000,000 bytes (12.2) |
| `<rewrite>` rules (URL Rewrite: http to https, old addresses) | IIS changed addresses before the app saw them | a proxy in front (Caddy) or the app itself; open the old links once to check |
| Windows authentication (logins with Windows accounts) | IIS checked the Windows user | a Linux container has no IIS to do it: usually a code change (the app's own login, or the proxy) |
| the app pool (outside web.config: recycling, idle stop, identity) | IIS restarted and stopped the app | `restart: unless-stopped`; no idle stop, no recycling |

### 12.1 The env vars IIS gave the app - what each one does

They are SETTINGS. None of them limits data or users; the limits are in 12.2. The name says what it is:

| Name | What it does | In compose |
|---|---|---|
| `ASPNETCORE_ENVIRONMENT` | which `appsettings.<name>.json` is read on top of `appsettings.json`, and whether error pages show details (`Development`) | keep the value web.config had (usually `Production`) |
| `ConnectionStrings__NAME` | the database the app uses: replaces `ConnectionStrings:NAME` of appsettings.json | the name in `environment:`, the value in `.env`, with a server address a container reaches |
| `AppSettings__KEY` (any `Section__Key`) | one of the app's OWN settings, `Section:Key` of appsettings.json - whatever the code uses it for | look at the value: a folder -> a Linux path + a volume; an address -> a name a container reaches; anything else -> as it is |
| `ASPNETCORE_URLS`, `ASPNETCORE_HTTP_PORTS`, `ASPNETCORE_HTTPS_PORT` | where the app listens, where it sends people for https | usually leave out: the image listens on 8080; part 3 says when the app needs them |
| `ASPNETCORE_DETAILEDERRORS`, `Logging__LogLevel__Default` | more detail in error pages / in the log | only while you look for a problem |
| `ASPNETCORE_AUTO_RELOAD_WS_ENDPOINT`, `..._WS_KEY`, `..._VDIR`, `DOTNET_MODIFIABLE_ASSEMBLIES`, and `ASPNETCORE_HOSTINGSTARTUPASSEMBLIES` / `DOTNET_STARTUP_HOOKS` naming BrowserRefresh, BrowserLink or DeltaApplier | Visual Studio wrote them while it ran the app on IIS for debugging (hot reload) - not the app's settings | leave out. *Tested:* the first ones do nothing; the hosting one logs a `crit` line; `DOTNET_STARTUP_HOOKS` with its Windows path stops the app before it starts |

### 12.2 The limits: uploads, slow requests, users

**Uploads.** Without IIS, the app's own web server, Kestrel, takes at most 30,000,000 bytes (28.6 MB) in one
request. A bigger upload fails: the log says `Request body too large. The max request body size is 30000000 bytes.`,
the browser shows an error (413). An env var does not change it (tested); only the code does:
`builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = 200_000_000)`, or `[RequestSizeLimit(...)]`
on the upload action. (A form upload has a second limit in the code, 128 MB: `FormOptions.MultipartBodyLengthLimit`.)

"Upload the biggest file once" means:
1. Find the page where people upload (photos, videos, an Excel import).
2. Take the biggest file they really upload - the largest file in the upload folder on the old server is a good
   sample.
3. Upload it to the dashboard in the container.
4. It arrives (it shows up in the list or the folder): nothing to do. It fails: `docker compose logs web` shows the
   line above, and the code change is needed. Files under 28 MB never reach the limit.

A proxy in front has its own limit: Caddy sets none by default; nginx takes 1 MB unless `client_max_body_size`
says more.

**Slow requests.** IIS out-of-process cut a request after `requestTimeout` (2 minutes by default). Kestrel has no
such limit: a long report runs to its end.

**Users at the same time.** Nothing in web.config or the env vars limits them, and Kestrel has no connection limit by
default. In practice the CPU and RAM of the container (`docker stats`) and the database decide.

---

## 13. Which base image: the KIND of program, not the way it is hosted

The image is chosen by what the program is. How people reach it (directly, through Caddy, through IIS on another
machine) is decided outside the image, by `ports:` and the proxy. Measured on disk:

| Image | What is inside | For | Like in Python | On disk |
|---|---|---|---|---|
| `dotnet/runtime-deps:8.0` | Linux + the C libraries .NET needs, no .NET | a self-contained app (it brings its own .NET, like a PyInstaller .exe) | `debian:bookworm-slim` | 180 MB |
| `dotnet/runtime:8.0` | + the .NET runtime | a console program, a background worker - no web pages | `python:3.11-slim` (192 MB) | 286 MB |
| `dotnet/aspnet:8.0` | + ASP.NET Core: the web server (Kestrel), MVC, Razor pages | a dashboard, a website, a web API | `python:3.11-slim` with Flask / uvicorn already installed | 327 MB |
| `dotnet/sdk:8.0` | + the compiler and NuGet | only the build stage of a two-stage Dockerfile (2.3) | `python:3.11` (full, gcc) for building wheels | 1.25 GB |

- **How to tell:** `MyApp.runtimeconfig.json` lists `Microsoft.AspNetCore.App` -> aspnet; only `Microsoft.NETCore.App`
  -> runtime. `dotnet_check.py` part 1 says it: `a web app: needs ASP.NET Core`. A dashboard is always aspnet.
- **CPU / GPU:** the ML question has no .NET twin - a dashboard needs no GPU. The CPU kind (x86_64 or ARM) comes
  from the same tag automatically.

### 13.1 Smaller .NET images - only when size matters

Where the size is (the test app): the aspnet image 327 MB, the app 28 MB after the `.dockerignore` lines. The app is
rarely the problem, so the X-Ray kind of cleaning has little to find: Publish already keeps only what the app
references.

| Way | Saves (tested) | The catch |
|---|---|---|
| the `.dockerignore` lines of `dotnet_check` part 9 (no source needed) | app 67 -> 28 MB | none |
| with the source: `dotnet publish -c Release -r linux-x64 --self-contained false` | the same: 67 -> 28 MB, no `runtimes\` folder at all | the folder then runs only on x86_64 Linux |
| `aspnet:8.0-noble-chiseled` (Ubuntu, no shell, no apt, runs as user `app`) | 327 -> 163 MB | no shell: `docker exec ... bash` and the bash checks fail (`exec: "sh": executable file not found`); `TZ` is ignored (no time zones); the keys folder is `/home/app/.aspnet/DataProtection-Keys` |
| `aspnet:8.0-noble-chiseled-extra` | 327 -> 219 MB | no shell; `TZ` works |
| `aspnet:8.0-alpine` | 327 -> 159 MB | `TZ` is ignored until `apk add tzdata`; native libraries need their musl build (`linux-musl-x64`) |
| trimming (`PublishTrimmed`) | - | only for self-contained apps, and not for MVC / Razor apps (they find their code by reflection): not for a dashboard |

The test app started and answered on all three smaller images. Change the base only after everything works, and
test every page again.

---

## 14. .NET 8's end of support, when you only get the published folder

**What ends.** After 2026-11-10 Microsoft fixes no more security holes in .NET 8, and the `aspnet:8.0` image gets no
more updates. The app keeps running exactly as before; what grows is the list of known, unfixed holes (an image
scanner will show them).

**Three ways:**
1. **A .NET 10 publish** from whoever has the source: TargetFramework `net10.0`, packages updated, the same Publish.
   The lasting fix; in Docker only `DOTNET_VERSION=10.0` changes.
2. **Without a new publish:** the same published .NET 8 folder on the .NET 10 runtime - `ARG DOTNET_VERSION=10.0` and
   `ENV DOTNET_ROLL_FORWARD=Major` (the .NET walkthrough's "Run it on .NET 10"). Tested with the test app: it started
   on `aspnet:10.0`, answered `ok .NET 10.0.14`, drew with its native library and wrote its files. Without the ENV
   line it stops: `You must install or update .NET to run this application`.
3. **Stay on 8.0 for now:** it keeps working; plan 1 or 2.

**What can break with way 2** - why "test every page": .NET 9 and 10 removed or changed some old parts (BinaryFormatter
is gone - an ASP.NET Core 8 app has it switched off already: `EnableUnsafeBinaryFormatterSerialization: false` in its
runtimeconfig.json), a few ASP.NET Core behaviours changed, and some libraries check the version they run on. Most apps
run unchanged; the proof is using every page once: logins, reports and PDFs, uploads, exports, pictures - and reading
`docker compose logs web` for exceptions.

**Safely:** keep the 8.0 image as `previous` (the .NET walkthrough, step 10), build and start the 10.0 one, test,
and go back in seconds if a page fails. `docker compose exec web dotnet --list-runtimes` shows which .NET runs. The
10.0 image is Ubuntu 24.04 (8.0: Debian 12); an apt line such as libgdiplus works the same.
