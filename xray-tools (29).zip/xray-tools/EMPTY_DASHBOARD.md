# The database has the new rows, the dashboard shows nothing - check this, then that

The ML programs run in Docker and write into the database: you see the new rows in it. The dashboard - in IIS, and
the copy in Docker - shows nothing new. When the IIS dashboard, which did not change, shows nothing either, the cause
is almost always in WHAT the containers write, not in the dashboard. Go through the checks in this order; each takes
a few minutes. Everything marked *tested* was run here with MySQL, a Python program and the .NET test app in
containers.

---

## 1. The same database?

Three places must name the same server, port and database:

| Where | How to see it |
|---|---|
| where the dashboard reads | its connection string: `dotnet_check.py` part 4 prints it (appsettings.json, web.config, the DLL's text; passwords as `***`) |
| where each program writes | its run.env (or the default in its constants.py): the database host, port, name |
| where you looked | the connection you opened in MySQL Workbench / your SQL tool |

Typical catches: a test database (`dash_test`) and the real one (`dash`); the MySQL on this PC and the one on the
server. From a container, `localhost` / `127.0.0.1` is the container itself; this PC is `host.docker.internal`; another
machine keeps its IP.

---

## 2. Put an old row next to a new one - the most telling check

```sql
SELECT * FROM the_table ORDER BY id DESC LIMIT 10;
```
Compare a row the dashboard SHOWS (written before Docker, by the programs on your PC) with a new one from the
containers, column by column. What differs points to the cause:

| Differs | Typical new value | Why | Check |
|---|---|---|---|
| the time | 5:30 hours behind the old rows and the clock | the container's clock runs in UTC | 3 |
| an image or file path | `/xout/...`, `/app/...`, `/data/...`; or a file that is not in the dashboard's folder | saved inside the container, or the container's path written into the table | 4 |
| an id or a name (camera, lane, site, device) | a default value, or empty | a setting that came from the PC (a file, an env var) is not in run.env | the program's run.env |
| a status or flag | not what the old rows have | a step failed - a second API call, an upload | `docker logs NAME` |
| a column that was filled before | `NULL` | another program, or a call, did not get through | 5 |

*Tested*, the database on Indian time, one row from the PC and one from a program in a container without a time
zone:
```text
id  plate        created_at            image_path
2   MH12CD5678   2026-10-29 12:41:16   /xout/pc_out_1/plate_002.jpg                              <- from the container
1   MH12AB1234   2026-10-29 18:11:16   D:\Dashboard\wwwroot\root\vehicle\car\plate_001.jpg       <- from the PC
```
Two differences in one row: the time is 5:30 hours behind, and the path is one only the container knows.

---

## 3. The clock

```bat
docker exec NAME date
```
for each program. It must show your PC's time. 5:30 hours behind (in India) = the container runs in UTC.

**Why the dashboard then shows nothing** (*tested*): with the database's `NOW()` at 18:11, the container wrote 12:41.
A page of "the last hour" - like a live view - asked:
```sql
SELECT id, plate FROM detections WHERE created_at >= NOW() - INTERVAL 1 HOUR;
```
and got only the row from the PC. The container's row was in the table, five and a half hours "old". After the same
program got the time zone, its next row showed up in that query.

**The fix:**

| Program | Line | Why this form |
|---|---|---|
| the Python programs (naive or slim, CPU or GPU) | in each run.env: `TZ=IST-5:30` | works in every image (*tested*). `TZ=Asia/Kolkata` needs time zone files: python:slim images have them, the Ubuntu-based CUDA images do not - there it is ignored without a word (*tested*: still UTC) |
| the .NET dashboard in Docker | compose `environment:` `TZ: Asia/Kolkata` | .NET does not understand `IST-5:30` - it stayed on UTC (*tested*); the aspnet image has the zone files |

Then remove and start the containers again (`docker restart` does not read run.env again) and check `date` once more.
X-Ray writes this line by itself from now on: `xray_runfile.py` 0.2.13 puts this PC's time zone into run.env
(`TZ=IST-5:30` on a PC in India), the plan (0.1.19) into its `.env.example`.

**Rows already written in UTC** stay 5:30 hours behind. Leave them, or - after a backup, and only for the rows the
containers wrote - correct them once:
```sql
UPDATE detections SET created_at = created_at + INTERVAL 330 MINUTE WHERE id BETWEEN FIRST_ID AND LAST_ID;
```

---

## 4. The pictures and files the dashboard shows

The dashboard shows a picture from a path in the table: the path in the OLD rows says what it expects (for example
`D:\Dashboard\wwwroot\root\vehicle\car\plate_001.jpg`, a file in its own `wwwroot`). Two things must hold for a new row:

- **The file is in that folder of your PC.** A program in a container saves inside the container unless the folder is
  mounted. Find where the newest pictures went - every picture of the last 30 minutes, anywhere in the container:
  ```bat
  docker exec NAME sh -c "find / \( -path /proc -o -path /sys \) -prune -o \( -name '*.jpg' -o -name '*.png' \) -mmin -30 -ls 2>/dev/null"
  ```
  A path under `/app`, `/xout`, `/data` that is not a mounted PC folder: the file stays in the container.
- **The table gets the path the dashboard understands** - the same Windows path as the old rows, not a container
  path. So do NOT point the program's folder setting at a container path (`OUTPUT_DIR=/data/out`) when it writes that
  path into the table: the dashboard would get `/data/out/plate.jpg`.

The way that keeps both (GUIDE.md 17c): mount the dashboard's folder, and let X-Ray's `xray_inputs` map the code's own
Windows path to it - the code keeps writing `D:\Dashboard\...` into the table, and the file lands in that PC folder
(*tested* with this very line: the program reported `D:\Dashboard\wwwroot\root\vehicle\car/plate_003.jpg`, and the
file was in the PC folder's `vehicle\car`):
```bat
docker run ... ^
  -v "D:\Dashboard\wwwroot\root:/data/root" ^
  -v "C:\...\xray-tools\xray_inputs:/opt/xray-inputs:ro" -e PYTHONPATH=/opt/xray-inputs ^
  -e "PC_PATHS=D:\Dashboard\wwwroot\root=/data/root" ^
  -e WIN_PATHS=1 ^
  NAME-naive
```
The `xray_inputs` part with its `-e PYTHONPATH=...`: copy it from the program's run-naive.bat - X-Ray wrote it there
for that image (with the image's own PYTHONPATH after the `:`, when it has one).
One detail from 17c: in the container the file name is joined with `/` (`...\car/plate_003.jpg`). Windows and the
dashboard on Windows accept it; compare the new row's path with an old one once.

---

## 5. Does the dashboard need a call, not only the database?

Some dashboards show what a program SENDS them (an upload, a notify address), not only what they read from the
database - a picture uploaded to the dashboard, a "new detection" message. In the old setup the program called the
dashboard's address. From a container that address must be one the container reaches:

| The dashboard runs | The address in the program's run.env |
|---|---|
| in IIS on this PC | `http://host.docker.internal:IIS_PORT/...` (or this PC's network IP) - never `localhost` |
| in Docker, on the same network as the program | `http://web:8080/...` - its name and its port inside (SYSTEM_WALKTHROUGH) |
| in Docker, not on that network | `http://host.docker.internal:PC_PORT/...` - the PC port of its `ports:` line |

Check from inside the program: its log (`docker logs NAME`) for errors on that address, then the way there:
```bat
docker exec NAME python -c "import socket; socket.create_connection(('host.docker.internal', IIS_PORT), 5); print('open')"
```
`open` = the network is fine. `timed out` with IIS on this PC: the Windows firewall (IT). The messages and what they
mean: CONNECTIONS_GUIDE section 8.

**The other way round: the dashboard calls a program.** An address in its appsettings.json or web.config (an API
the dashboard reads its data from, e.g. `http://localhost:5014/...`) now leads to a program in Docker. That program
answers on the PC only with `-p 5014:5014` in its docker run - *tested*: without `-p` the PC got no answer, with it
the answer came. Then:

| The dashboard runs | Its setting |
|---|---|
| in IIS on this PC | stays as it was (`localhost:5014` reaches the `-p` port) |
| in Docker | the WHOLE address, only the host changed: `http://host.docker.internal:5014/...` (the program's PC port), or on one network `http://NAME:5014/...` - never just `host.docker.internal` |

---

## 6. See what the dashboard asks the database

When checks 1 to 5 find nothing: MySQL can show the exact SELECT the dashboard sends (*tested*). As an admin user
(root), in Workbench:
```sql
SET GLOBAL log_output = 'TABLE';
SET GLOBAL general_log = 'ON';
-- now open the dashboard page once, then:
SELECT event_time, argument FROM mysql.general_log
 WHERE command_type = 'Query' AND argument LIKE 'SELECT%'
 ORDER BY event_time DESC LIMIT 20;
SET GLOBAL general_log = 'OFF';
```
```text
event_time                   argument
2026-10-29 18:11:29.941749   SELECT id, plate, created_at, image_path FROM detections WHERE created_at >= NOW() - INTERVAL 1 HOUR ORDER BY created_at DESC
```
Run that SELECT yourself. No new rows: its `WHERE` says why - a time window (check 3), a camera or site id (check 2),
a status, or a `JOIN` with another table that has no new rows (check 5). Switch the log off again: it records every
query.

---

## 7. Shown, but not refreshed

The browser keeps the old page: Ctrl+F5. A page that refreshes every few minutes: wait one round. A dashboard that
keeps data in memory: restart it (IIS: recycle its app pool; Docker: `docker compose restart web`).

---

## 8. The dashboard in Docker, next to IIS

Both can run at the same time - another PC port, the same database, the same picture folder:

```yaml
name: dashboard
services:
  web:
    build:
      context: ../publish-2026-06-19
      dockerfile: ../docker/Dockerfile
    image: dashboard
    ports:
      - "8090:8080"                      # PC port 8090 (IIS keeps its own); the app's port inside stays 8080
    environment:
      ASPNETCORE_ENVIRONMENT: Production
      TZ: Asia/Kolkata                   # the dashboard's clock - the .NET form of the time zone
      ConnectionStrings__Main: ${ConnectionStrings__Main}    # the SAME database as the IIS dashboard, from .env
    volumes:
      - "D:/Dashboard/wwwroot/root:/app/wwwroot/root"        # the SAME picture folder the programs write into
      - dp-keys:/root/.aspnet/DataProtection-Keys
    restart: unless-stopped
volumes:
  dp-keys:
```
- **The PC port** (left of `:`) must be free: not the one IIS uses. People open `http://SERVER:8090`.
- **The connection string** in `.env`: the one from web.config / appsettings.json (dotnet_check part 4), with a
  server address a container reaches - a MySQL on this PC is `host.docker.internal`, another machine keeps its IP. If
  MySQL answers `Access denied for user 'app'@'172.19.0.4'` (*tested*), that user may log in only from localhost: the
  address after `@` is what MySQL sees, and the user needs a version for it (`'app'@'%'` - whoever manages the database).
- **The folder** on the left of the volume is the one the programs save into (check 4); the right side is where the
  dashboard looks inside the container (`/app` + its folder under wwwroot).
- **The programs still on the default network** (started without `--network`, called by 172.17 addresses): add
  `network_mode: bridge` under `web:` so the dashboard is on their network too (CONNECTIONS_GUIDE 5.1).
- **Only the dashboard's own settings** go under `environment:` - the names in its appsettings.json and web.config.
  The programs' names (their run.env) do nothing here, and Visual Studio's `ASPNETCORE_AUTO_RELOAD_...` lines stay
  out (dotnet_check marks them).
- The setting names (`ConnectionStrings__Main`, `AppSettings__...`) are the ones dotnet_check prints. The .NET
  walkthrough writes this whole file from its form: PC port, Settings, Secrets, "Folders the app writes"
  (`wwwroot/root = D:\Dashboard\wwwroot\root`) and Time zone.

---

## The short version

1. Same server, port and database in the dashboard, in the programs' run.env, and where you looked.
2. An old row next to a new one: time, path, ids, status, empty columns.
3. `docker exec NAME date` = the PC's time; else `TZ=IST-5:30` in run.env, `TZ: Asia/Kolkata` for the .NET dashboard.
4. Pictures in the dashboard's folder, the Windows path in the table: mount + `PC_PATHS`.
5. Calls to the dashboard: `host.docker.internal`, not localhost. Calls from the dashboard to a program: that
   program needs `-p`.
6. Still nothing: MySQL's general log shows the dashboard's own SELECT.
