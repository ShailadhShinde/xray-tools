# X-Ray on Linux (Ubuntu)

The X-Ray tools are made for Windows and Linux alike: the same Python files, Python's standard library only. On Linux they write bash run files (`run-naive.sh`) where Windows gets `run-naive.bat`, and every message names the right file. What changes for you is how Docker is installed, a few command words, and one file, `pc-map.txt`, that says where the Windows folders your code names (`C:\...`, `D:\...`) are on the Linux PC. Your code does not change.

*Tested* on Ubuntu 24.04 with Docker 29, as a normal user (not root, in the `docker` group). The test project's code names a model on `C:\` (an `os.getenv` default), a video on `C:\` (in a config list) and a `D:\` folder it saves into. It went through every step to `VERDICT: PASS` without a code change, and every file the runs wrote belonged to the user. Not tested here: the GPU (the test machine has none) and program windows on a Linux desktop.

---

## 0. What is the same, what is different

| | Windows | Linux (Ubuntu) |
|---|---|---|
| Python | `python xray_static.py ...` | `python3 xray_static.py ...` (or `python` inside the venv of section 1) |
| run files | `run-naive.bat` | `bash run-naive.sh` (the files are not executable, so start them with `bash`) |
| folders | `C:\Users\me\xray-tools` | `/home/me/xray-tools` (`~/xray-tools`) |
| Docker | Docker Desktop | Docker Engine with the compose plugin, a service that starts at boot (section 1) |
| GPU in containers | NVIDIA driver + Docker Desktop (WSL 2) | NVIDIA driver + NVIDIA Container Toolkit (section 1) |
| editing a file | Notepad | `nano FILE`, gedit or VS Code |
| `C:\...` paths in your code | found where they are | found through `pc-map.txt` (section 3) |
| files the runs write | yours | yours: the tools hand back what containers wrote as root (section 5) |
| program windows (`cv2.imshow`) | `run-window.bat` (WSLg) | `run-window.sh` (your desktop's X server, section 7) |

Everything that runs inside the containers is identical, because a container is Linux on Windows too: the images, the Dockerfiles X-Ray writes, the trace, the package scan and the verify.

---

## 1. Set up the Ubuntu PC once

**Docker Engine and compose** (Docker's own packages; Ubuntu's `docker.io` + `docker-compose-v2` work too, only older):

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

**Docker without `sudo`:** put yourself in the `docker` group, then log out and in once (or type `newgrp docker` in the open terminal).

```bash
sudo usermod -aG docker $USER
docker ps
```

`docker ps` must answer without "permission denied". Never run the run files with `sudo`. Everything they write would then belong to root, and the tools could not hand it back to you.

**Python for the tools:** Ubuntu has `python3`. `xray_naive.py` also needs pip, to check your requirements against PyPI. Ubuntu 24.04 refuses `pip install` outside a virtual environment ("externally-managed-environment"), so give the tools their own venv, once:

```bash
sudo apt-get install -y python3-venv python3-pip
python3 -m venv ~/xray-venv
~/xray-venv/bin/python -m pip install -U pip
source ~/xray-venv/bin/activate
```

After `source ...activate`, `python` and `pip` in that terminal are the venv's, so the commands look exactly as on Windows (`python xray_static.py ...`). Activate it again in each new terminal, or always type `~/xray-venv/bin/python`. X-Ray installs nothing into it except the newer pip (*tested*: with pip 24.0 from Ubuntu, `xray_naive.py` warns that Requires-Python is checked against the wrong Python; in the venv with the new pip the warning is gone).

**The NVIDIA GPU** (GPU projects only): the driver, then NVIDIA's Container Toolkit, which lets containers use the card.

```bash
sudo ubuntu-drivers install
sudo reboot
nvidia-smi
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
docker run --rm --gpus all ubuntu nvidia-smi
```

The last line must print the same table as `nvidia-smi` on the PC: then `--gpus all` in the run files works.

**The tools:** clone your xray-tools repo (or unzip `xray-tools.zip`) into your home folder:

```bash
git clone https://github.com/YOUR-NAME/xray-tools.git ~/xray-tools
cd ~/xray-tools
```

Everything below runs from `~/xray-tools`.

---

## 2. Bring your projects and data over

- **The code:** copy each project folder to the Linux PC (git, a USB disk, `scp`), for example to `~/projects/anpr`.
- **The data the code names** (models, videos, config files on `C:\` or `D:\`): copy them to Linux folders of your choice, for example `~/data/models`, `~/data/videos`. Section 3 tells X-Ray where they went.
- **The `runs` folders made on Windows:** start again on Linux. Their JSON and run files hold Windows paths (`C:\...\project`) and `.bat` files. Run the steps of section 4 again: the analysis is the same, it is only the paths that differ.
- **Settings files you wrote on Windows** (a `.env`, a `run.env` you changed): Notepad ends lines with `\r\n`. In an env file the `\r` becomes part of the value, so a path or password no longer matches. Fix such a file once:

  ```bash
  sed -i 's/\r$//' FILE
  ```

  The tools themselves write Linux line ends. Python code with Windows line ends runs as it is.

---

## 3. Your code's Windows paths: `pc-map.txt`

Code written on Windows names files by where they were on that PC:

```python
MODEL = os.getenv("MODEL_PATH", r"C:\Users\me\models\plate.onnx")      # a default
VIDEOS = [r"C:\Users\me\Desktop\videos\lane1.mp4"]                    # a config list
SAVE_DIR = r"D:\output\frames"                                         # a folder it saves into
```

A Linux PC has no `C:\`. So X-Ray cannot find the model or the video, and cannot mount them into the runs. Tell it where you copied them: `pc-map.txt` in the tools folder, one line per folder, WINDOWS FOLDER = LINUX FOLDER:

```text
# Windows folder (as the code writes it) = the same folder on this Linux PC
C:\Users\me\models = /home/me/data/models
C:\Users\me\Desktop\videos = /home/me/data/videos
```

- Write it **before Step 1**. Step 1 then finds the files ("NOT on the PC" warnings disappear), and `xray_naive.py`, `xray_runfile.py` and `xray_plan.py` use the Linux folders.
- One line covers everything below that folder: `C:\Users\me = /home/me/data` maps `C:\Users\me\models\plate.onnx` to `/home/me/data/models/plate.onnx`. When two lines match, the longer folder wins.
- Upper and lower case, and `\` against `/`, do not matter on the Windows side, as on Windows.
- **The other way to add a line:** `python3 xray_runfile.py ... --map "C:\Users\me\models=/home/me/data/models"` adds it to the file.
- **Under WSL** (Ubuntu inside Windows) nothing is needed: `C:\` is `/mnt/c` there, and X-Ray uses that by itself.
- **It stays on this PC:** `pc-map.txt` names your folders, so the tools' `.gitignore` keeps it out of git.

What X-Ray then does with each kind of path. Your code keeps its own text throughout; *tested* with the three lines above:

| In the code | On Linux, with `pc-map.txt` |
|---|---|
| an `os.getenv` default that is a file (`MODEL_PATH`) | the Linux folder is mounted, or copied into the image when small. The env var gets the path inside the container |
| a file named in a list, dict or constant (`VIDEOS`) | the Linux file is mounted at `/xin/pc_1/...`. `PC_PATHS` maps the code's `C:\...` text to it (`xray_inputs`, GUIDE 17b) |
| a folder the code saves into (`SAVE_DIR`) | nothing to map: it lands in the run's out folder `runs/NAME/out/pc_out_1` (GUIDE 17c) |
| a path with no line in `pc-map.txt` | the run files print a `CHECK` line naming the folder to add. Add it, then run `xray_runfile.py` again |

**For production** (`xray_plan.py`'s `compose.yml` and `.env.example` in `runs/NAME/plan`):
- **Inputs:** the input folders are the Linux ones from `pc-map.txt`.
- **A folder the code saves into, with no line:** it becomes `./pc_out_1` next to `compose.yml`. A comment in `.env.example` says what to write there.
- **Folders next to `compose.yml`:** the plan makes them itself, as yours. A folder Docker makes belongs to root, and the slim image's program (user 1000) could not write into it (*tested*).
- **An absolute folder you write into `.env`** (`PC_OUT_1=/srv/out`) must exist and belong to user 1000: `sudo mkdir -p /srv/out && sudo chown 1000:1000 /srv/out`.

---

## 4. The steps, with the Linux commands

The same order as the walkthrough and GUIDE.md. Exactly this sequence ran in the test (with `--cpu`):

```bash
cd ~/xray-tools
mkdir -p runs/app
python3 xray_static.py --root ~/projects/app --entry main.py --requirements requirements.txt --out runs/app/app.json 2>&1 | tee runs/app/step1.log
python3 xray_needs.py runs/app/app.json 2>&1 | tee runs/app/step1-needs.log
python3 xray_naive.py --project ~/projects/app --requirements requirements.txt --entry main.py --name app --gpu --static runs/app/app.json
cp runs/app/naive/Dockerfile.naive runs/app/naive/Dockerfile.naive.dockerignore runs/app/naive/requirements.docker.txt ~/projects/app/
python3 xray_runfile.py --static runs/app/app.json --project ~/projects/app --name app
cd runs/app
bash build-naive.sh
bash run-naive.sh
bash run-step2.sh
bash run-step3-4.sh
bash build-slim.sh
bash run-slim.sh
tail -1 verify.txt
```

- **`app`:** your project's short name. `--gpu` is for a GPU program, `--cpu` for a CPU one.
- **`xray_naive.py`** writes into `runs/app/naive/`. Copy those three files into the project (the `cp` line), as on Windows.
- **`xray_runfile.py`** prints the files it wrote and the order to run them in. Read `code-changes.txt` first, as on Windows.
- **The verdict:** `verify.txt` must end with `VERDICT: PASS`.
- **Every other run file works the same way:** `bash run-explore.sh`, `bash run-load.sh A`, `bash compare-images.sh`, `bash videos.sh ~/data/videos`.

---

## 5. Files the runs write are yours

A container usually runs its program as root. On Windows that does not matter. On Linux, files a container writes into a folder of your PC would belong to root, and you could not edit or delete them without `sudo`. The tools hand them back to you:

- `xray_trace.py` (step 2, slim, load and explore runs), `xray_pkg.py`, `xray_look.py` and `xray_videos.py` give root's files back to the owner of the folder when they finish.
- **`run-naive.sh`** runs no X-Ray inside, so it ends with one `chown` in the same image.

*Tested*: after build, naive, step 2, steps 3-4, slim and compare-images, every file in `runs/app` belonged to the user. Deleting a folder needed no `sudo`.

Two cases need one command:
- **Older runs** (made before this version), or a run stopped with Ctrl+C before the end.
- **A user id other than 1000:** `id -u` prints it. The slim image's program runs as user 1000, and the first user of an Ubuntu PC is 1000.

```bash
sudo chown -R $USER:$USER ~/xray-tools/runs/app
```

---

## 6. The other guides' Windows commands, in Linux form

The walkthrough pages and GUIDE.md write many commands for Windows CMD. The Linux form of each:

| In a guide (Windows CMD) | On Linux (bash) |
|---|---|
| `python xray_static.py ...` | `python3 xray_static.py ...` |
| `cd /d D:\xray-tools` | `cd ~/xray-tools` |
| `run-naive.bat` | `bash run-naive.sh` |
| `runs\app\step2-needs.txt` | `runs/app/step2-needs.txt` |
| `notepad FILE` | `nano FILE` (or gedit, `code FILE`) |
| `type FILE` | `cat FILE` |
| `dir /b` | `ls` |
| `findstr TEXT FILE` | `grep TEXT FILE` |
| `copy A B` / `xcopy /E /I A B` | `cp A B` / `cp -r A B` |
| `del FILE` / `rmdir /s /q DIR` | `rm FILE` / `rm -r DIR` |
| `set NAME=value` | `export NAME=value` |
| `%NAME%`, `%CD%` | `$NAME`, `$PWD` |
| `^` at the end of a line (continues the command) | `\` at the end of a line |
| `where python` | `which python3` |
| `ipconfig` | `hostname -I` (or `ip -4 addr`) |
| `-v "C:\data:/data"` | `-v "/home/me/data:/data"` |
| `chcp 65001` | not needed: the terminal is UTF-8 |
| Docker Desktop: Settings > Resources (memory, CPUs) | not needed: containers use the whole PC (limit them with `--memory`, `--cpus`) |
| Docker Desktop: "start when you sign in" | `sudo systemctl enable --now docker`: Docker starts at boot, with or without a user signed in |

Lines meant for INSIDE a container (`docker exec -it NAME bash`, then `ls /app`, `ldd`, `$LD_LIBRARY_PATH` ...) are the same everywhere: they were always Linux.

---

## 7. GPU, program windows, cameras

- **GPU:** once the Toolkit of section 1 works (`docker run --rm --gpus all ubuntu nvidia-smi`), the run files' `--gpus all` and the compose files' `deploy: ... devices` work as on Windows. Docker Desktop on Windows shares the card through WSL 2; on Linux the Toolkit does it.
- **Program windows** (`cv2.imshow`, `run-window.sh`): the container draws on your desktop through the X server's socket (`/tmp/.X11-unix`, `DISPLAY`). Start it from a terminal of the desktop session, not over SSH. The run file allows local containers with `xhost +local:` when `xhost` is installed (`sudo apt-get install -y x11-xserver-utils`). Ubuntu's default Wayland desktop runs XWayland for this. A container without a screen still needs the windows switched off: `NO_WINDOWS=1`, GUIDE 16, the same as on Windows.
- **Cameras:**
  - `rtsp://` cameras work the same.
  - A USB camera is a device on Linux: add `--device /dev/video0` to the `docker run` line of the run file (GUIDE 18.3).
  - `SOURCE` (GUIDE 17a) takes Linux paths: `SOURCE="/home/me/data/videos"`.

---

## 8. Hosting clients and combining images on Linux

- **`xray_clients.py`** (CLIENT_HOSTING.md) was tested on this Linux PC end to end: four clients, keys, passwords, isolation, updates, backups. It also gives the folders the programs write to the user the image runs as. CLIENT_HOSTING.md section 14 has the Linux commands: `python3`, `/srv/hosting`, `sudo ufw allow 8441:8460/tcp`, `systemctl enable docker`.
- **`xray_combine.py`** (COMBINE_GUIDE.md) writes `run-combined.sh` next to each program's `run-slim.sh`. The combined image is the same on both systems.

---

## 9. When something goes wrong

| You see | Why | Do |
|---|---|---|
| `permission denied while trying to connect to the Docker daemon socket` | you are not in the `docker` group yet | section 1: `sudo usermod -aG docker $USER`, then log out and in |
| `bash: ./run-naive.sh: Permission denied` | the run files are not executable | `bash run-naive.sh` |
| `CHECK ... a Windows path - on this Linux PC write where that folder is into pc-map.txt` | no line for that folder | add the line (section 3), run `xray_runfile.py` again |
| the program in the container: `No such file or directory: 'C:\...'` | that path has no line, or the file is not where the line says | `pc-map.txt`; `ls` the Linux folder |
| `No module named pip` (xray_naive.py) | Ubuntu's Python without pip | section 1: the venv |
| `error: externally-managed-environment` | `pip install` into Ubuntu's own Python | section 1: the venv |
| `could not select device driver "" with capabilities: [[gpu]]` | the NVIDIA Container Toolkit is missing or not configured | section 1, the GPU block |
| `Permission denied` deleting something in `runs/` | older runs, or your user id is not 1000 | `sudo chown -R $USER:$USER ~/xray-tools/runs/NAME` |
| `$'\r': command not found`, or a value with an odd character at the end | a file edited in Windows' Notepad | `sed -i 's/\r$//' FILE` |
| `cannot open display` (run-window.sh) | not started from the desktop session, or X refuses containers | open the terminal on the desktop; `xhost +local:` |
| `python: command not found` | Ubuntu's command is `python3` | `python3`, or the venv (section 1), or `sudo apt-get install python-is-python3` |

---

## 10. What changed in the tools for Linux

| Tool | Version | Change |
|---|---|---|
| `xray_runfile.py` | 0.2.14 | `pc-map.txt` + `--map` (`C:\...` found on Linux, `/mnt/c` under WSL); mounts use the Linux folders; `run-naive.sh` gives its files back; run files pass `--naive-image` to the plan |
| `xray_static.py` | 0.5.19 | a file of the PC is looked up through `pc-map.txt` |
| `xray_needs.py` | 0.1.17 | on Linux, "not on this PC" points to `pc-map.txt` |
| `xray_naive.py` | 0.4.10 | uses the mapped folders; `build-naive.sh` and `$PWD` in its text on Linux; a project with no packages no longer stops the check; the pip warning gives the Ubuntu fix |
| `xray_plan.py` | 0.1.20 | the Linux folders in `compose.yml` / `.env.example`, and the folders next to `compose.yml` made as yours; files the naive Dockerfile copied from the PC are taken from the naive image (`COPY --from=NAME-naive`), so the slim image has them too, on Windows as well |
| `xray_trace.py` | 0.2.10 | gives back the whole out folder and the test folders, not only its own files |
| `xray_look.py`, `xray_videos.py` | 0.1.6, 0.2.1 | give back what they write as root |
| `xray_combine.py` | 0.1.4 | names `.sh` files on Linux; files of the PC built into a program's image (`/xin/...`) are taken into the combined image too (before, a program that read such a file failed there, on Windows as well) |
