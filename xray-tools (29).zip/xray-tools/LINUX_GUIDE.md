# X-Ray on Linux (Ubuntu)

The X-Ray tools are made for Windows and Linux alike: the same Python files, Python's standard library only. On Linux they write bash run files (`run-naive.sh`) where Windows gets `run-naive.bat`, and every message names the right file. What changes for you is how Docker is installed and a few command words. For the paths your code names there are two ways (section 3): change them to where the files are on the Linux PC - X-Ray then mounts each one at the same path, with nothing to set - or keep the Windows paths (`C:\...`, `D:\...`) and write in one file, `pc-map.txt`, where those folders are now.

**Step by step, with your folders filled into every command: `LINUX_WALKTHROUGH.html`** in the tools folder - the checks, the installs, the paths, every X-Ray step and `docker compose`, with what each printed on the test PC. This guide is the reference behind it.

*Tested* on Ubuntu 24.04 with Docker 29, as a normal user (not root, in the `docker` group), both ways:
- **Linux paths in the code:** a video in the home folder, a model on a second disk (`/mnt/...`), a log folder and an image folder the program creates itself - written as constants, and again as `os.getenv` defaults. Every step to `VERDICT: PASS`, then `docker compose up` with the plan's `compose.yml`: the program read its inputs and wrote into the real folders. Also two such programs in one combined image.
- **Windows paths kept, with `pc-map.txt`:** a model on `C:\` (an `os.getenv` default), a video on `C:\` (in a config list) and a `D:\` folder it saves into. Every step to `VERDICT: PASS`, without a code change.

Every file the runs, the plans and Docker wrote belonged to the user. Not tested here: the GPU (the test machine has none) and program windows on a Linux desktop.

---

## 0. What is the same, what is different

| | Windows | Linux (Ubuntu) |
|---|---|---|
| Python | `python xray_static.py ...` | `python3 xray_static.py ...` (or `python` inside the venv of section 1) |
| run files | `run-naive.bat` | `bash run-naive.sh` (the files are not executable, so start them with `bash`) |
| folders | `C:\Users\me\xray-tools` | `/home/me/xray-tools` (`~/xray-tools`) |
| Docker | Docker Desktop | Docker Engine with the compose plugin, a service that starts at boot (section 1) |
| GPU in containers | NVIDIA driver + Docker Desktop (WSL 2) | NVIDIA driver + NVIDIA Container Toolkit (section 1) |
| editing a file | Notepad | `nano FILE`, gedit or VS Code |
| paths in your code | `C:\...` as they are | changed by you to Linux paths (section 3a), or kept with `pc-map.txt` (3b) |
| files the runs write | yours | yours: the tools hand back what containers wrote as root (section 5) |
| program windows (`cv2.imshow`) | `run-window.bat` (WSLg) | `run-window.sh` (your desktop's X server, section 7) |

Everything that runs inside the containers is identical, because a container is Linux on Windows too: the images, the Dockerfiles X-Ray writes, the trace, the package scan and the verify.

---

## 0b. Before you start: what this PC already has

**The terminal: your normal user.** Open Terminal (`Ctrl+Alt+T`): it runs as you. Ubuntu has no "Run as administrator" window. Instead, a single command that changes the system starts with `sudo`, which asks for your password (and remembers it for about 15 minutes). In this guide:
- **with `sudo`:** installing packages, adding you to the `docker` group, setting up the NVIDIA toolkit, making Docker start at boot, and making a folder outside your home (`/mnt/disk/...`, `/srv/...`).
- **without `sudo`, as you:** everything else - every X-Ray tool, every `bash run-....sh`, every `docker` command. Never `sudo bash run-naive.sh` and never a root shell (`sudo -i`, `su`). What a run writes would belong to root, and the tools hand files back to the user who runs them.

**The checks.** All as you, without `sudo`; they change nothing. Paste the whole block into the terminal:

```bash
echo "--- Ubuntu";         grep PRETTY_NAME /etc/os-release
echo "--- you";            id
echo "--- docker";         docker --version; docker info --format 'server {{.ServerVersion}}'
echo "--- docker at boot"; systemctl is-enabled docker
echo "--- compose";        docker compose version
echo "--- buildx";         docker buildx version
echo "--- a container";    docker run --rm hello-world | grep Hello
echo "--- python";         python3 --version; ~/xray-venv/bin/python -m pip --version
echo "--- disk";           df -h ~ | tail -1
echo "--- tools folder";   find ~/xray-tools ! -user "$USER" | head -3; echo "(end of list)"
echo "--- gpu";            nvidia-smi --query-gpu=name,driver_version --format=csv,noheader; nvidia-ctk --version | head -1
echo "--- gpu in docker";  docker run --rm --gpus all ubuntu nvidia-smi -L
```

Read the answer of each part. For each: why X-Ray needs it, what "ready" looks like, and what to do if it is not.

- **Ubuntu** - the version the commands are for.
  - ready: `PRETTY_NAME="Ubuntu 24.04.5 LTS"` (22.04 works the same)
  - if not: an older Ubuntu - Python 3.8 (Ubuntu 20.04) is the oldest the tools run on
- **you** - `uid=1000`: the slim image's program runs as user 1000, so what it writes into your folders is yours. `docker`: Docker without `sudo`. `sudo`: you may install.
  - ready: `uid=1000(me) gid=1000(me) groups=1000(me),4(adm),27(sudo),...,996(docker)`
  - if not: no `docker` in the list - section 1, Docker without `sudo`. A uid other than 1000 - section 5
- **docker** - Docker Engine: the `docker` command and the service that runs the containers.
  - ready: `Docker version 29.x.x, build ...` and `server 29.x.x`
  - if not: `Command 'docker' not found` - section 1, Docker Engine
  - if not: `permission denied while trying to connect to the docker API` (older Docker: `... the Docker daemon socket`) - you are not in the `docker` group yet: section 1, then log out and in
  - if not: `failed to connect to the docker API ... check if ... the daemon is running` (older: `Cannot connect to the Docker daemon`) - `sudo systemctl enable --now docker`
- **docker at boot** - the containers of a `compose.yml` (`restart: unless-stopped`) come back after the PC restarts.
  - ready: `enabled`
  - if not: `disabled` - `sudo systemctl enable --now docker`
- **compose** - the plans' `compose.yml`, `xray_clients.py`.
  - ready: `Docker Compose version v2.x` or newer
  - if not: `docker: unknown command: docker compose` (older: `'compose' is not a docker command`) - `sudo apt-get install -y docker-compose-plugin`
- **buildx** - X-Ray's Dockerfiles keep pip's downloads in a cache (`RUN --mount=type=cache`); only BuildKit (buildx) builds that.
  - ready: `github.com/docker/buildx v0.x ...`
  - if not: `docker: unknown command: docker buildx` - `sudo apt-get install -y docker-buildx-plugin`. Without it every X-Ray build stops at `the --mount option requires BuildKit` (*tested*)
- **a container** - Docker can download an image and start a container.
  - ready: `Hello from Docker!`
  - if not: a network or proxy error - the PC's internet. `toomanyrequests` / `429 Too Many Requests` - Docker Hub's limit for downloads without an account: `docker login`, or try again later
- **python** - the tools need `python3` 3.8 or newer; `xray_naive.py` also needs pip, from the venv of section 1.
  - ready: `Python 3.12.3` and `pip 25.x from /home/me/xray-venv/...`
  - if not: `No such file or directory` - section 1, Python for the tools
- **disk** - images are big: a GPU image is 5-15 GB, and Steps 2-4 keep the naive and the slim image.
  - ready: the 4th column (free space) shows enough, e.g. `/dev/nvme0n1p2  468G  41G  404G  10% /`
  - if not: under about 50 GB free - make room, or give Docker another disk (`"data-root"` in `/etc/docker/daemon.json`)
- **tools folder** - everything in it is yours, so the tools can write and hand files back.
  - ready: `(end of list)` alone
  - if not: files listed (copied with `sudo`, or old runs) - `sudo chown -R $USER:$USER ~/xray-tools`
- **gpu** (GPU projects only) - the NVIDIA driver on the PC, and the toolkit that gives the card to containers.
  - ready: `NVIDIA GeForce RTX 3060, 5xx.xx` and `NVIDIA Container Toolkit CLI version 1.x`
  - if not: `Command 'nvidia-smi' not found` - section 1, the GPU block
  - if not: `NVIDIA-SMI has failed because it couldn't communicate with the NVIDIA driver` - restart the PC; with Secure Boot on, Ubuntu asks at the restart to enroll a key (MOK): do it
  - if not: `nvidia-ctk: command not found` - the toolkit, section 1
- **gpu in docker** (GPU projects only) - the run files' `--gpus all`.
  - ready: `GPU 0: NVIDIA GeForce RTX 3060 (UUID: GPU-...)`
  - if not: `could not select device driver "" with capabilities: [[gpu]]`, or on newer Docker `failed to discover GPU vendor from CDI: no known GPU vendor found` (*tested*, on this PC without a card) - the toolkit is missing or not set up: section 1, the GPU block

Everything ready: go on with section 2. Something missing: do only that part of section 1, then paste the checks again. *Tested* here: every part except the GPU ones (the test machine has no card) and `hello-world` (Docker Hub answered `429 Too Many Requests` that day - the case in the table).

---

## 1. Set up the Ubuntu PC once

Only the parts the checks of 0b showed missing. In your normal terminal; each `sudo` line asks for your password. The comment at the end of each line says what it does.

**Docker Engine and compose** (Docker's own packages; Ubuntu's `docker.io` + `docker-compose-v2` work too, only older):

```bash
sudo apt-get update                                  # refresh Ubuntu's list of packages
sudo apt-get install -y ca-certificates curl         # the tools that download Docker's key safely
sudo install -m 0755 -d /etc/apt/keyrings            # the folder for the keys of package sources
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc   # Docker's key: apt checks every package with it
sudo chmod a+r /etc/apt/keyrings/docker.asc          # apt may read the key
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null   # Docker's package source
sudo apt-get update                                  # the list again, now with Docker's packages
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin   # the service, the docker command, its runtime, BuildKit, compose
sudo systemctl enable --now docker                   # start Docker now and at every boot
```

The installs print many lines and end without `E:` lines. Then the checks of 0b for docker, compose and buildx answer as in the table.

**Docker without `sudo`:** put yourself in the `docker` group, then log out and in once (or type `newgrp docker` in the open terminal).

```bash
sudo usermod -aG docker $USER     # you may use Docker's socket: docker without sudo
docker ps                         # after logging out and in: a header line, no "permission denied"
```

`docker ps` must answer with its header (`CONTAINER ID   IMAGE ...`), without "permission denied". Never run the run files with `sudo`. Everything they write would then belong to root, and the tools could not hand it back to you.

**Python for the tools:** Ubuntu has `python3`. `xray_naive.py` also needs pip, to check your requirements against PyPI. Ubuntu 24.04 refuses `pip install` outside a virtual environment ("externally-managed-environment"), so give the tools their own venv, once:

```bash
sudo apt-get install -y python3-venv python3-pip      # what makes a venv, and pip
python3 -m venv ~/xray-venv                           # the tools' own Python folder, in your home (no sudo)
~/xray-venv/bin/python -m pip install -U pip          # a new pip in it: ends with "Successfully installed pip-25..."
source ~/xray-venv/bin/activate                       # this terminal uses it: the prompt starts with (xray-venv)
```

After `source ...activate`, `python` and `pip` in that terminal are the venv's, so the commands look exactly as on Windows (`python xray_static.py ...`). Activate it again in each new terminal, or always type `~/xray-venv/bin/python`. X-Ray installs nothing into it except the newer pip (*tested*: with pip 24.0 from Ubuntu, `xray_naive.py` warns that Requires-Python is checked against the wrong Python; in the venv with the new pip the warning is gone).

**The NVIDIA GPU** (GPU projects only): the driver, then NVIDIA's Container Toolkit, which lets containers use the card.

```bash
sudo ubuntu-drivers install            # the NVIDIA driver Ubuntu recommends for your card
sudo reboot                            # the driver loads at the start (Secure Boot: enroll the key it asks for)
nvidia-smi                             # a table with your card, the driver version and "CUDA Version"
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg   # NVIDIA's key for its packages
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list   # NVIDIA's package source
sudo apt-get update                    # the list again, with NVIDIA's packages
sudo apt-get install -y nvidia-container-toolkit     # gives the card to containers
sudo nvidia-ctk runtime configure --runtime=docker   # tells Docker about it (writes /etc/docker/daemon.json)
sudo systemctl restart docker          # Docker reads that file again
docker run --rm --gpus all ubuntu nvidia-smi         # as you: the same table, from inside a container
```

The last line must print the same table as `nvidia-smi` on the PC: then `--gpus all` in the run files works.

**The tools:** clone your xray-tools repo (or unzip `xray-tools.zip`) into your home folder:

```bash
git clone https://github.com/YOUR-NAME/xray-tools.git ~/xray-tools     # as you, no sudo: the folder is yours
cd ~/xray-tools
```

Everything below runs from `~/xray-tools`, as you. With the zip instead: `unzip ~/Downloads/xray-tools.zip -d ~` (as you, too).

---

## 2. Bring your projects and data over

- **The code:** copy each project folder to the Linux PC (git, a USB disk, `scp`), for example to `~/projects/anpr`.
- **The data the code names** (models, videos, config files on `C:\` or `D:\`): copy them to Linux folders of your choice, for example `~/data/models`, `~/data/videos`. Then section 3: write those paths into the code (3a), or tell X-Ray where they went (3b).
- **The `runs` folders made on Windows:** start again on Linux. Their JSON and run files hold Windows paths (`C:\...\project`) and `.bat` files. Run the steps of section 4 again: the analysis is the same, it is only the paths that differ.
- **Settings files you wrote on Windows** (a `.env`, a `run.env` you changed): Notepad ends lines with `\r\n`. In an env file the `\r` becomes part of the value, so a path or password no longer matches. Fix such a file once:

  ```bash
  sed -i 's/\r$//' FILE
  ```

  The tools themselves write Linux line ends. Python code with Windows line ends runs as it is.

---

## 3. Your code's paths: two ways

Code written on Windows names files by where they were on that PC:

```python
MODEL = os.getenv("MODEL_PATH", r"C:\Users\me\models\plate.onnx")      # a default
VIDEOS = [r"C:\Users\me\Desktop\videos\lane1.mp4"]                    # a config list
SAVE_DIR = r"D:\output\frames"                                         # a folder it saves into
```

A Linux PC has no `C:\`. Copy the data to Linux folders (section 2), then choose per project:

| | 3a. Change the paths in the code to Linux paths | 3b. Keep the Windows paths |
|---|---|---|
| you write | the Linux paths, in the code (`/home/me/data/models/plate.onnx`) | one line per folder, in `pc-map.txt` (`C:\Users\me\models = /home/me/data/models`) |
| the code | changed by you | unchanged |
| X-Ray | mounts each path at the same place in the container | gives the code's `C:\...` text the Linux file (`PC_PATHS`, X-Ray's `xray_inputs`) |
| production (`compose.yml`) | everything filled in by the plan | a file named in a config list: a line by hand (end of 3b) |

Both are *tested*. Once the paths are Linux paths (3a), the project runs on this PC without Docker too, as before on Windows.

### 3a. Linux paths in the code

```python
MODEL = os.getenv("MODEL_PATH", "/mnt/disk/models/plate.onnx")  # a default
VIDEOS = ["/home/me/data/videos/lane1.mp4"]                    # a config list
SAVE_DIR = "/home/me/data/frames"                              # a folder it saves into
```

Three rules:
1. **The data first, then Step 1.** Copy the models, videos and config files to exactly the paths the code names, before Step 1. X-Ray knows a path belongs to this PC because its first two folders are here (`/home/me`, `/mnt/disk`). A path whose top is missing (`/home/alice/...`, copied from a colleague's code) is treated as another machine's path: a CHECK line and a suggested code change.
2. **Where:** your home (`/home/me/...`), a second disk (`/mnt/...`, `/media/...`) or a folder of your own (`/srv/...`, `/data/...`, `/opt/...`). Not the system's folders (`/tmp`, `/var`, `/etc`, `/usr`): the container has its own there, so X-Ray mounts nothing from them.
3. **A folder outside your home** needs `sudo` once, and must then be yours: `sudo mkdir -p /mnt/disk/data && sudo chown -R $USER:$USER /mnt/disk/data`. In your home you make folders without `sudo`.

What X-Ray does with each (*tested*):

- **A file or folder the code reads** (`VIDEOS`, `"/mnt/disk/models/plate.onnx"`)
  - test runs: mounted read-only at the same path
  - production (the plan's `compose.yml`): the same. `.env` names it (`LANE1_MP4_FILE=/home/me/...`): on another machine only that line changes
- **A folder the code writes** (it may make it itself: `SAVE_DIR`)
  - test runs: a test folder, `runs/NAME/files/frames`, is mounted at that path - your real folder stays as it is
  - production: your real folder, at the same path. The plan makes it, as you, if it is missing
- **An `os.getenv` default** (`MODEL_PATH`)
  - test runs: the env var gets the path in the container, and a small file is copied into the image (as on Windows)
  - production: the same, your real folder mounted read-only
- **A path relative to the project** (`models/plate.onnx`)
  - both: part of the image (`/app/models/...`), as on Windows

- **Nothing to set:** no `pc-map.txt`, no code change. Step 1 lists these paths as `thispc`, and `CODE CHANGES NEEDED` says `none found`.
- **A file that is not there** stops the run before the program starts: `bind source path does not exist: /mnt/disk/models/plate.onnx`. Put the file there and start again. Docker's plain `-v` would instead make an empty folder of that name, owned by root, and the next run would fail with `Is a directory` (*tested*). X-Ray's files avoid that: `--mount` in the run files, `create_host_path: false` in `compose.yml`.
- **Both ways in one project** work: a path left as `C:\...` goes through `pc-map.txt` (3b), the Linux ones as here.

### 3b. Windows paths kept: `pc-map.txt`

X-Ray cannot find `C:\...` on Linux, so it cannot mount those files into the runs. Tell it where you copied them: `pc-map.txt` in the tools folder, one line per folder, WINDOWS FOLDER = LINUX FOLDER:

```text
# Windows folder (as the code writes it) = the same folder on this Linux PC
C:\Users\me\models = /home/me/data/models
C:\Users\me\Desktop\videos = /home/me/data/videos
```

- Write it **before Step 1**. Step 1 then finds the files ("NOT on the PC" warnings disappear), and `xray_naive.py`, `xray_runfile.py` and `xray_plan.py` use the Linux folders.
- One line covers everything below that folder: `C:\Users\me = /home/me/data` maps `C:\Users\me\models\plate.onnx` to `/home/me/data/models/plate.onnx`. When two lines match, the longer folder wins.
- Upper and lower case, and `\` against `/`, do not matter on the Windows side, as on Windows.
- **The other way to add a line:** `python3 xray_runfile.py ... --map "C:\Users\me\models=/home/me/data/models"` adds it to the file.
- **Under WSL** (Ubuntu inside Windows) nothing is needed: `C:\` is `/mnt/c` there, and X-Ray uses that by itself.
- **It stays on this PC:** `pc-map.txt` names your folders, so the tools' `.gitignore` keeps it out of git.

What X-Ray then does with each kind of path. Your code keeps its own text throughout; *tested* with the three lines above:

| In the code | On Linux, with `pc-map.txt` |
|---|---|
| an `os.getenv` default that is a file (`MODEL_PATH`) | the Linux folder is mounted, or copied into the image when small. The env var gets the path inside the container |
| a file named in a list, dict or constant (`VIDEOS`) | the Linux file is mounted at `/xin/pc_1/...`. `PC_PATHS` maps the code's `C:\...` text to it (`xray_inputs`, GUIDE 17b) |
| a folder the code saves into (`SAVE_DIR`) | nothing to map: it lands in the run's out folder `runs/NAME/out/pc_out_1` (GUIDE 17c) |
| a path with no line in `pc-map.txt` | the run files print a `CHECK` line naming the folder to add. Add it, then run `xray_runfile.py` again |

**For production** (`xray_plan.py`'s `compose.yml` and `.env.example` in `runs/NAME/plan`):
- **Inputs:** the input folders of `os.getenv` defaults are the Linux ones from `pc-map.txt`.
- **A file named in a config list** (`VIDEOS` above) is given to the code in the test runs only. In production a server's config usually names its real source (a camera), so `.env.example` only says how to add it by hand (a mount and a `PC_PATHS` line). Simpler: change that one path to its Linux place (3a).
- **A folder the code saves into, with no line:** it becomes `./pc_out_1` next to `compose.yml`. A comment in `.env.example` says what to write there.
- **Folders next to `compose.yml`:** the plan makes them itself, as yours. A folder Docker makes belongs to root, and the slim image's program (user 1000) could not write into it (*tested*).
- **An absolute folder you write into `.env`** (`PC_OUT_1=/srv/out`) must exist and belong to user 1000: `sudo mkdir -p /srv/out && sudo chown 1000:1000 /srv/out`.

---

## 4. The steps, with the Linux commands

The same order as the walkthrough and GUIDE.md. Exactly this sequence ran in the test (with `--cpu`):

```bash
cd ~/xray-tools
mkdir -p runs/app
python3 xray_static.py --root ~/projects/app --entry main.py --requirements requirements.txt --out runs/app/app.json 2>&1 | tee runs/app/step1.log
python3 xray_needs.py runs/app/app.json 2>&1 | tee runs/app/step1-needs.log
python3 xray_naive.py --project ~/projects/app --requirements requirements.txt --entry main.py --name app --gpu --static runs/app/app.json
cp runs/app/naive/Dockerfile.naive runs/app/naive/Dockerfile.naive.dockerignore runs/app/naive/requirements.docker.txt ~/projects/app/
python3 xray_runfile.py --static runs/app/app.json --project ~/projects/app --name app
cd runs/app
bash build-naive.sh
bash run-naive.sh
bash run-step2.sh
bash run-step3-4.sh
bash build-slim.sh
bash run-slim.sh
tail -1 verify.txt
```

- **`app`:** your project's short name. `--gpu` is for a GPU program, `--cpu` for a CPU one.
- **Paths:** the same commands for both ways of section 3. With Linux paths in the code (3a) there is nothing to write first; with Windows paths (3b), `pc-map.txt` before the first line.
- **`xray_naive.py`** writes into `runs/app/naive/`. Copy those three files into the project (the `cp` line), as on Windows.
- **`xray_runfile.py`** prints the files it wrote and the order to run them in. Read `code-changes.txt` first, as on Windows.
- **The verdict:** `verify.txt` must end with `VERDICT: PASS`.
- **Every other run file works the same way:** `bash run-explore.sh`, `bash run-load.sh A`, `bash compare-images.sh`, `bash videos.sh ~/data/videos`.

---

## 5. Files the runs write are yours

A container usually runs its program as root. On Windows that does not matter. On Linux, files a container writes into a folder of your PC would belong to root, and you could not edit or delete them without `sudo`. The tools hand them back to you:

- `xray_trace.py` (step 2, slim, load and explore runs), `xray_pkg.py`, `xray_look.py` and `xray_videos.py` give root's files back to the owner of the folder when they finish.
- **`run-naive.sh`** runs no X-Ray inside, so it ends with one `chown` in the same image.

*Tested*: after build, naive, step 2, steps 3-4, slim and compare-images, every file in `runs/app` belonged to the user. Deleting a folder needed no `sudo`.

**What X-Ray makes on your PC, and whose it is:**

| What | Made by | Where |
|---|---|---|
| the run files, logs, trace, package scan, plan, `out*` and `files*` folders | the tools and the run files | `~/xray-tools/runs/NAME` |
| test folders for the folders the code writes (3a) | the run files, before each run | `runs/NAME/files/...` |
| the real folders the code writes (3a), if missing | `xray_plan.py` (Steps 3-4) | the paths in the code |
| folders next to `compose.yml` (3b: `pc_out_1`) | `xray_plan.py` | `runs/NAME/plan/` |
| `pc-map.txt` (3b) | you, or `xray_runfile.py --map` | `~/xray-tools` |

Docker itself makes nothing on your PC: an input that is missing stops the start, and every folder a container writes into exists before it starts. *Tested*: after all the steps, `docker compose up`, a missing input and the combined image, `find ~/xray-tools ~/data /mnt/disk -uid 0` listed nothing - no file of root.

Two cases need one command:
- **Older runs** (made before this version), or a run stopped with Ctrl+C before the end.
- **A user id other than 1000:** `id -u` prints it. The slim image's program runs as user 1000, and the first user of an Ubuntu PC is 1000.

```bash
sudo chown -R $USER:$USER ~/xray-tools/runs/app
```

---

## 6. The other guides' Windows commands, in Linux form

The walkthrough pages and GUIDE.md write many commands for Windows CMD. The Linux form of each:

| In a guide (Windows CMD) | On Linux (bash) |
|---|---|
| `python xray_static.py ...` | `python3 xray_static.py ...` |
| `cd /d D:\xray-tools` | `cd ~/xray-tools` |
| `run-naive.bat` | `bash run-naive.sh` |
| `runs\app\step2-needs.txt` | `runs/app/step2-needs.txt` |
| `notepad FILE` | `nano FILE` (or gedit, `code FILE`) |
| `type FILE` | `cat FILE` |
| `dir /b` | `ls` |
| `findstr TEXT FILE` | `grep TEXT FILE` |
| `copy A B` / `xcopy /E /I A B` | `cp A B` / `cp -r A B` |
| `del FILE` / `rmdir /s /q DIR` | `rm FILE` / `rm -r DIR` |
| `set NAME=value` | `export NAME=value` |
| `%NAME%`, `%CD%` | `$NAME`, `$PWD` |
| `^` at the end of a line (continues the command) | `\` at the end of a line |
| `where python` | `which python3` |
| `ipconfig` | `hostname -I` (or `ip -4 addr`) |
| `-v "C:\data:/data"` | `-v "/home/me/data:/data"` |
| `chcp 65001` | not needed: the terminal is UTF-8 |
| Docker Desktop: Settings > Resources (memory, CPUs) | not needed: containers use the whole PC (limit them with `--memory`, `--cpus`) |
| Docker Desktop: "start when you sign in" | `sudo systemctl enable --now docker`: Docker starts at boot, with or without a user signed in |

Lines meant for INSIDE a container (`docker exec -it NAME bash`, then `ls /app`, `ldd`, `$LD_LIBRARY_PATH` ...) are the same everywhere: they were always Linux.

---

## 7. GPU, program windows, cameras

- **GPU:** once the Toolkit of section 1 works (`docker run --rm --gpus all ubuntu nvidia-smi`), the run files' `--gpus all` and the compose files' `deploy: ... devices` work as on Windows. Docker Desktop on Windows shares the card through WSL 2; on Linux the Toolkit does it.
- **Program windows** (`cv2.imshow`, `run-window.sh`): the container draws on your desktop through the X server's socket (`/tmp/.X11-unix`, `DISPLAY`). Start it from a terminal of the desktop session, not over SSH. The run file allows local containers with `xhost +local:` when `xhost` is installed (`sudo apt-get install -y x11-xserver-utils`). Ubuntu's default Wayland desktop runs XWayland for this. A container without a screen still needs the windows switched off: `NO_WINDOWS=1`, GUIDE 16, the same as on Windows.
- **Cameras:**
  - `rtsp://` cameras work the same.
  - A USB camera is a device on Linux: add `--device /dev/video0` to the `docker run` line of the run file (GUIDE 18.3).
  - `SOURCE` (GUIDE 17a) takes Linux paths: `SOURCE="/home/me/data/videos"`.
- **ffmpeg (and any program the code starts):** nothing to install on the Linux PC. The program uses the ffmpeg of
  its image (GUIDE 19): X-Ray finds it in the code - by name, as `C:\ffmpeg\bin\ffmpeg.exe`, or through a package
  such as pydub - Dockerfile.naive installs it, and the slim image keeps it. A Windows path to it needs no code
  change: `WIN_PATHS=1` (the run files set it) starts the image's ffmpeg. `videos.sh` builds its own converter image
  (`xray-ffmpeg:2`, from the tools' `xray_ffmpeg.Dockerfile`) the first time - only to convert test videos.

---

## 8. Hosting clients and combining images on Linux

- **`xray_clients.py`** (CLIENT_HOSTING.md) was tested on this Linux PC end to end: four clients, keys, passwords, isolation, updates, backups. It also gives the folders the programs write to the user the image runs as. CLIENT_HOSTING.md section 14 has the Linux commands: `python3`, `/srv/hosting`, `sudo ufw allow 8441:8460/tcp`, `systemctl enable docker`.
- **`xray_combine.py`** (COMBINE_GUIDE.md) writes `run-combined.sh` next to each program's `run-slim.sh`. The combined image is the same on both systems.

---

## 9. When something goes wrong

- **`permission denied while trying to connect to the docker API` (older Docker: `... the Docker daemon socket`)**
  - why: you are not in the `docker` group yet
  - do: section 1: `sudo usermod -aG docker $USER`, then log out and in
- **`bind source path does not exist: /path/file`**
  - why: a file the code reads (3a) is not at that path
  - do: put it there; in production also check its line in `.env`
- **`IsADirectoryError` / `Is a directory: '/path/model.onnx'`**
  - why: a `docker run -v` written by hand (not X-Ray's files) found no file and made a folder of that name, as root
  - do: `sudo rmdir /path/model.onnx`, put the file back
- **`PermissionError: [Errno 13] Permission denied: '/path/...'` in `docker compose logs`**
  - why: the folder the program writes belongs to root or to another user
  - do: `sudo chown -R $(id -u):$(id -g) /path`
- **`the --mount option requires BuildKit`**
  - why: buildx is missing
  - do: `sudo apt-get install -y docker-buildx-plugin`
- **`docker: unknown command: docker compose` (older: `'compose' is not a docker command`)**
  - why: the compose plugin is missing
  - do: `sudo apt-get install -y docker-compose-plugin`
- **`bash: ./run-naive.sh: Permission denied`**
  - why: the run files are not executable
  - do: `bash run-naive.sh`
- **`CHECK ... a Windows path - on this Linux PC write where that folder is into pc-map.txt`**
  - why: no line for that folder
  - do: add the line (section 3), run `xray_runfile.py` again
- **the program in the container: `No such file or directory: 'C:\...'`**
  - why: that path has no line, or the file is not where the line says
  - do: `pc-map.txt`; `ls` the Linux folder
- **`No module named pip` (xray_naive.py)**
  - why: Ubuntu's Python without pip
  - do: section 1: the venv
- **`error: externally-managed-environment`**
  - why: `pip install` into Ubuntu's own Python
  - do: section 1: the venv
- **`could not select device driver "" with capabilities: [[gpu]]`, or `failed to discover GPU vendor from CDI`**
  - why: the NVIDIA Container Toolkit is missing or not configured
  - do: section 1, the GPU block
- **`Permission denied` deleting something in `runs/`**
  - why: older runs, or your user id is not 1000
  - do: `sudo chown -R $USER:$USER ~/xray-tools/runs/NAME`
- **`$'\r': command not found`, or a value with an odd character at the end**
  - why: a file edited in Windows' Notepad
  - do: `sed -i 's/\r$//' FILE`
- **`cannot open display` (run-window.sh)**
  - why: not started from the desktop session, or X refuses containers
  - do: open the terminal on the desktop; `xhost +local:`
- **`python: command not found`**
  - why: Ubuntu's command is `python3`
  - do: `python3`, or the venv (section 1), or `sudo apt-get install python-is-python3`

---

## 10. What changed in the tools for Linux

| Tool | Version | Change |
|---|---|---|
| `xray_runfile.py` | 0.2.14 | `pc-map.txt` + `--map` (`C:\...` found on Linux, `/mnt/c` under WSL); mounts use the Linux folders; `run-naive.sh` gives its files back; run files pass `--naive-image` to the plan |
| `xray_static.py` | 0.5.19 | a file of the PC is looked up through `pc-map.txt` |
| `xray_needs.py` | 0.1.17 | on Linux, "not on this PC" points to `pc-map.txt` |
| `xray_naive.py` | 0.4.10 | uses the mapped folders; `build-naive.sh` and `$PWD` in its text on Linux; a project with no packages no longer stops the check; the pip warning gives the Ubuntu fix |
| `xray_plan.py` | 0.1.20 | the Linux folders in `compose.yml` / `.env.example`, and the folders next to `compose.yml` made as yours; files the naive Dockerfile copied from the PC are taken from the naive image (`COPY --from=NAME-naive`), so the slim image has them too, on Windows as well |
| `xray_trace.py` | 0.2.10 | gives back the whole out folder and the test folders, not only its own files |
| `xray_look.py`, `xray_videos.py` | 0.1.6, 0.2.1 | give back what they write as root |
| `xray_combine.py` | 0.1.4 | names `.sh` files on Linux; files of the PC built into a program's image (`/xin/...`) are taken into the combined image too (before, a program that read such a file failed there, on Windows as well) |

Then, for the programs the code starts (ffmpeg - GUIDE 19), on Windows and Linux alike:

| Tool | Version | Change |
|---|---|---|
| `xray_static.py` | 0.5.20 | `C:\ffmpeg\bin\ffmpeg.exe` in the code is the program the image needs (`ffmpeg`), not a PC file to mount - started, checked first or handed to a library; `import ffmpeg` is the package ffmpeg-python |
| `xray_inputs` | - | with `WIN_PATHS=1`, `C:\...\ffmpeg.exe` starts the image's ffmpeg, and `os.path.isfile` / `os.access` on it find it |
| `xray_naive.py` | 0.4.11 | more packages that start ffmpeg (ffmpy, python-ffmpeg, vidgear, yt-dlp, youtube-dl, spleeter); the line for a Windows program says how it runs |
| `xray_runfile.py` | 0.2.15 | `WIN_PATHS=1` for a Windows program in the code too; a Step 1 map kept elsewhere is copied to `runs/NAME/NAME.json`, where the run files read it |
| `xray_trace.py` | 0.2.11 | sees through xray_inputs: a program the code starts through it is the code's own (before, the slim plan could leave that program out) |
| `xray_pkg.py` | 0.1.5 | a program a package starts (pydub, ffmpeg-python: ffmpeg) counts like the code's own - seen in the run, or while that package stays (before, the slim plan left it out); a program from a pip package (a link to imageio-ffmpeg's ffmpeg) keeps that package; a program no package has is copied from the naive image |
| `xray_plan.py` | 0.1.21 | the slim Dockerfile makes that link again, or copies that program |
| `xray_combine.py` | 0.1.5 | the same in the combined image |

Then, for Linux paths in the code (section 3a):

| Tool | Version | Change |
|---|---|---|
| `xray_static.py` | 0.5.21 | a path of this PC in the code (`/home/me/...`, `/mnt/disk/...`) is `thispc`: mounted at the same path, no code change (before: a "file of one PC" for `pc-map.txt`, or a code change) |
| `xray_needs.py` | 0.1.18 | lists those paths as `thispc`, not as code changes |
| `xray_runfile.py` | 0.2.16 | mounts them at the same path - inputs read-only with `--mount`, so a missing file stops the run (before, a model under `/mnt` was not mounted at all and the program failed); a folder the code writes anywhere on this PC gets a test folder; an `os.getenv` default under `/mnt` is handled like one under `/home`. `run-naive.sh` cancels its stop timer when the program ends (before, starting it again within `RUN_SECONDS` stopped the new run early) |
| `xray_naive.py` | 0.4.13 | never copies such a path into the image; `naive-check.txt` lists it as mounted at the same path, and its `docker run` line mounts it (0.4.12 left both out) |
| `xray_plan.py` | 0.1.22 | `compose.yml`: the real folders at the same paths (made as yours), inputs read-only with `create_host_path: false`; a folder an env var moved defaults to its real place; no two `.env` names alike |
