# One GPU server, many clients - hosting ML solutions with Docker

How to run your ML solutions for several clients at the same time on one GPU machine: each client gets its own copy,
nobody sees another client's data, and only a client with the right key (or password) gets in. The working templates
are in `multi-client/`. Everything marked *tested* was run with them; what was not tested is said where it comes up.

---

## 0. The picture

```
   client A's software                 client B's people (browser)
         |  https://client-a.yourcompany.com     |  https://client-b.yourcompany.com
         |  + its API key                         |  + user name / password
  =======|========================================|=====================  the server: only ports 80 + 443 open
         v                                        v
   +---------------------------- proxy (Caddy) -------------------------------+
   |  checks the key / password, then sends the request to that client only   |
   +------------|------------------------------------------|-------------------+
                v  network client-a_net                     v  network client-b_net
        client A's solution  (data: clients\client-a\data)   client B's solution  (data: clients\client-b\data)
                \_______________________ one GPU, shared ______________________/
```

- **One compose project per client** (`docker compose -p client-a up -d`): its own containers, its own network, its
  own data folder, its own settings (`.env`), its own limits.
- **One proxy in front** (Caddy): the only container that is reachable from outside. It decides who gets in, and
  where each request goes.
- **The GPU is shared**: every client's containers use the same card(s) (section 5) - the reason this is
  containers and not one VM per client (section 1).

---

## 1. The first idea was one VM per client - why it became containers

**The idea.** Deliver each client its own ML solution in its own virtual machine (VM), all on one machine at the
same time: client A's solution in VM A, client B's in VM B, each closed off from the others.

**What stopped it: the GPU.** Every one of these solutions needs the NVIDIA card - and a VM can only use a GPU in a few
ways, none of which gives several VMs one consumer card. What we found for this office's setup (a Windows 11 PC with
an RTX 3060, Docker Desktop on WSL2, Oracle VirtualBox):

| Way to run a VM | GPU (CUDA) inside the VM? | Why |
|---|---|---|
| Oracle VirtualBox | no | it gives a VM only a simulated graphics card - no CUDA, no NVIDIA driver inside |
| VMware Workstation | no | the same: simulated 3D graphics only |
| Hyper-V on Windows 10 / 11 | no (for a Linux VM) | giving a whole card to a VM (DDA) exists only on Windows Server |
| WSL2 (Windows' built-in Linux VM) | yes | Windows shares its own NVIDIA driver with it. But it is ONE VM: every Linux in WSL2 runs inside the same one, so it cannot be one VM per client |
| A Linux server with a hypervisor (Proxmox, VMware ESXi) + PCI passthrough | yes, the whole card | a card goes to ONE VM. One RTX 3060 = one VM with a GPU; a second client needs a second card |
| NVIDIA vGPU (one card split between VMs) | yes | only data-centre cards (A / L series) with NVIDIA's vGPU licences - not an RTX 3060 |

So with one RTX 3060, at most ONE VM can have the GPU - and every other client's VM would run its models on the CPU,
many times slower (or not at all, where the code asks for CUDA).

**Containers solve exactly that.** All containers on a machine can use the same card at the same time (`--gpus all`;
compose: the `deploy:` block), with nothing to set up. And the separation the VMs were meant to give, containers give
too:

| What the VM per client was for | With a compose project per client |
|---|---|
| client A cannot reach client B | each client's containers are on their own network: client A's cannot even find client B's (*tested*: `Name or service not known`) |
| each client's data apart | each client's own folder (`clients\client-a\data`), mounted only into its own containers |
| one client cannot take the whole machine | CPU and memory limits per client (*tested*: `docker stats` showed the limit); GPU memory: section 5 |
| each client's own settings and version | its own `.env` and its own image version (section 6) |
| only that client gets in | the proxy: a key or a password per client (section 4) |
| the GPU | shared by all - the one thing VMs could not do here |

Containers are also lighter: no operating system per client to install, update and give RAM to; a client's
solution starts in seconds.

**What a container does NOT give, compared with a VM.** All containers share the machine's Linux kernel. That is safe
when the containers run OUR solutions and the clients only send requests to them - the case here. If a client were
to run THEIR OWN code on the machine, or a contract demands it, a VM boundary is stronger: then a Linux server with
Proxmox and one GPU per VM (one card per client), or data-centre cards with vGPU.

**Why a reverse proxy in front, and why Caddy.** Without a proxy every client's solution would need its own open
port, its own HTTPS certificate and its own login check. One proxy does all three in one place, and it is the only
container reachable from outside. nginx (the first idea) can do the same; Caddy was picked because it gets and renews
the HTTPS certificates by itself (nginx needs certbot next to it) and a client's whole block is a few lines (section
4). With nginx: one `server { }` per client name, `if ($http_x_api_key != "THE KEY") { return 401; }` for the key,
`proxy_pass http://client-a-api:8000;` - not tested here.

---

## 2. The server

- **Ubuntu Server 24.04 LTS on the machine itself** (not Windows + WSL): it starts the containers at boot without a
  login, it is what servers run, and the NVIDIA driver works directly.
- **NVIDIA driver** (`sudo ubuntu-drivers install`), **Docker Engine + compose plugin** (docs.docker.com/engine/install/ubuntu),
  **NVIDIA Container Toolkit** (then `docker run --rm --gpus all nvidia/cuda:12.8.1-base-ubuntu24.04 nvidia-smi` shows the card).
- **Network**: a fixed IP; open to the outside only **443** (HTTPS) and **80** (Caddy needs it for certificates and
  redirects it to 443); **22** (SSH) only from your office. For clients on the internet: a name per client
  (`client-a.yourcompany.com`) pointing at the server's public address - IT sets that up in the company's DNS.
- **Docker's log limit** in `/etc/docker/daemon.json` (`"log-opts": {"max-size": "50m", "max-file": "5"}`), so logs
  cannot fill the disk.

---

## 3. One client = one folder

```
clients\
  client-a\   compose.yml  .env  data\
  client-b\   compose.yml  .env  data\
proxy\        compose.yml  .env  Caddyfile
```

For a new client:
```bash
cp -r multi-client/client-template clients/client-c
cd clients/client-c
cp .env.example .env        # then edit it
docker compose -p client-c up -d
```
`.env` of a client:
```ini
# its name: network client-c_net, the proxy reaches it as client-c-api
CLIENT=client-c
# which solution, which version (section 6)
IMAGE=anpr-slim:1.4
# the port the solution listens on inside the container
PORT=8000
# at most 4 CPU cores, at most 8 GB RAM (above that only this client's container is stopped and restarted)
CPUS=4
MEM_LIMIT=8g
# + the solution's own settings for this client: its database, its model, its options ...
```
(A comment goes on its own line: `IMAGE=x  # note` would make the note part of the value for the program.)
What is separate per client: the network (`client-c_net`), the data folder (`./data`, mounted at `/data`), the
settings (`.env`), the limits, the image version. No `ports:` - nobody reaches a client's container except through
the proxy.

A solution of several services (an API + a worker + a database for this client): put them all into the client's
`compose.yml` - they share the client's network and reach each other by name (SERVICES_GUIDE.md 4 and 9).

---

## 4. The proxy: who gets in, and where to

`multi-client/proxy/Caddyfile` - one block per client:

```caddyfile
# a client whose SOFTWARE calls the API: a key in the X-API-Key header
client-a.yourcompany.com {
	@key header X-API-Key {$CLIENT_A_KEY}
	handle @key {
		reverse_proxy client-a-api:8000
	}
	respond "missing or wrong API key" 401
}

# a client whose PEOPLE open a dashboard: user name + password
client-b.yourcompany.com {
	basic_auth {
		clientb $2a$14$...the hash...
	}
	reverse_proxy client-b-api:8000
}
```
- **The key**: a long random text, one per client, in `proxy\.env` (`CLIENT_A_KEY=...`). Make one:
  `python -c "import secrets; print(secrets.token_hex(32))"`. Give it to the client once; a new key = change `.env`
  and reload. The client's software sends it with every request: `X-API-Key: <the key>`.
- **The password**: Caddy stores only its hash: `docker run --rm caddy:2 caddy hash-password --plaintext "PASSWORD"`.
  For many users with their own logins, put a login service in front instead (e.g. oauth2-proxy with the company's
  Microsoft / Google accounts).
- **HTTPS**: for names the internet can reach, Caddy gets and renews the certificates by itself (Let's Encrypt) - not
  tested here (it needs a public name). Inside the office only: `tls internal` in the block (browsers warn until
  Caddy's root certificate is installed on the PCs), or `http://name` for plain HTTP on a trusted network.
- **The proxy joins every client's network** (`proxy\compose.yml`, `networks:`) - the clients never join each other's.
- **A new client**: its block in the Caddyfile, its network in `proxy\compose.yml`, then `docker compose up -d` in
  `proxy\` (a Caddyfile change alone: `docker compose exec caddy caddy reload --config /etc/caddy/Caddyfile`).

*Tested* with two clients behind the proxy:

| Request | Answer |
|---|---|
| client A, no key / a wrong key | `401 missing or wrong API key` |
| client A, its key | `200 {"client": "client-a", ...}` - client A's container |
| client B, no password / a wrong one | `401` |
| client B, its password | `200 {"client": "client-b", ...}` |
| client B's address with client A's key | `401` |
| from client A's container to client B's | `Name or service not known` |

---

## 5. Sharing the GPU between the clients' models

- **Computing is shared by itself**: the card works for every container in turn. When two clients are busy at the
  same time, each is slower - measure with the load tests (X-Ray `run-load`) how many clients one card carries.
- **GPU memory adds up, and Docker cannot limit it.** Each client's container loads its own copy of the model, plus a
  few hundred MB for CUDA itself. An RTX 3060 has 12 GB. When it is full, the next one to ask fails
  (`CUDA out of memory`) - that can be any client.
- **Limit it in the program** (each framework has its own switch):
  - PyTorch: `torch.cuda.set_per_process_memory_fraction(0.25)` (at most 25 % of the card)
  - TensorFlow: takes almost ALL the memory at start unless told otherwise - env var `TF_FORCE_GPU_ALLOW_GROWTH=true`
    in the client's `.env` (then it takes what it needs)
  - ONNX Runtime: the CUDA provider option `gpu_mem_limit` (bytes), e.g.
    `providers=[("CUDAExecutionProvider", {"gpu_mem_limit": 2 * 1024**3}), "CPUExecutionProvider"]`
- **Watch it**: `nvidia-smi` on the server - memory per process, and in total.
- **Many clients, the same model**: one shared model service (the model loaded once) that every client's container
  calls, instead of one copy per client. Less memory; the requests of all clients go through one process.
- **More than one card**: give a client its own - in its compose, `device_ids: ["1"]` instead of `count: all`.

Not tested here (this test machine has no GPU): the per-framework limits above are the frameworks' own documented
switches; check them with `nvidia-smi` on the server.

---

## 6. Versions and updates - one client at a time

- Give every built image a version: `docker build -t anpr-slim:1.4 .` (not only `latest`).
- Each client's `.env` names its version: `IMAGE=anpr-slim:1.4`. A new version: change one client's `.env`, then
  `docker compose -p client-a up -d` - only that client restarts. Something wrong: back to the old number, same command.
- Keep the old image until every client runs the new one (`docker images`; old ones: `docker image rm anpr-slim:1.3`).

---

## 7. When the solution runs at the client's site instead

Their machine needs: an NVIDIA GPU + driver, Docker Engine + compose, the NVIDIA Container Toolkit.
- **Give them the images**: `docker save anpr-slim:1.4 | gzip > anpr-slim-1.4.tar.gz`, they run
  `docker load -i anpr-slim-1.4.tar.gz` - or a private registry they can pull from.
- **Give them the compose file + a `.env.example`** with every setting explained; they fill in their own `.env`.
- Never inside the image: passwords, keys, their data - those are in their `.env` and their folders.

---

## 8. Checklist

- [ ] only the proxy publishes ports; databases never (`ports:` missing, or `127.0.0.1:` only)
- [ ] one long random key per client; `.env` files never in git, never in a chat
- [ ] HTTPS for everything that leaves the building
- [ ] CPU and memory limits for every client; the GPU memory switch in each solution
- [ ] each client's `data\` folder in the backups; each client's database dumped (SERVICES_GUIDE.md 3)
- [ ] images with versions; one client updated at a time
- [ ] Docker's log limit set; `df -h` and `docker system df` now and then

## 9. Daily commands

| Command | Does |
|---|---|
| `docker compose -p client-a ps` | client A's containers: running? healthy? |
| `docker compose -p client-a logs -f` | client A's output, live |
| `docker stats` | CPU and memory of every container, against its limit |
| `nvidia-smi -l 5` | the GPU: use and memory, every 5 s |
| `docker compose -p client-a up -d` | start client A / apply a change of its `.env` or version |
| `docker compose -p client-a down` | stop client A (its data stays in its folder) |
| `cd proxy && docker compose exec caddy caddy reload --config /etc/caddy/Caddyfile` | apply a Caddyfile change |
