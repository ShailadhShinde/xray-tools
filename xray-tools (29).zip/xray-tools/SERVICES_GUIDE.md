# A dashboard, a database and your programs in Docker - one system

How to put a .NET web app (a dashboard, a web API), a database (PostgreSQL or MySQL) and your Python / ML
programs into containers, start them together and connect them. For any project. `example-stack/` is a
working example of everything here: run it once as it is, then swap in your own parts (section 8).

Everything below was tested with the example (Docker 29, .NET 8, PostgreSQL 16, MySQL 8.4): what each step
printed is quoted. Not tested here: Windows CMD itself (the commands are the same in CMD), SQL Server, the GPU block.

---

## 0. The picture, and six words

```
            your browser                 pgAdmin / DBeaver on your PC
                 |  http://localhost:8080          |  localhost:5432
  ===============|=================================|============================  your PC / the server
                 v  ports: "8080:8080"             v  ports: "127.0.0.1:5432:5432"
  +--------------------------------- network myapp_net -------------------------------+
  |   web (.NET)  ----- db:5432 ----->   db (PostgreSQL)   <----- db:5432 -----  worker (Python)  |
  |   volume web-keys                    volume db-data                          GPU (optional)    |
  +----------------------------------------------------------------------------------------------+
```

| Word | Means |
|---|---|
| image | the packed program: built once (`docker build`, or downloaded: `postgres:16`) |
| container | an image running. Delete it and start a new one: nothing lost, unless it was inside the container only |
| volume | a folder that lives OUTSIDE the container: the database's files, uploads, keys. It survives |
| service | one part of the system in the compose file: `web`, `db`, `worker` |
| network | compose puts all services on one; each service's name is its address there (`db`) |
| compose file + .env | the plan of the whole system (`compose.yml`), and its passwords / per-machine values (`.env`) |

---

## 1. How much tooling does this need? Much less than the ML part

The ML programs needed X-Ray because their images are hard: thousands of possible pip packages, CUDA, system
libraries, version conflicts, and only a real run shows what is used. The rest of a system is easier:

- **.NET**: Microsoft builds the runtime images (`mcr.microsoft.com/dotnet/aspnet:8.0`). A published .NET app
  carries all its NuGet libraries in its own folder, so the image is that folder + the runtime - no
  requirements to solve, no CUDA. What decides whether it works is the app's SETTINGS and its Windows habits:
  the .NET version, the port, the connection string, paths like `C:\...`, an `.exe` it starts, files it writes.
  Reading the app's folder once finds all of that: `dotnet_check.py` (section 2.0), or by hand with section 2.4.
- **Databases**: no Dockerfile at all - the official image plus a few env vars and a volume. The real work is
  the DATA: the right version, where the files live, loading your existing data, the password, backups.
- **Connecting**: one rule (service name + container port) and a compose file.

So: a Dockerfile template, a compose template and this checklist are enough - no tracing, no slimming.

---

## 2. The .NET app

### 2.0 First: read the app with dotnet_check.py

```bat
python dotnet_check.py "C:\path\to\published-folder" > dotnet-check.txt
python dotnet_check.py "C:\path\to\project" --port 8080 > dotnet-check.txt
notepad dotnet-check.txt
```
Give it the PUBLISHED folder (the one with `MyApp.dll` and `MyApp.runtimeconfig.json` - checked best: it holds
exactly what runs, the compiled code included) or the PROJECT folder (the one with `MyApp.csproj`). `--port` = the
container port your compose file publishes (the right side of `"8080:8080"`): it says if the app listens there.
It only reads files, needs nothing but Python, and never prints passwords (`***`).

It prints nine parts - the app and its .NET version / base image, Linux or not (Windows-only packages and APIs),
port and certificate, database (the driver it uses, connection strings that say localhost or use Windows
login), data-protection keys, programs / files / addresses the code names (`cmd.exe`, `ffmpeg.exe` named with
`\`, `C:\` paths, file names in the wrong upper/lower case), machine checks (MAC, machine name), the Dockerfile
next to it (image version = app version? the right .dll? a web app on the runtime image?), and what goes into the
image (certificates and keys, backup copies, data folders that should be volumes). Each finding is a `PROBLEM`
(it will not work in the container as it is) or a `CHECK` (look at it once), with the fix, and all are
repeated in the SUMMARY at the end.

Tested on a .NET 8 app built with the usual Windows habits (published and source): it found the localhost
endpoint, the `C:\` certificate path, `cmd.exe`, `ffmpeg.exe` named with `\`, `/images/Logo.PNG` against
`logo.png`, the wrong image version and .dll in the Dockerfile, the `.pfx` and keys going into the image,
`appsettings.Old.json`, the uploads folder, `bin/` and `obj/` in a source build. On the clean example app: no PROBLEM.

### 2.1 Which Dockerfile

| You have | Use | Build from |
|---|---|---|
| the source code (`.csproj`, `.cs` files) | `example-stack/web/Dockerfile` - two stages: the SDK image builds, the small runtime image runs | the folder with the `.csproj` |
| only the PUBLISHED folder (what "Publish" made: `MyApp.dll`, `MyApp.runtimeconfig.json`, `wwwroot/`) | `example-stack/web/Dockerfile.published` - runtime only, the app is already compiled | that folder |

Copy the `.dockerignore` next to it either way: it keeps `bin/`, `obj/` (Windows build output that breaks
the Linux build), certificates, keys and `.exe` files out of the image.

Change in the Dockerfile:
- **the .NET version**: the `<TargetFramework>` in the `.csproj` (`net8.0` -> `8.0`), or `"tfm"` in
  `MyApp.runtimeconfig.json`. `ARG DOTNET_VERSION=8.0`. `8.0` = the newest 8.0.x patch.
- **the image**: `aspnet` for a website / web API (`Microsoft.AspNetCore.App` is listed in the
  runtimeconfig.json), `runtime` for a console app or background service (only `Microsoft.NETCore.App`).
- **the .dll** in `ENTRYPOINT ["dotnet", "MyApp.dll"]`: the name of the `.csproj` / of the runtimeconfig.json.
  `MyApp.exe` is only the Windows starter; Linux runs the `.dll`.

Tested: both Dockerfiles built the example app (324 MB image) and it answered.

### 2.2 Port and HTTPS

- A .NET 8+ image listens on **plain HTTP port 8080** inside the container (.NET 6 / 7 images: port 80).
  The compose file publishes it: `"8080:8080"` = PC port : container port. Another container port:
  `ASPNETCORE_HTTP_PORTS=5000`. If the app names its own address (`UseUrls`, a `Kestrel` section in
  appsettings.json), that one wins and the log says `Overriding address(es)`.
- **HTTPS**: mount the certificate (`.pfx`) at run time - never copy it into the image - and name it:
  ```yaml
  environment:
    ASPNETCORE_URLS: https://+:8443;http://+:8080
    Kestrel__Certificates__Default__Path: /https/server.pfx
    Kestrel__Certificates__Default__Password: ${CERT_PASSWORD}
  volumes:
    - ./certs:/https:ro
  ports:
    - "8443:8443"
  ```
  Tested: the log said `Now listening on: https://0.0.0.0:8443` and `http://0.0.0.0:8080`, and both answered.
  (The other common way: the app speaks plain HTTP, and a reverse proxy - nginx, Caddy, IIS - does HTTPS in front.)

### 2.3 Settings: appsettings.json and env vars

ASP.NET Core reads `appsettings.json`, then `appsettings.Production.json` (the environment is
`ASPNETCORE_ENVIRONMENT`, `Production` when not set), then **env vars - they win**. An appsettings.json key as
an env var: every `:` becomes `__` (two underscores):

| appsettings.json | env var in compose |
|---|---|
| `"ConnectionStrings": { "Default": "..." }` | `ConnectionStrings__Default: Host=db;...` |
| `"Database": { "Kind": "postgres" }` | `Database__Kind: postgres` |
| `"Logging": { "LogLevel": { "Default": "Warning" } }` | `Logging__LogLevel__Default: Warning` |

So appsettings.json can keep the values for your PC, and compose sets the Docker ones - no file edits.
Tested: the example's appsettings.json says `Host=localhost`, compose says `Host=db`; the app connected to `db`.

### 2.4 What breaks when a Windows .NET app runs on Linux - check these

| In the app | On Linux | Fix |
|---|---|---|
| a path `C:\...` / `D:\...` in appsettings.json | does not exist | a Linux path in the env var (`/app/data/...`) + a volume there |
| `\` in a path in the code (`"images\\" + name`) | `\` is a normal character, not a folder separator | `Path.Combine` / `/` in the code |
| file names: `Images/Logo.PNG` asked as `images/logo.png` | Linux names are case-sensitive: 404 | the same case everywhere |
| an `.exe` it starts (ffmpeg.exe, a tool) | Linux cannot run it | the Linux program (`apt-get install ffmpeg` in the Dockerfile) |
| `System.Drawing.Common` (images, GDI+) | `PlatformNotSupportedException` since .NET 7 | a code change: ImageSharp / SkiaSharp |
| Windows login, Active Directory, the registry, the event log, WMI | not there | a code change |
| `web.config` (IIS) | ignored: no IIS in the container | its settings as env vars / appsettings |

### 2.5 What it writes

- **Data-protection keys** (they sign the login cookies): without a volume, every new container logs everyone
  out. `- web-keys:/root/.aspnet/DataProtection-Keys`.
- **Uploads, photos, exports, logs**: a volume or a PC folder (`- ./data/photos:/app/wwwroot/photos`). The
  same PC folder can be mounted into the worker too, when the worker writes what the dashboard shows.

---

## 3. The database - no Dockerfile

The official image, a few env vars, a volume. Everything is in the example's compose files.

| | PostgreSQL | MySQL |
|---|---|---|
| image | `postgres:16` (with pgvector: `pgvector/pgvector:pg16`) | `mysql:8.4` (MariaDB: `mariadb:11`) |
| env vars (first start only) | `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD` |
| data (the volume) | `/var/lib/postgresql/data` | `/var/lib/mysql` |
| scripts run on the first start | `/docker-entrypoint-initdb.d/*.sql` | the same |
| port inside the network | 5432 | 3306 |
| healthcheck | `pg_isready -U ... -d ...` | `mysqladmin ping -h 127.0.0.1 ...` |
| .NET connection string | `Host=db;Port=5432;Database=app;Username=app;Password=...` (Npgsql) | `Server=db;Port=3306;Database=app;User ID=app;Password=...` (MySqlConnector) |
| Python driver | `psycopg2-binary` | `PyMySQL` + `cryptography` (see section 7) |
| a shell in it | `docker compose exec db psql -U app -d app` | `docker compose exec db mysql -u app -p app` |

**Three rules:**
1. **The version of your data.** Use the MAJOR version your data comes from (`postgres:16` for 16). A data
   folder of 15 does not start on 16: move between versions with a dump (below).
2. **The env vars work only once.** `POSTGRES_PASSWORD` / `MYSQL_*` are used when the data volume is EMPTY -
   the first start. Changing them in .env later changes nothing in the database (section 7 says how to change
   a password). The same for the init scripts: on later starts the log says `Database directory appears to
   contain a database; Skipping initialization`.
3. **The data lives in the volume.** `docker compose down` keeps it; `docker compose down -v` DELETES it.
   Tested: down + up kept every row; down -v left an empty database.

**Your existing data into the container** (tested with both):
```bat
REM 1. a dump from where the data is now (the old server, or your PC's database)
pg_dump -h OLD_SERVER -U app -d app --clean --if-exists > backup.sql
mysqldump -h OLD_SERVER -u app -p app > backup.sql
REM 2. EITHER put it into the init folder before the FIRST start (db\postgres-init\02-data.sql) - it loads once
REM    OR load it into the running container:
docker compose exec -T db psql -U app -d app < backup.sql
docker compose exec -T db mysql -u app -pTHE_PASSWORD app < backup.sql
```
**A backup** of the running database: `docker compose exec -T db pg_dump -U app -d app --clean --if-exists > backup.sql`
(MySQL: `docker compose exec -T db mysqldump -u root -pROOT_PASSWORD app > backup.sql`). Run these in CMD,
not PowerShell: PowerShell has no `<`, and Windows PowerShell's `>` writes UTF-16, which psql / mysql cannot read.

SQL Server works the same way (`mcr.microsoft.com/mssql/server:2022-latest`, `ACCEPT_EULA=Y`,
`MSSQL_SA_PASSWORD`, data in `/var/opt/mssql`) - not tested here.

---

## 4. The network - the rules

1. **Containers in the same compose file reach each other by SERVICE NAME and the CONTAINER port**:
   `Host=db;Port=5432`, `DB_HOST=db`. Not the PC port, not an IP.
2. **`localhost` inside a container is that container itself.** Tested:
   `connection to server at "localhost" (127.0.0.1), port 5432 failed: Connection refused`.
3. **`ports:` are doors from your PC (and the network) INTO a container.** The containers do not need them to
   talk to each other. Publish only what people use: the web app. A database port only for tools on THIS PC,
   bound to 127.0.0.1 (`"127.0.0.1:5432:5432"`) so the rest of the network cannot reach it.
4. **From your PC to a container**: `localhost:` + the PC port (`http://localhost:8080`, pgAdmin to
   `localhost:5432`). Tested: psql on the PC reached the container's database this way.
5. **From a container to a program on your PC** (a database that still runs on Windows):
   `host.docker.internal` instead of localhost (Docker Desktop).
6. **From a container to another machine** (a camera, a server): its IP or name, as from your PC - nothing to set.
7. **Two compose files** (the dashboard + database in one, workers in another): give the network a fixed name in
   the first (`networks: default: name: myapp_net`), and join it from the second:
   ```yaml
   networks:
     default:
       name: myapp_net
       external: true
   ```
   Tested: a worker from a second compose file reached `db` by name. Not on the same network:
   `could not translate host name "db" to address: Name or service not known`.

---

## 5. Your ML program in the same system

- **Its Dockerfile**: the one X-Ray's plan wrote (`plans\NAME\Dockerfile`). In compose:
  ```yaml
  worker:
    build:
      context: C:\path\to\project
      dockerfile: C:\path\to\xray-tools\plans\NAME\Dockerfile
  ```
  or the image you already built: `image: name-slim`.
- **The database address** through env vars the code reads: `DB_HOST: db`, `DB_PORT: "5432"`. If the code
  has `localhost` or an IP written in it, that is a code change (`DB_HOST = os.getenv("DB_HOST", "localhost")`) -
  X-Ray's `code-changes.txt` lists such lines.
- **The GPU**: the `deploy:` block in the compose file (commented in the example).
- **Starting order**: `depends_on: db: condition: service_healthy` - it starts after the database answers. Still
  let the program retry its first connection (the example worker does): a database can restart later too.
- **The licence MAC** (GUIDE.md section 18.8): `mac_address: ${MAC_ADDRESS}` under the service, the
  value in .env. The MAC is a Docker setting: an env var alone does not change what the program reads.

---

## 6. Start, check, stop

Run in the folder of the compose file (with `-f compose.postgres.yml` while it has that name):

| Command | Does |
|---|---|
| `docker compose up -d --build` | build what changed, start everything in the background |
| `docker compose ps` | each service: running? `(healthy)`? |
| `docker compose logs -f web` | the web app's output, live (Ctrl+C stops watching, not the app) |
| `docker compose exec db psql -U app -d app` | a database shell inside the container |
| `docker compose restart worker` | restart one service |
| `docker compose up -d --build web` | rebuild and replace only the web app |
| `docker compose down` | stop and remove the containers - the volumes (data) stay |
| `docker compose down -v` | the same AND delete the volumes: the database is gone |

---

## 7. When something breaks (the messages are from the tests)

| You see | Meaning | Fix |
|---|---|---|
| `password authentication failed for user "app"` (PostgreSQL `28P01`) after you changed DB_PASSWORD | the database still has the password of its first start | set it inside: `docker compose exec db psql -U app -d app -c "ALTER USER app PASSWORD 'new';"` then `docker compose restart web worker` (or `down -v` if the data does not matter) |
| `'cryptography' package is required for sha256_password or caching_sha2_password auth methods` (Python + MySQL) | PyMySQL needs it for MySQL 8 logins | `cryptography` in requirements.txt. Tricky: it can work for a while, after another program logged in once |
| `could not translate host name "db" to address` | this container is not on the database's network | the same compose file, or the external network (4.7); check the service name |
| `Connection refused` to `localhost` / `127.0.0.1` | localhost is the container itself | the service name (`db`) |
| `Connection refused` to `db` | the database is not ready yet, or another port | `depends_on ... service_healthy`, retry in the program; the CONTAINER port (5432) |
| `relation "x" does not exist` | the init scripts did not run: the volume was not empty | load the script by hand (`psql ... < 01-schema.sql`) or `down -v` and start again |
| `port is already allocated` | another program on the PC uses that PC port | another PC port: `WEB_PORT_ON_PC=8081` in .env |
| the web app logs everyone out after a restart | no volume for the data-protection keys | the `web-keys` volume (2.5) |
| images / files: 404 in the container, fine on Windows | Linux file names are case-sensitive | the same case in the code and on disk |
| `required variable DB_PASSWORD is missing a value: put DB_PASSWORD in .env` | .env not filled in, or not next to the compose file | fill in .env in the compose file's folder |

---

## 8. The example - and how to make it yours

`example-stack/`:

| File | What it is |
|---|---|
| `compose.postgres.yml` / `compose.mysql.yml` | the whole system, with PostgreSQL / MySQL - every line has its reason |
| `.env.example` | the passwords and per-machine values: copy to `.env` |
| `web/` | a tiny .NET 8 web app (`/db` reads the worker's rows) + `Dockerfile`, `Dockerfile.published`, `.dockerignore` |
| `worker/` | a tiny Python worker that writes a row every 2 s + its Dockerfile |
| `db/postgres-init/`, `db/mysql-init/` | the first-start scripts (the table) |

`dotnet_check.py` (tools folder): reads a .NET app's folder and prints what its image and compose service need (2.0).

Run it as it is first (needs internet for the images and NuGet / pip):
```bat
cd example-stack
copy .env.example .env
notepad .env
docker compose -f compose.postgres.yml up -d --build
docker compose -f compose.postgres.yml ps
```
then open `http://localhost:8080/db`: `{"database":"postgres","server":"tcp://db:5432","detections":13}` -
the number grows every 2 s. Stop: `docker compose -f compose.postgres.yml down`.

Then swap in your parts, one at a time, checking `ps` and `logs` after each:
1. **your database**: the image version of your data; your dump into `db/postgres-init/` (or restore it, section 3).
2. **your .NET app**: run `dotnet_check.py` on it first (2.0). Then `build:` to your project (or its published
   folder) with the right Dockerfile (2.1);
   your connection string as `ConnectionStrings__<its name>`; its port (2.2); its folders as volumes (2.5).
   Go through 2.4 once.
3. **your ML programs**: `build:` / `image:` from X-Ray's plan (section 5), their DB env vars, GPU, shared folders.
4. **secrets** only in `.env`; certificates and keys mounted, never in an image.


---

## 9. Several projects that call each other - one system (xray_system.py)

Example: a toll program detects plates, saves a JSON file and sends it to a Fastag API; the Fastag API sends it on
to an ANPR API; the answer goes back. On one PC you started the two APIs, copied the addresses they printed
(`Running on http://...:5000`) into the next project, then started the toll. In Docker the three run together,
started in the right order, and find each other by NAME - no IPs to copy.

### 9.1 Run it

Step 1 for every project (each gets its map `runs\NAME\NAME.json`), then:
```bat
python xray_system.py --project toll=runs\toll\toll.json --project fastag=runs\fastag\fastag.json --project anpr=runs\anpr\anpr.json --out runs\system
notepad runs\system\system.txt
```
The NAME before `=` becomes the service name in compose - and the address the others use (`http://fastag:5000`).

### 9.2 What it reads, and what it prints

From each map: what the project LISTENS on (`app.run(port=5000)`, uvicorn ...) and what it CALLS (an address with a
port: `requests.post("http://...:5000/x")`, a database). It matches the two by the port, and prints:

```text
CONNECTIONS (who calls whom - matched by the port)
  toll -> fastag:5000   now http://127.0.0.1:5000/fastag   in compose http://fastag:5000/fastag   (env FASTAG_URL)
  fastag -> anpr:5001   now http://192.168.1.20:5001/anpr   in compose http://anpr:5001/anpr   (written in the code (app.py:13) -> env ANPR_URL after the change)

START ORDER (a server before the projects that call it)
  anpr -> fastag -> toll

MUST CHANGE (else the connection does not work)
  anpr: server.py:13: it listens on 127.0.0.1:5001 - inside its container only, so the projects that call it cannot reach it. Change it to 0.0.0.0, e.g. app.run(host="0.0.0.0", port=5001)

CODE CHANGES (so compose can set the addresses / folders)
  fastag: app.py:13: the address http://192.168.1.20:5001/anpr is written in the code - compose cannot change it. Read it from an env var: ANPR_URL = os.getenv("ANPR_URL", "http://192.168.1.20:5001/anpr")
  toll: main.py:15: the folder D:/toll/json is written in the code (a path of one PC). Read it from an env var - JSON_DIR = os.getenv("JSON_DIR", "D:/toll/json") - then compose gives toll and fastag the same folder

CHECK
  toll writes files into D:/toll/json (main.py:15) and fastag opens a file whose path comes from its input. If toll sends the file's PATH (not its content), both need the same folder at the same path ...
```
(the output of the test projects, shaped like toll / Fastag / ANPR)

The three kinds of change, and why:
- **A server on 127.0.0.1.** Flask's `app.run()` without a host prints `Running on http://127.0.0.1:5000`: it answers
  only inside its own container. `host="0.0.0.0"` = every address of the container.
- **An address written in the code.** Compose sets env vars; an address in the code does not read one. Two lines:
  `ANPR_URL = os.getenv("ANPR_URL", "<the old address>")` and use `ANPR_URL` where the address was. On your PC it
  still uses the old address; in compose it gets `http://anpr:5001/anpr`.
- **A folder of one PC written in the code** that another project must read (the toll sends the PATH of its JSON
  file): both containers get the same host folder at the same path, through an env var. (Compose cannot mount a
  folder at a path with `D:` in it - tested: `invalid volume specification` - so the env var is needed.)

After the changes, run Step 1 for the changed projects and `xray_system.py` again: MUST CHANGE and CODE CHANGES say
`nothing` / `none`.

### 9.3 The compose file it writes (runs\system\compose.yml)

```yaml
services:
  anpr:
    build: {context: ..., dockerfile: ...}       # X-Ray's slim plan, else Dockerfile.naive, else the project's Dockerfile
    healthcheck:                                  # "is it answering on 5001?" - Python is in the image, curl may not be
      test: ["CMD", "python", "-c", "import socket; socket.create_connection(('127.0.0.1', 5001), 3)"]
    # ports: ["5001:5001"]                        # only the others call it: not open to the network
  fastag:
    environment:
      ANPR_URL: http://anpr:5001/anpr             # the service NAME, not an IP
      JSON_DIR: /shared/toll-json
    depends_on:
      anpr: {condition: service_healthy}          # starts once anpr answers
    volumes: [./shared/toll-json:/shared/toll-json]
  toll:
    environment:
      FASTAG_URL: http://fastag:5000/fastag
      JSON_DIR: /shared/toll-json
    depends_on:
      fastag: {condition: service_healthy}
    volumes: [./shared/toll-json:/shared/toll-json]
    deploy: ...                                   # the GPU, when Step 1 found GPU use
networks:
  default: {name: system_net}
```
- a server nobody in the system calls (a dashboard, an API for outside) gets `ports:`; one only the others call does
  not (the comment shows the line, to call it from your PC while testing).
- **Tested** with the three test projects after the changes: anpr started, then fastag once anpr was healthy, then
  toll; every toll request went through fastag to anpr and back (`fastag answered 200
  {"anpr":{"plate":"AB12CD3456","valid":true},"fastag":"ok"}`), and the JSON files were in the shared folder.
- the start order only covers STARTING. If an API restarts later, the caller's next request fails until it is back:
  the caller should catch the error and try again (as the toll in the example does: it prints "not reachable" and
  carries on).

### 9.4 What it cannot know, and what you add

- **Two servers on the same port** (both Flask on 5000): it cannot tell which one a project calls - it says so, and
  `--link toll=fastag` tells it.
- **An address it cannot see** (read from a database, built from pieces at run time): not matched - add the env var
  by hand. Step 2's merged map (`runs\NAME\NAME-merged.json` instead of `NAME.json`) adds the addresses the run really
  called.
- **A database or another service outside these projects** (PostgreSQL on 5432 ...): listed under CALLS TO THINGS
  OUTSIDE, with a commented `db` service in compose. Already on a server: keep its address (from a container it is
  reached as from the PC). In this system: section 3.
- **Each project's own env vars** (models, settings): add them under `environment:` - `runs\NAME\run.env` lists them.
- **Space**: three projects with the same big packages (torch, CUDA) each build the same 4 GB again. One shared base
  image instead: `xray_compare.py` (Step 5 of the X-Ray guide) writes a base Dockerfile with the common packages and
  a small Dockerfile per project FROM it; then `--dockerfile NAME=that file` here.

---

## 10. The .NET app on the Windows PC itself (no container)

With the ASP.NET Core Hosting Bundle installed, a published .NET app runs on Windows directly. The containers
(database, ML programs) and the app then talk through the PC:

| Who calls | Whom | Address |
|---|---|---|
| the .NET app on Windows | a database in a container | `Host=localhost;Port=5432` - the compose file must publish it: `ports: ["127.0.0.1:5432:5432"]` |
| a container | the .NET app on Windows | `http://host.docker.internal:8080` (Docker Desktop; Docker Engine in WSL: add `extra_hosts: ["host.docker.internal:host-gateway"]` to the service) |
| other PCs | the .NET app | `http://THIS-PC:8080` - after IT opens the port in Windows Firewall |

**Without admin rights** - in the published folder:
```bat
dotnet YourApp.dll --urls http://0.0.0.0:8080
```
It runs while that window is open (`0.0.0.0` = also from other PCs; `localhost` = this PC only).

**In IIS** (needs admin: IIS Manager): Add Website -> physical path = the published folder, a port; its Application
Pool: .NET CLR version **No Managed Code** (that setting is for the old .NET Framework; the Hosting Bundle runs
the app with .NET 8 / 9 instead). The
`web.config` that Publish wrote tells IIS to start the app. After installing the Hosting Bundle, restart IIS once
(`iisreset` in an admin CMD). Settings for this machine: `appsettings.Production.json` next to the app, or env vars in
`web.config` (`<environmentVariables>` under `<aspNetCore>`).

What `dotnet_check.py` says still matters here: the port, the connection string, the certificate. Its Linux points
(`.exe` files, `C:\` paths, upper/lower case in file names) do not apply on Windows - they matter on the day the app
moves into a container.
