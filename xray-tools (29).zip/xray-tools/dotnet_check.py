#!/usr/bin/env python3
"""dotnet_check.py - read a .NET app folder and print what its Docker image and compose service depend on:
the .NET version and base image, the port, HTTPS, the database (wherever the connection string is: appsettings,
web.config, MyApp.dll.config, the code), the files it writes, Windows-only parts and native libraries, and what
goes into the image (with the .dockerignore lines). For ANY .NET app (a website, a web API, a worker service). It
only reads files: it runs nothing and changes nothing. Needs Python 3.8+ and nothing else.

    python dotnet_check.py "C:\\path\\to\\published-folder"        what "Publish" made: MyApp.dll + MyApp.runtimeconfig.json
    python dotnet_check.py "C:\\path\\to\\project"                 the source: the folder with MyApp.csproj
    python dotnet_check.py FOLDER --port 8080 > dotnet-check.txt   --port: the container port compose publishes

The published folder is checked best (it holds exactly what runs, the compiled code included). A Dockerfile in
the folder (or --dockerfile, with its NAME.dockerignore next to it) is checked against the app too.
SERVICES_GUIDE.md explains every line.

Passwords are never printed (shown as ***). IP addresses and names are: replace them with *** before you paste
the output anywhere outside your office.
"""
import argparse
import datetime
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

VERSION = "0.4.1"

# end of security fixes, per .NET version (Microsoft's support policy; .NET 9 was extended to 24 months)
SUPPORT_END = {"5.0": "2022-05-10", "6.0": "2024-11-12", "7.0": "2024-05-14",
               "8.0": "2026-11-10", "9.0": "2026-11-10", "10.0": "2028-11-14"}

# packages whose features only work on Windows (System.Drawing.Common: the text depends on its version, sdc_text)
WINDOWS_ONLY = {
    "System.Drawing.Common": "images through GDI+",
    "System.Management": "WMI: Windows only",
    "System.DirectoryServices": "Active Directory: partly Windows only",
    "System.DirectoryServices.AccountManagement": "Active Directory: Windows only",
    "Microsoft.Win32.Registry": "the registry: Windows only",
    "System.Diagnostics.EventLog": "the Windows event log: Windows only",
    "System.ServiceProcess.ServiceController": "Windows services: Windows only",
    "Microsoft.Extensions.Hosting.WindowsServices": "runs as a Windows service: in a container the app simply runs",
    "Microsoft.Windows.Compatibility": "the Windows compatibility pack",
    "System.Windows.Forms": "Windows Forms: Windows only",
}
# Microsoft libraries pull some of those in for their own Windows-only features (System.Windows.Extensions ->
# System.Drawing.Common, Microsoft.Extensions.Logging.EventLog -> System.Diagnostics.EventLog): harmless on Linux
MS_PREFIXES = ("System.", "Microsoft.Extensions.", "Microsoft.Data.", "Microsoft.Win32.", "Microsoft.NETCore.",
               "Microsoft.AspNetCore.")
# a native library is found on linux-x64 (the usual Docker image) under these RIDs
LINUX_RIDS = {"linux-x64", "linux", "unix", "any"}
# the package with a library's Linux build, when it is not "<library>.NativeAssets.Linux"
# (SkiaSharp: .NoDependencies needs nothing installed; SkiaSharp.NativeAssets.Linux also needs apt libfontconfig1)
LINUX_NATIVE = {"SkiaSharp": "SkiaSharp.NativeAssets.Linux.NoDependencies"}
# package -> (database, image for compose, its port). The first match per database is shown.
DATABASES = [
    ("Npgsql", "PostgreSQL", "postgres:16 (with pgvector: pgvector/pgvector:pg16)", 5432),
    ("Npgsql.EntityFrameworkCore.PostgreSQL", "PostgreSQL", "postgres:16", 5432),
    ("MySqlConnector", "MySQL / MariaDB", "mysql:8.4 or mariadb:11", 3306),
    ("MySql.Data", "MySQL", "mysql:8.4", 3306),
    ("Pomelo.EntityFrameworkCore.MySql", "MySQL / MariaDB", "mysql:8.4 or mariadb:11", 3306),
    ("MySql.EntityFrameworkCore", "MySQL", "mysql:8.4", 3306),
    ("Microsoft.Data.SqlClient", "SQL Server", "mcr.microsoft.com/mssql/server:2022-latest", 1433),
    ("System.Data.SqlClient", "SQL Server", "mcr.microsoft.com/mssql/server:2022-latest", 1433),
    ("Microsoft.EntityFrameworkCore.SqlServer", "SQL Server", "mcr.microsoft.com/mssql/server:2022-latest", 1433),
    ("Microsoft.Data.Sqlite", "SQLite (a FILE, no server)", None, None),
    ("Microsoft.EntityFrameworkCore.Sqlite", "SQLite (a FILE, no server)", None, None),
    ("Oracle.ManagedDataAccess.Core", "Oracle", None, 1521),
    ("MongoDB.Driver", "MongoDB", "mongo:7", 27017),
    ("StackExchange.Redis", "Redis", "redis:7", 6379),
]
NOTABLE = [("Pgvector", "pgvector: the database needs the extension - image pgvector/pgvector:pg16"),
           ("Microsoft.EntityFrameworkCore", "EF Core: the tables come from migrations - check how they are applied "
                                             "(Database.Migrate() at start, or dotnet ef / a SQL script)"),
           ("FirebaseAdmin", "Firebase push: needs internet to Google and a service-account file"),
           ("Microsoft.AspNetCore.SignalR", "SignalR (websockets): a reverse proxy in front must pass them"),
           ("Hangfire.Core", "Hangfire: background jobs, stored in the database"),
           ("Serilog.Sinks.File", "Serilog file logs: the log folder should be a volume")]

# identifiers looked up in the code (names of the methods/types it uses)
NAMES = {
    "port": ["UseUrls", "ListenAnyIP", "ListenLocalhost", "ConfigureKestrel", "UseKestrel"],
    "https": ["UseHttps", "UseHttpsRedirection", "UseHsts"],
    "keys": ["AddDataProtection", "PersistKeysToFileSystem", "PersistKeysToDbContext",
             "PersistKeysToStackExchangeRedis", "SetApplicationName", "ProtectKeysWithCertificate"],
    "process": ["ProcessStartInfo"],
    "mac": ["GetAllNetworkInterfaces", "GetPhysicalAddress"],
    "hostname": ["MachineName", "get_MachineName", "GetHostName"],
    "windows": ["RegistryKey", "EventLog", "WindowsIdentity", "WindowsPrincipal", "UseWindowsService",
                "ManagementObjectSearcher", "AddNegotiate"],
    "config": ["AddJsonFile", "AddXmlFile", "AddIniFile"],
    "writes": ["WriteAllText", "WriteAllBytes", "WriteAllTextAsync", "WriteAllBytesAsync", "AppendAllText",
               "AppendAllTextAsync", "CopyToAsync", "CreateDirectory", "SaveAs", "SaveAsync"],
    "certs": ["DangerousAcceptAnyServerCertificateValidator", "ServerCertificateCustomValidationCallback",
              "ServerCertificateValidationCallback", "RemoteCertificateValidationCallback"],
    "bodysize": ["RequestSizeLimitAttribute", "DisableRequestSizeLimitAttribute", "RequestSizeLimit",
                 "DisableRequestSizeLimit", "MaxRequestBodySize", "KestrelServerOptions", "ConfigureKestrel",
                 "IISServerOptions"],
}
# programs an app may start, and their Linux package
PROGRAMS = {"ffmpeg": "ffmpeg", "ffprobe": "ffmpeg", "wkhtmltopdf": "wkhtmltopdf", "wkhtmltoimage": "wkhtmltopdf",
            "tesseract": "tesseract-ocr", "soffice": "libreoffice", "libreoffice": "libreoffice",
            "gswin64c": "ghostscript", "gswin32c": "ghostscript", "magick": "imagemagick", "python": "python3",
            "node": "nodejs", "7z": "p7zip-full", "git": "git", "curl": "curl", "pg_dump": "postgresql-client",
            "mysqldump": "default-mysql-client"}
WINDOWS_PROGRAMS = {"cmd", "powershell", "pwsh", "wscript", "cscript", "explorer", "taskkill", "netsh", "sc", "wmic",
                    "notepad", "rundll32", "regedit", "msiexec"}

BACKUP_ENV_RE = re.compile(r"(?i)old|bak|backup|copy|orig|\d")   # appsettings.Old.json: a copy, not an environment
BACKUP_RE = re.compile(r"(?i)(-old\b|_old\b|\.old$|bkp|backup|_bak\b|\.bak$| - copy|-copy\b|_copy\b|\(\d+\))")
FILE_EXT_RE = re.compile(r"(?i)[\w .()-]+\.(exe|bat|cmd|sh|ps1|txt|log|json|xml|pfx|pem|key|crt|onnx|"
                         r"mp4|avi|mkv|m3u8|db|sqlite|csv|xlsx)$")
URL_RE = re.compile(r"(?i)\b(?:https?|rtsp|wss?|ftp)://[^\s\"'<>]+")
WIN_ABS_RE = re.compile(r"(?<![A-Za-z])[A-Za-z]:\\[^\"<>|*?\r\n]*")
UNC_RE = re.compile(r"^\\\\[\w.-]+\\[^\"<>|*?\r\n]+")
BACKSLASH_REL_RE = re.compile(r"^[\w.-]+(\\[\w .-]+)+$")
LINUX_ABS_RE = re.compile(r"^/(?:home|app|var|tmp|mnt|media|opt|srv|data|root)(?:/[^\s\"'<>]*)?$")
PROGRAM_RE = re.compile(r"(?i)(?:^|[\\/])([\w.-]+?)(\.exe)?$")
DATA_DIR_RE = re.compile(r"(?i)(upload|photo|capture|snapshot|detect|attachment|export|recording|report|log|temp|"
                         r"tmp|backup|document|download|media|video|face)")
LOCAL_RE = re.compile(r"(?i)//(localhost|127\.0\.0\.1|\[::1\])")
LOCAL_PORT_RE = re.compile(r"(?i)//(?:localhost|127\.0\.0\.1|\[::1\]):(\d+)")
# what a page's <script src> / <link href> / <img src> loads: the viewer's browser fetches it, not the app
BROWSER_EXT_RE = re.compile(r"(?i)\.(js|css|map|woff2?|ttf|eot|otf|svg|png|jpe?g|gif|ico|webp)$")
BROWSER_ATTR_RE = re.compile(r"(?i)(?:\b(?:src|href|srcset|action)\s*=\s*[\"']?|url\(\s*[\"']?)$")
# a machine on the office network: a private IPv4 address, a name without dots, an intranet name
LAN_HOST_RE = re.compile(r"(?i)^(?:(?:10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}|[a-z0-9-]+|"
                         r"[\w.-]+\.(?:local|lan|corp|internal|intranet|intra|home|localdomain))$")
CONN_HOST_KEYS = ("host", "server", "data source", "datasource", "address", "addr", "network address")
CONN_OTHER_KEYS = ("database", "initial catalog", "uid", "user id", "userid", "user", "username", "pwd", "password",
                   "port", "sslmode", "ssl mode", "integrated security", "trusted_connection")
KESTREL_MAX_BODY = 30000000     # Kestrel's default request size limit, in bytes
SKIP_DIRS = {"bin", "obj", ".vs", ".git", ".idea", "node_modules", "packages", "TestResults"}

problems, checks = [], []


def problem(msg):
    problems.append(msg)
    print("      -> PROBLEM: " + msg)


def check(msg):
    checks.append(msg)
    print("      -> CHECK: " + msg)


def note(msg):
    print("      -> " + msg)


def fact(label, text, ok=False):
    print("  %-21s %s%s" % (label, text, "   OK" if ok else ""))


# ---------- small helpers ----------

def scrub(text):
    """hide passwords, user:password@ in URLs, and secret query values"""
    text = re.sub(r"(?i)\b(password|pwd|passwd)\s*=\s*[^;\"']*", r"\1=***", text)
    text = re.sub(r"://[^/@\s:]+:[^/@\s]+@", "://***:***@", text)
    text = re.sub(r"(?i)([?&](?:key|token|secret|password|pwd|apikey|api_key|sig)=)[^&\s]*", r"\1***", text)
    return text


def secret_key(key):
    return bool(re.search(r"(?i)(password|secret|token|apikey|api_key|pwd)", key))


def load_json_lenient(path):
    """JSON as ASP.NET reads it: comments and trailing commas allowed"""
    try:
        with open(path, encoding="utf-8-sig") as f:
            text = f.read()
    except OSError as e:
        return None, str(e)
    out, i, n, in_str = [], 0, len(text), False
    while i < n:  # drop // and /* */ comments outside strings
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 1
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True
            out.append(c)
        elif text.startswith("//", i):
            while i < n and text[i] not in "\r\n":
                i += 1
            continue
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        else:
            out.append(c)
        i += 1
    cleaned, res, in_str, i = "".join(out), [], False, 0
    while i < len(cleaned):  # drop trailing commas
        c = cleaned[i]
        if in_str:
            res.append(c)
            if c == "\\" and i + 1 < len(cleaned):
                res.append(cleaned[i + 1])
                i += 1
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True
            res.append(c)
        elif c == ",":
            j = i + 1
            while j < len(cleaned) and cleaned[j] in " \t\r\n":
                j += 1
            if j >= len(cleaned) or cleaned[j] not in "}]":
                res.append(c)
        else:
            res.append(c)
        i += 1
    try:
        return json.loads("".join(res)), None
    except ValueError as e:
        return None, "not valid JSON (%s)" % e


def flatten(obj, prefix=""):
    """{"A": {"B": 1}} -> {"A:B": 1}, the way ASP.NET names config keys"""
    flat = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            flat.update(flatten(v, "%s:%s" % (prefix, k) if prefix else str(k)))
    elif isinstance(obj, list):
        for idx, v in enumerate(obj):
            flat.update(flatten(v, "%s:%d" % (prefix, idx)))
    else:
        flat[prefix] = obj
    return flat


def show(key, value):
    if value is None or value == "":
        return "%s = (empty)" % key
    if secret_key(key):
        return "%s = ***" % key
    return "%s = %s" % (key, scrub(str(value)))


def env_name(key):
    """an appsettings key as the env var that replaces it: ConnectionStrings:Default -> ConnectionStrings__Default"""
    return key.replace(":", "__")


def vs_leftover(name, value):
    """an env var Visual Studio writes into web.config while it debugs the app on IIS (hot reload, browser link):
    not the app's setting. In a container the first ones do nothing; DOTNET_STARTUP_HOOKS with its Windows path
    stops the app before it starts (tested)"""
    n = (name or "").upper()
    return (n.startswith(("ASPNETCORE_AUTO_RELOAD_", "DOTNET_WATCH")) or n == "DOTNET_MODIFIABLE_ASSEMBLIES"
            or (n in ("ASPNETCORE_HOSTINGSTARTUPASSEMBLIES", "DOTNET_STARTUP_HOOKS")
                and bool(re.search(r"(?i)BrowserRefresh|BrowserLink|DeltaApplier|WebTools", value or ""))))


def strings_in_binary(path):
    """(text literals, identifiers) in a .dll: the code's strings are stored as UTF-16,
    the names of the methods/types it uses as ASCII"""
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return set(), set()
    literals = {m.decode("utf-16-le") for m in re.findall(rb"(?:[\x20-\x7e]\x00){3,}", data)}
    names = {m.decode("ascii") for m in re.findall(rb"[A-Za-z_][A-Za-z0-9_]{2,}", data)}
    # a property is stored as get_X / set_X: keep X too, as the source code writes it
    names |= {n[4:] for n in names if n.startswith(("get_", "set_", "add_")) and len(n) > 6}
    return literals, names


def assembly_refs(paths, wanted):
    """which of these assemblies the app's own .dll files reference (their names are stored as ASCII + NUL)"""
    found = set()
    for p in paths:
        try:
            with open(p, "rb") as f:
                data = f.read()
        except OSError:
            continue
        found |= {w for w in wanted if (w + "\x00").encode("ascii") in data}
    return found


CS_STR_RE = re.compile(r'@"((?:[^"]|"")*)"|\$?"((?:[^"\\\r\n]|\\.)*)"')


def strings_in_source(path):
    """(string literals, identifiers) in a .cs / .cshtml / .razor file"""
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            text = f.read()
    except OSError:
        return set(), set()
    literals = set()
    for verb, reg in CS_STR_RE.findall(text):
        s = verb.replace('""', '"') if verb else reg.replace("\\\\", "\x00").replace('\\"', '"').replace("\x00", "\\")
        if len(s) >= 3:
            literals.add(s)
    return literals, set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b", text))


def ports_of(value):
    """ports named in a Kestrel URL / Urls value (a;b lists allowed)"""
    found = []
    for part in str(value).split(";"):
        part = part.strip()
        m = re.search(r":(\d{1,5})/?$", part)
        if m:
            found.append(int(m.group(1)))
        elif part.lower().startswith("https://"):
            found.append(443)
        elif part.lower().startswith("http://"):
            found.append(80)
    return found


def conn_parts(value):
    """the key=value parts of a database connection string, or None if the text is not one"""
    if not isinstance(value, str) or value.count("=") < 2 or ";" not in value or len(value) > 1000:
        return None
    parts = {}
    for p in value.split(";"):
        k, eq, v = p.partition("=")
        if eq:
            parts[k.strip().lower()] = v.strip()
    if any(k in parts for k in CONN_HOST_KEYS) and any(k in parts for k in CONN_OTHER_KEYS):
        return parts
    return None


def url_host(url):
    m = re.match(r"(?i)^[a-z]+://(?:[^/@\s]*@)?(\[[^\]]+\]|[^/:?#\s]+)", url)
    return m.group(1).lower() if m else ""


def native_stem(path):
    """libSkiaSharp.dylib / libSkiaSharp.dll / libSkiaSharp.so -> skiasharp: one library, built for each OS"""
    base = re.sub(r"(?i)\.(dll|dylib|so(\.\d+)*|a)$", "", os.path.basename(path)).lower()
    return base[3:] if base.startswith("lib") and len(base) > 3 else base


def chain_to(graph, root, target):
    """the packages from the app to a package: [app, A, B, target] (the shortest way), or []"""
    prev, todo = {root: None}, [root]
    while todo:
        nxt = []
        for n in todo:
            for d in graph.get(n, []):
                if d not in prev:
                    prev[d] = n
                    nxt.append(d)
        todo = nxt
    if target not in prev:
        return []
    path = [target]
    while prev[path[-1]] is not None:
        path.append(prev[path[-1]])
    return path[::-1]


def sdc_text(version):
    """System.Drawing.Common on Linux: before 6.0 it draws through libgdiplus, from 6.0 on it throws"""
    try:
        major = int(str(version).split(".")[0])
    except ValueError:
        major = None
    gdi = ("on Linux it draws through libgdiplus, which the .NET images do not have: the first use stops with "
           "DllNotFoundException: libgdiplus. In the Dockerfile: RUN apt-get update && apt-get install -y "
           "--no-install-recommends libgdiplus && rm -rf /var/lib/apt/lists/*")
    pnse = ("version 6 and newer throw PlatformNotSupportedException on Linux - the fix is in the code "
            "(ImageSharp or SkiaSharp)")
    if major is None:
        return "images through GDI+: before version 6 %s; %s" % (gdi, pnse)
    return "images through GDI+: " + (gdi if major < 6 else pnse)


def read_webconfig(path):
    """what IIS gives the app (web.config): env vars, the request size limit"""
    try:
        tree = ET.parse(path)
    except (ET.ParseError, OSError):
        return None
    info = {"env": [], "max_body": None}
    for el in tree.getroot().iter():
        tag = el.tag.split("}")[-1]
        if tag == "environmentVariable" and el.get("name"):
            info["env"].append((el.get("name"), el.get("value", "")))
        elif tag == "requestLimits" and (el.get("maxAllowedContentLength") or "").isdigit():
            info["max_body"] = int(el.get("maxAllowedContentLength"))
    return info


def read_netfx_config(path):
    """connectionStrings and appSettings of an app.config / MyApp.dll.config (read by ConfigurationManager)"""
    try:
        root_el = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None
    conns = [(a.get("name", "?"), a.get("connectionString", "")) for a in root_el.findall("./connectionStrings/add")]
    sets = [(a.get("key", "?"), a.get("value", "")) for a in root_el.findall("./appSettings/add")]
    return conns, sets


def plural(n, word):
    return "%d %s%s" % (n, word, "" if n == 1 else "s")


def mb(n):
    return "%.1f MB" % (n / 1048576.0) if n >= 104858 else "%d KB" % max(1, round(n / 1024.0))


def dockerignore_rules(path):
    rules = []
    if not path or not os.path.isfile(path):
        return rules
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            neg = line.startswith("!")
            pat = (line[1:] if neg else line).strip().replace("\\", "/").strip("/")
            if pat.startswith("./"):
                pat = pat[2:]
            rx, i = "", 0
            while i < len(pat):
                if pat.startswith("**/", i):
                    rx, i = rx + "(?:.*/)?", i + 3
                elif pat.startswith("**", i):
                    rx, i = rx + ".*", i + 2
                elif pat[i] == "*":
                    rx, i = rx + "[^/]*", i + 1
                elif pat[i] == "?":
                    rx, i = rx + "[^/]", i + 1
                else:
                    rx, i = rx + re.escape(pat[i]), i + 1
            rules.append((neg, line, re.compile("^" + rx + "$")))
    return rules


def ignored_by(relpath, rules):
    """the rule that leaves this path out, or None (a rule on a folder covers what is inside)"""
    parts = relpath.split("/")
    candidates = ["/".join(parts[:k]) for k in range(1, len(parts) + 1)]
    hit = None
    for neg, line, rx in rules:
        if any(rx.match(c) for c in candidates):
            hit = None if neg else line
    return hit


def major_minor(text):
    m = re.search(r"(\d+)\.(\d+)", str(text or ""))
    return "%s.%s" % (m.group(1), m.group(2)) if m else None


def image_default_port(ver):
    """the port a mcr.microsoft.com/dotnet image listens on when nothing else is set"""
    try:
        return 8080 if int(str(ver).split(".")[0]) >= 8 else 80
    except ValueError:
        return None


# ---------- the app: a published folder or a project (source) ----------

def read_published(root, rc_name):
    """what a published folder says about the app"""
    app = rc_name[: -len(".runtimeconfig.json")]
    rc, _err = load_json_lenient(os.path.join(root, rc_name))
    rc = (rc or {}).get("runtimeOptions", {})
    fws = rc.get("frameworks") or ([rc["framework"]] if "framework" in rc else [])
    info = {"mode": "published", "app": app, "dll": app + ".dll", "tfm": rc.get("tfm", "?"),
            "web": any(f.get("name") == "Microsoft.AspNetCore.App" for f in fws),
            "fw_names": [f.get("name", "?") for f in fws], "fw_version": next(
                (f.get("version") for f in fws if f.get("name") == "Microsoft.AspNetCore.App"), None),
            "self_contained": bool(rc.get("includedFrameworks")), "packages": {}, "projects": [], "rid": "",
            "native": [], "no_linux": [], "graph": {}, "deps_error": None, "settings_dir": root, "flags": [],
            "roll_forward": str(rc.get("rollForward") or "")}
    deps, err = load_json_lenient(os.path.join(root, app + ".deps.json"))
    if not deps:
        info["deps_error"] = err or "missing"
        return info
    target = (deps.get("runtimeTarget") or {}).get("name", "")
    rid = target.split("/", 1)[1] if "/" in target else ""
    info["rid"] = rid
    tlibs = (deps.get("targets") or {}).get(target, {})
    for key, lib in (deps.get("libraries") or {}).items():
        name, _, v = key.partition("/")
        if lib.get("type") == "project":
            info["projects"].append((name, tlibs.get(key, {})))
        elif lib.get("type") == "package":
            info["packages"][name] = v
    libs = {}        # one native library (libSkiaSharp), built for several OSes, often by several packages
    for key, t in tlibs.items():
        name = key.partition("/")[0]
        info["graph"][name] = list((t.get("dependencies") or {}).keys())
        if rid and not rid.startswith("linux") and t.get("native"):
            info["native"].append((name, "Windows libraries: " + ", ".join(sorted(t["native"]))))
        for path, asset in (t.get("runtimeTargets") or {}).items():
            if asset.get("assetType") == "native":
                lib = libs.setdefault(native_stem(path), {"file": re.sub(r"\.[^.]+$", "", os.path.basename(path)),
                                                          "rids": set(), "packages": set()})
                lib["rids"].add(asset.get("rid", ""))
                lib["packages"].add(name)
    if not rid:      # a portable app: the host picks each library's build for the OS it runs on
        info["no_linux"] = [lib for _s, lib in sorted(libs.items()) if not lib["rids"] & LINUX_RIDS]
    return info


def read_csproj(path, seen=None):
    """(properties, packages, referenced projects) of a .csproj"""
    seen = seen if seen is not None else set()
    props, packages, refs = {}, {}, []
    try:
        tree = ET.parse(path)
    except (ET.ParseError, OSError):
        return props, packages, refs
    root_el = tree.getroot()
    props["Sdk"] = root_el.get("Sdk", "")
    for el in root_el.iter():
        tag = el.tag.split("}")[-1]
        if tag == "PackageReference" and el.get("Include"):
            packages[el.get("Include")] = el.get("Version") or (el.findtext("Version") or "")
        elif tag == "ProjectReference" and el.get("Include"):
            refs.append(os.path.normpath(os.path.join(os.path.dirname(path), el.get("Include").replace("\\", os.sep))))
        elif tag in ("TargetFramework", "TargetFrameworks", "AssemblyName", "OutputType", "UseWindowsForms", "UseWPF",
                     "RuntimeIdentifier", "RuntimeIdentifiers", "SelfContained") and (el.text or "").strip():
            props.setdefault(tag, el.text.strip())
    for r in refs:     # the libraries it references bring their packages too
        if r not in seen and os.path.isfile(r):
            seen.add(r)
            packages.update(read_csproj(r, seen)[1])
    return props, packages, refs


def read_source(root, csprojs):
    """what a project folder (the source) says about the app; the web project when there are several"""
    parsed = [(p, read_csproj(os.path.join(root, p))) for p in csprojs]
    web = [x for x in parsed if x[1][0].get("Sdk", "").endswith(".Web")]
    path, (props, packages, refs) = (web or parsed)[0]
    tfm = (props.get("TargetFramework") or props.get("TargetFrameworks", "?")).split(";")[0]
    app = props.get("AssemblyName") or os.path.splitext(os.path.basename(path))[0]
    sdk = props.get("Sdk", "")
    flags = []
    if props.get("UseWindowsForms", "").lower() == "true" or props.get("UseWPF", "").lower() == "true":
        flags.append("UseWindowsForms / UseWPF: a Windows desktop app - it cannot run in a Linux container")
    if "-windows" in tfm:
        flags.append("TargetFramework %s: built for Windows only" % tfm)
    if props.get("OutputType", "").lower() == "winexe":
        flags.append("OutputType WinExe: a Windows program with a window")
    return {"mode": "source", "app": app, "dll": app + ".dll", "tfm": tfm, "web": sdk.endswith(".Web"),
            "fw_names": [sdk or "?"], "fw_version": None, "self_contained": props.get("SelfContained", "").lower() == "true",
            "packages": packages, "projects": [], "rid": props.get("RuntimeIdentifier", ""), "native": [],
            "no_linux": [], "graph": {}, "deps_error": None, "settings_dir": os.path.join(root, os.path.dirname(path)),
            "flags": flags, "csproj": path, "other_projects": [p for p, _x in parsed if p != path],
            "roll_forward": props.get("RollForward", "")}


def read_dockerfile(path):
    """the final stage of a Dockerfile: its FROM image, ENV, EXPOSE and the .dll it starts"""
    info = {"path": path, "from": None, "env": {}, "expose": [], "dll": None}
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            text = f.read()
    except OSError:
        return None
    info["text"] = text
    text = re.sub(r"\\\r?\n", " ", text)
    args = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        word, _, rest = line.partition(" ")
        word, rest = word.upper(), rest.strip()
        if word == "ARG" and "=" in rest:
            k, _, v = rest.partition("=")
            args[k.strip()] = v.strip().strip('"')
        elif word == "FROM":
            img = re.sub(r"(?i)\s+AS\s+\S+$", "", rest).split()[-1] if rest else ""
            img = re.sub(r"\$\{(\w+)\}|\$(\w+)", lambda m: args.get(m.group(1) or m.group(2), m.group(0)), img)
            info.update({"from": img, "env": {}, "expose": [], "dll": None})
        elif word == "ENV":
            pairs = re.findall(r'(\w+)=("[^"]*"|\S+)', rest)
            if pairs:
                info["env"].update({k: v.strip('"') for k, v in pairs})
            elif rest:
                k, _, v = rest.partition(" ")
                info["env"][k] = v.strip()
        elif word == "EXPOSE":
            info["expose"] += [int(p) for p in re.findall(r"\d+", rest)]
        elif word in ("ENTRYPOINT", "CMD"):
            m = re.search(r"([\w.-]+\.dll)", rest)
            if m:
                info["dll"] = m.group(1)
    return info


# ---------- the checks ----------

def main():
    ap = argparse.ArgumentParser(description="Read a .NET app folder (published, or the source with its .csproj); "
                                             "print what its Docker image and compose service need.")
    ap.add_argument("folder", help="the published folder (MyApp.dll + MyApp.runtimeconfig.json) or the project folder "
                                   "(MyApp.csproj)")
    ap.add_argument("--port", type=int, help="the CONTAINER port your compose file publishes (the right side of "
                                             "\"8080:8080\") - checked against where the app listens")
    ap.add_argument("--environment", default="Production",
                    help="ASPNETCORE_ENVIRONMENT in the container (default: Production, as when it is not set)")
    ap.add_argument("--dockerfile", help="default: Dockerfile in the folder")
    ap.add_argument("--dockerignore", help="default: NAME.dockerignore next to the --dockerfile, else "
                                           "Dockerfile.dockerignore or .dockerignore in the folder")
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass

    root = os.path.abspath(args.folder)
    if not os.path.isdir(root):
        print("not a folder: %s" % root)
        return 2
    print("dotnet_check %s - read-only check of a .NET app, for its Docker image (SERVICES_GUIDE.md)" % VERSION)
    print("folder: %s" % root)

    # the Dockerfile next to it (part 8 checks it; parts 1, 2 and 4 look at what it adds)
    dpath = args.dockerfile or next((os.path.join(root, f) for f in ("Dockerfile",) if os.path.isfile(os.path.join(root, f))),
                                    None)
    df = read_dockerfile(dpath) if dpath else None
    dtext = (df or {}).get("text", "").lower()

    # ---- 1. APP ----
    print("\n1. APP")
    rcs = sorted(f for f in os.listdir(root) if f.endswith(".runtimeconfig.json")
                 and not f.endswith(".dev.runtimeconfig.json"))
    csprojs = sorted(f for f in os.listdir(root) if f.endswith(".csproj"))
    if not csprojs and not rcs:          # a solution folder: the projects one level down
        csprojs = sorted(os.path.join(d, f) for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))
                         and d not in SKIP_DIRS for f in os.listdir(os.path.join(root, d)) if f.endswith(".csproj"))
    if rcs:
        a = read_published(root, rcs[0])
        fact("folder", "PUBLISHED app (what Publish made) -> Dockerfile.published of example-stack", ok=True)
    elif csprojs:
        a = read_source(root, csprojs)
        fact("folder", "SOURCE code (%s) -> the two-stage Dockerfile of example-stack (SDK builds, runtime runs)"
             % a["csproj"], ok=True)
        if a["other_projects"]:
            note("more projects: %s - the Dockerfile must COPY every .csproj before dotnet restore"
                 % ", ".join(a["other_projects"]))
        note("checked from the source; the PUBLISHED folder is checked more exactly (dotnet publish -c Release -o out)")
    else:
        fact("folder", "no *.runtimeconfig.json and no *.csproj here")
        problem("this is neither a published .NET app folder nor a project folder (or it is a single-file .exe): "
                "give the folder with MyApp.runtimeconfig.json, or the one with MyApp.csproj")
        return 1
    for fl in a["flags"]:
        problem(fl)
    if a["mode"] == "published":
        if os.path.isfile(os.path.join(root, a["dll"])):
            fact("start file", '%s  -> ENTRYPOINT ["dotnet", "%s"]' % (a["dll"], a["dll"]))
        else:
            fact("start file", "%s is MISSING" % a["dll"])
            problem("%s is missing: there is nothing for dotnet to run" % a["dll"])
    else:
        fact("start file", '%s (after publish)  -> ENTRYPOINT ["dotnet", "%s"]' % (a["dll"], a["dll"]))
    ver = major_minor(re.sub(r"^net", "", a["tfm"])) if re.match(r"net\d", a["tfm"]) else None
    kind = "aspnet" if a["web"] else "runtime"
    if a["self_contained"]:
        fact("publish", "self-contained: the .NET runtime is inside the folder")
        check("a self-contained app brings its own runtime for one OS: base image "
              "mcr.microsoft.com/dotnet/runtime-deps:%s, ENTRYPOINT [\"./%s\"] (built for linux-x64), or publish "
              "it again framework-dependent" % (ver or "8.0", a["app"]))
    elif a["web"]:
        fact("target", "%s - a web app: needs ASP.NET Core %s%s" % (a["tfm"], ver or "?", (
            " (%s or a newer %s.x patch)" % (a["fw_version"], ver)) if a["fw_version"] else ""))
    else:
        fact("target", "%s - frameworks: %s" % (a["tfm"], ", ".join(a["fw_names"]) or "none"))
        note("no ASP.NET Core: a console app / worker service - base image mcr.microsoft.com/dotnet/runtime, no port")
    if ver:
        fact("base image", "mcr.microsoft.com/dotnet/%s:%s  (ARG DOTNET_VERSION=%s)" % (kind, ver, ver), ok=True)
        end = SUPPORT_END.get(ver)
        if end:
            try:
                days = (datetime.date.fromisoformat(end) - datetime.date.today()).days
                when = "ENDED on %s" % end if days < 0 else "end on %s (in %d days)" % (end, days)
            except ValueError:
                days, when = 9999, "end in %s" % end
            fact("support", "security fixes for .NET %s %s" % (ver, when))
            dm = re.search(r"(?i)/dotnet/(?:aspnet|runtime):(\d+)\.", (df or {}).get("from") or "")
            roll = (df or {}).get("env", {}).get("DOTNET_ROLL_FORWARD", "") or a.get("roll_forward", "")
            if days < 120 and dm and int(dm.group(1)) > int(ver.split(".")[0]) and roll.lower() in ("major",
                                                                                                    "latestmajor"):
                fact("  in the Dockerfile", ".NET %s.0 runs it (DOTNET_ROLL_FORWARD=%s): that one gets the fixes"
                     % (dm.group(1), roll), ok=True)
            elif days < 120:
                msg = (".NET %s gets no security fixes after %s (the image keeps working, without fixes). The real "
                       "move to .NET 10 (LTS, to Nov 2028) needs the source code: TargetFramework net10.0, publish "
                       "again, DOTNET_VERSION=10.0" % (ver, end))
                if a["mode"] == "published" and not a["self_contained"] and ver != "10.0":
                    msg += (". Without the source, as a stop-gap: image %s:10.0 + ENV DOTNET_ROLL_FORWARD=Major runs "
                            "this .NET %s app on .NET 10 - test every page" % (kind, ver))
                check(msg)

    # the text inside the app's own code
    literals, names, scanned, own_dlls = set(), set(), [], []
    if a["mode"] == "published":
        own = [os.path.join(root, a["dll"])] + [os.path.join(root, os.path.basename(p)) for _, t in a["projects"]
                                               for p in (t.get("runtime") or {}) if p.lower().endswith(".dll")]
        own.append(os.path.join(root, a["app"] + ".Views.dll"))
        for p in dict.fromkeys(own):
            if os.path.isfile(p):
                lit, nm = strings_in_binary(p)
                literals |= lit
                names |= nm
                scanned.append(os.path.basename(p))
                own_dlls.append(p)
    else:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and d != "wwwroot"]
            for fn in filenames:
                if fn.endswith((".cs", ".cshtml", ".razor")):
                    lit, nm = strings_in_source(os.path.join(dirpath, fn))
                    literals |= lit
                    names |= nm
                    scanned.append(fn)
    uses = {group: [n for n in lst if n in names] for group, lst in NAMES.items()}
    # the addresses in the code: what the app may call, and what its pages make the BROWSER load (CDN scripts)
    code_urls, page_urls = set(), set()
    for s in literals:
        for m in URL_RE.finditer(s):
            u = m.group(0)
            if re.search(r"(?i)//(localhost|127\.0\.0\.1|\*|\+|0\.0\.0\.0|\[::\])", u) or re.search(
                    r"(?i)(w3\.org|schemas\.|xmlsoap|microsoft\.com/|aka\.ms|go\.microsoft|asp\.net|nuget\.org|"
                    r"github\.com/dotnet)", u):
                continue
            path = re.split(r"[?#]", u)[0]
            if BROWSER_EXT_RE.search(path) or BROWSER_ATTR_RE.search(s[max(0, m.start() - 12):m.start()]):
                page_urls.add(scrub(u))
            else:
                code_urls.add(scrub(u))
    code_urls, page_urls = sorted(code_urls), sorted(page_urls)

    def label(n):
        return "%s %s" % (n, a["packages"][n]) if n in a["packages"] else n

    # ---- 2. RUNS ON LINUX? ----
    print("\n2. RUNS ON LINUX?")
    packages = a["packages"]
    if a["deps_error"]:
        fact("deps.json", a["deps_error"])
        check("no readable %s.deps.json: the packages were not checked" % a["app"])
    if a["mode"] == "published" and not a["deps_error"]:
        rid = a["rid"]
        if not rid:
            fact("publish", "portable (any OS)", ok=True)
        elif rid.startswith("linux"):
            fact("publish", "for %s" % rid, ok=True)
        else:
            fact("publish", "for %s only" % rid)
            check("published for %s: Windows-specific parts were chosen when it was published. Fine if nothing "
                  "below is a PROBLEM; the clean way is a portable or linux-x64 publish (needs the source)" % rid)
        for name, what in a["native"]:
            fact("native code", "%s: %s" % (name, what))
            problem("%s has no Linux version of its native library: it fails when used. The fix is a package "
                    "change in the source (e.g. a *.NativeAssets.Linux package) and a new publish" % name)
        for lib in a["no_linux"]:   # one library (libSkiaSharp), built only for other OSes, by one or more packages
            fams = sorted({re.sub(r"\.NativeAssets\..*$", "", p) for p in lib["packages"] if ".NativeAssets." in p})
            fam = fams[0] if fams else sorted(lib["packages"])[0]
            fver = packages.get(fam) or packages.get(sorted(lib["packages"])[0], "")
            rids = ", ".join(sorted(lib["rids"]))
            fact("native code", "%s (%s %s): only for %s - no Linux build" % (lib["file"], fam, fver, rids))
            chain = chain_to(a["graph"], a["app"], fam)
            if len(chain) > 2:
                note("comes in through: " + " -> ".join(label(n) for n in chain[1:]))
            linux_pkg = LINUX_NATIVE.get(fam, fam + ".NativeAssets.Linux") if fams else None
            if dtext and (lib["file"].lower() + ".so" in dtext or (linux_pkg or "\0").lower() in dtext):
                fact("  in the Dockerfile", "it adds the Linux build", ok=True)
                continue
            fix = ("With the source: add the package %s %s and publish again. Without the source: the Dockerfile "
                   "adds %s.so from that package (SERVICES_GUIDE 2.4)" % (linux_pkg, fver, lib["file"])
                   if linux_pkg else "The fix: a Linux build of that library (a package for Linux, or the .so next to "
                                     "the app in the image)")
            problem("%s is in the folder only for %s - not for Linux: the first time the app uses %s it stops with "
                    "DllNotFoundException: %s. %s" % (lib["file"], rids, fam, lib["file"], fix))
        if not a["native"] and not a["no_linux"]:
            fact("native code", "nothing Windows-only", ok=True)
    elif a["mode"] == "source" and a["rid"] and not a["rid"].startswith(("linux", "any")):
        fact("RuntimeIdentifier", a["rid"])
        check("the .csproj names %s: the Dockerfile's dotnet publish must build for Linux - remove it or add "
              "-r linux-x64 to the publish line" % a["rid"])
    win = sorted(n for n in packages if n in WINDOWS_ONLY)
    own_asm = assembly_refs(own_dlls, win + ["System.Configuration.ConfigurationManager"])
    for n in win:
        v = packages[n]
        what = sdc_text(v) if n == "System.Drawing.Common" else WINDOWS_ONLY[n]
        fact("package", label(n))
        who = "the project references it"
        if a["mode"] == "published":
            parents = sorted(p for p, ds in a["graph"].items() if n in ds and p != a["app"])
            chain = chain_to(a["graph"], a["app"], n)
            if len(chain) > 2:
                note("comes in through: " + " -> ".join(label(x) for x in chain[1:]))
            if n not in own_asm and parents and all(p.startswith(MS_PREFIXES) for p in parents):
                note("your code does not use it; %s pull%s it in for Windows-only features: harmless on Linux"
                     % (", ".join(parents), "s" if len(parents) == 1 else ""))
                continue
            who = "your code uses it" if n in own_asm else "used by %s, not by your code" % ", ".join(parents or ["?"])
        if n == "System.Drawing.Common" and "libgdiplus" in dtext and "libgdiplus" in what:
            fact("  in the Dockerfile", "libgdiplus is installed", ok=True)
            continue
        check("%s %s (%s): %s. Harmless if that part never runs" % (n, v, who, what))
    if not win:
        fact("packages", "%d, none of them Windows-only" % len(packages), ok=True)
    found = ["%s %s (%s)" % (n, packages[n], why) for n, why in NOTABLE if n in packages]
    for x in found:
        fact("notable", x)
    if uses["windows"]:
        fact("Windows APIs", ", ".join(uses["windows"]))
        check("the code uses Windows-only APIs (%s): they fail on Linux if they are reached (the registry, the "
              "event log, Windows login, WMI) - look at where" % ", ".join(uses["windows"]))

    # settings, as ASP.NET Core loads them
    env = args.environment
    sdir = a["settings_dir"]
    settings_files = sorted(f for f in os.listdir(sdir) if re.match(r"(?i)^appsettings.*\.json$", f))
    loaded = [f for f in settings_files if f.lower() in ("appsettings.json", "appsettings.%s.json" % env.lower())]
    loaded.sort(key=lambda f: f.lower() != "appsettings.json")  # appsettings.json first, then the env file
    config = {}
    for f in loaded:  # later files win, as in ASP.NET
        data, err = load_json_lenient(os.path.join(sdir, f))
        if data is None:
            fact(f, err)
            problem("%s cannot be read (%s): the app will fail at start" % (f, err))
            continue
        for k, v in flatten(data).items():
            config[k] = (v, f)
    # what IIS gave the app (web.config), and the old-style config file ConfigurationManager reads
    wc = read_webconfig(os.path.join(sdir, "web.config")) if os.path.isfile(os.path.join(sdir, "web.config")) else None
    nf_name = next((f for f in ([a["app"] + ".dll.config"] if a["mode"] == "published" else ["app.config", "App.config"])
                    if os.path.isfile(os.path.join(sdir, f))), None)
    nf = read_netfx_config(os.path.join(sdir, nf_name)) if nf_name else None

    # ---- 3. PORT AND CERTIFICATE ----
    print("\n3. PORT AND CERTIFICATE")
    ep_urls = {k: v for k, v in config.items() if re.match(r"(?i)^Kestrel:Endpoints:[^:]+:Url$", k)}
    top_urls = {k: v for k, v in config.items() if k.lower() in ("urls", "http_ports", "https_ports")}
    app_ports, https_ports, local_only = [], [], []
    for k, (v, f) in sorted(ep_urls.items()) + sorted(top_urls.items()):
        fact(f, show(k, v))
        if k.lower() in ("http_ports", "https_ports"):
            got = [int(p) for p in re.findall(r"\d+", str(v))]
            https_ports += got if k.lower() == "https_ports" else []
        else:
            got = ports_of(v)
            https_ports += ports_of(";".join(u for u in str(v).split(";") if u.strip().lower().startswith("https")))
        if LOCAL_RE.search(str(v)):
            local_only.append((k, str(v)))
        else:
            app_ports += got
    for k, v in local_only:
        msg = ("%s = %s: in a container localhost is the container itself; nobody outside reaches it. In compose "
               "set %s: %s" % (k, v, env_name(k), LOCAL_RE.sub("//*", v)))
        (check if app_ports else problem)(msg + (" (only if you need this endpoint)" if app_ports else ""))
    if uses["port"]:
        port_lits = sorted(s for s in literals if re.search(r"^(https?://)?[\w*+.\[\]-]*:\d{2,5}/?$", s))
        fact("in the code", ", ".join(uses["port"]) + ("  addresses: " + ", ".join(port_lits) if port_lits else ""))
    listen, where = sorted(set(app_ports)), "the app's settings"
    if not listen and local_only:        # only localhost addresses: once fixed (* instead of localhost), these ports
        listen, where = sorted({p for k, v in local_only for p in ports_of(v)}), "the app's settings (after the fix above)"
    if ep_urls or top_urls:
        note("the app names its own address: ASPNETCORE_URLS / ASPNETCORE_HTTP_PORTS are not used (the log says "
             "\"Overriding address(es)\")")
    elif any(n in uses["port"] for n in ("UseUrls", "ListenAnyIP", "ListenLocalhost")):
        listen, where = [], "the code"
        check("the code sets its own address (%s): find the port in the log line \"Now listening on:\" and "
              "publish that one" % ", ".join(uses["port"]))
    elif df and (df["env"].get("ASPNETCORE_URLS") or df["env"].get("ASPNETCORE_HTTP_PORTS")
                 or df["env"].get("ASPNETCORE_HTTPS_PORTS")):
        e = df["env"]
        listen = sorted(set(ports_of(e.get("ASPNETCORE_URLS", "")) + [int(p) for p in re.findall(
            r"\d+", e.get("ASPNETCORE_HTTP_PORTS", "") + ";" + e.get("ASPNETCORE_HTTPS_PORTS", ""))]))
        where = "the Dockerfile's ENV"
        https_ports += ports_of(";".join(u for u in e.get("ASPNETCORE_URLS", "").split(";")
                                         if u.strip().lower().startswith("https")))
        if LOCAL_RE.search(e.get("ASPNETCORE_URLS", "")):
            problem("the Dockerfile's ASPNETCORE_URLS names localhost: nobody outside the container reaches it - "
                    "use + or *, e.g. http://+:8080")
    elif a["web"] and ver:
        listen, where = [image_default_port(ver)], "the .NET %s image's default" % ver
    if a["web"]:
        if listen:
            fact("listens on", "%s (%s)%s" % (", ".join(map(str, listen)), where,
                                              "; HTTPS on %s" % ", ".join(map(str, sorted(set(https_ports))))
                                              if https_ports else ""))
            if args.port and args.port not in listen:
                problem("compose publishes into container port %d, but the app listens on %s: ports: \"PC_PORT:%d\" "
                        "(left = the port people open, right = the app's port)" % (args.port, ", ".join(
                            map(str, listen)), listen[0]))
            elif args.port:
                fact("compose port", "%d" % args.port, ok=True)
            else:
                note("in compose: ports: - \"%d:%d\"  (left = the port people open on this machine)" % (listen[0], listen[0]))
    cert = {k: v for k, v in config.items() if re.match(r"(?i)^Kestrel:(Certificates:Default|Endpoints:[^:]+:Certificate):", k)}
    for k, (v, f) in sorted(cert.items()):
        fact(f, show(k, v))
        if k.lower().endswith(":path") and (WIN_ABS_RE.search(str(v)) or "\\" in str(v)):
            problem("%s is a Windows path: the container has no such file. Mount the certificate (a folder, :ro) and "
                    "set %s to the path inside, e.g. /https/server.pfx" % (k, env_name(k)))
    if any(re.match(r"(?i)^Kestrel:Certificates:Default:", k) for k in cert):
        note("compose's Kestrel__Certificates__Default__Path / __Password replace it (no ASPNETCORE_ prefix, so they "
             "win over appsettings.json; ASPNETCORE_Kestrel__... would lose to it)")
    if any(re.match(r"(?i)^Kestrel:Endpoints:[^:]+:Certificate:", k) for k in cert):
        check("an endpoint names its own certificate, so the Default certificate variables do not apply to it: in "
              "compose set that endpoint's keys instead, e.g. Kestrel__Endpoints__Https__Certificate__Path")
    if https_ports and not cert:
        check("HTTPS without a certificate in appsettings: give it in compose - Kestrel__Certificates__Default__Path "
              "(the .pfx mounted :ro) and __Password from .env. Or plain HTTP behind a reverse proxy that does HTTPS")
    if uses["https"]:
        fact("HTTPS in the code", ", ".join(uses["https"]))
        if "UseHttpsRedirection" in uses["https"] and not https_ports:
            check("UseHttpsRedirection, but no HTTPS port: requests stay on http (the log warns \"Failed to determine "
                  "the https port for redirect\"). Fine behind a reverse proxy that does HTTPS")
    if wc:   # IIS settings: nothing reads web.config in a container
        fact("web.config (IIS)", "env vars IIS gives the app: %s" % (", ".join(n for n, _v in wc["env"]) or "none"))
        vs = [n for n, v in wc["env"] if vs_leftover(n, v)]
        for n, v in wc["env"]:
            print("  %-21s   %s" % ("", "%s = (a connection string: part 4)" % n if conn_parts(v) else
                                    show(n, v) + ("   <- Visual Studio's, leave out" if n in vs else "")))
        if len(vs) < len(wc["env"]):
            note("no IIS in a container, so nobody reads web.config: set these under environment: in compose (a "
                 "password from .env)%s" % (", all but the ones Visual Studio wrote" if vs else ""))
        if vs:
            check("%s: Visual Studio wrote these into web.config while it ran the app on IIS for debugging (hot "
                  "reload, browser link). They are not the app's settings: leave them out of compose%s"
                  % (", ".join(vs), " - DOTNET_STARTUP_HOOKS with that Windows path stops the app before it starts"
                     if "DOTNET_STARTUP_HOOKS" in (n.upper() for n in vs) else ""))
        iis_env = next((v for n, v in wc["env"] if n.upper() == "ASPNETCORE_ENVIRONMENT"), None)
        if iis_env and iis_env.lower() != env.lower():
            check("IIS runs the app as %s (web.config ASPNETCORE_ENVIRONMENT), a container as %s unless compose sets "
                  "ASPNETCORE_ENVIRONMENT: %s. Run this check again with --environment %s (it changes which "
                  "appsettings files count)" % (iis_env, env, iis_env, iis_env))
        if wc["max_body"] and wc["max_body"] > KESTREL_MAX_BODY:
            fact("upload size", "IIS takes requests up to %s (web.config requestLimits)" % mb(wc["max_body"]))
            raised = [n for n in uses["bodysize"] if n != "IISServerOptions"]
            kestrel = "KestrelServerOptions" in raised or "ConfigureKestrel" in raised
            if any(n.startswith(("RequestSizeLimit", "DisableRequestSizeLimit")) for n in raised) or (
                    "MaxRequestBodySize" in raised and kestrel):
                note("the code sets its own request size limit (%s): big uploads should work in the container too - "
                     "upload the biggest file once to test" % ", ".join(raised))
            else:
                iis_only = "; the IISServerOptions in the code count only under IIS" if (
                    "IISServerOptions" in uses["bodysize"]) else ""
                check("no IIS in a container: Kestrel takes requests up to %s bytes (28.6 MB) unless the CODE raises "
                      "it - Limits.MaxRequestBodySize in ConfigureKestrel, or [RequestSizeLimit] / "
                      "[DisableRequestSizeLimit] on the upload action%s. An env var does not change it. Upload the "
                      "biggest file once to test" % ("{:,}".format(KESTREL_MAX_BODY), iis_only))

    # ---- 4. DATABASE AND OTHER SERVICES ----
    print("\n4. DATABASE AND OTHER SERVICES")
    shown = set()
    for pkg, what, image, port in DATABASES:
        if pkg in packages and what not in shown:
            shown.add(what)
            fact("uses", "%s (%s %s)%s" % (what, pkg, packages[pkg], "  -> moved into Docker too: image %s, port %s "
                                           "inside the network" % (image, port) if image else ""))
    # connection strings, wherever the app keeps them: (where, key, value, how a container changes it)
    found = []
    for k, (v, f) in sorted(config.items()):
        if k.lower().startswith("connectionstrings:"):
            found.append((f, k, v, "In compose: %s" % env_name(k)))
        elif conn_parts(v):
            found.append((f, k, v, "In compose: %s (an env var replaces %s when the app reads its settings the usual "
                                   "way - IConfiguration / Options)" % (env_name(k), k)))
    for n, v in (wc or {}).get("env", []):
        if n.lower().startswith("connectionstrings__") or conn_parts(v):
            found.append(("web.config", n, v, "In compose: %s (IIS set it; nothing reads web.config in a container)"
                          % n))
    if nf:
        cm_used = "System.Configuration.ConfigurationManager" in (
            own_asm if a["mode"] == "published" else packages)
        for n, v in nf[0] + [(k, v) for k, v in nf[1] if conn_parts(v)]:
            unused = "" if cm_used else " (your code does not use ConfigurationManager: probably unused)"
            found.append((nf_name, n, v, "%s is read through ConfigurationManager%s: no env var changes it - edit the "
                                         "file, or mount your own copy over /app/%s.dll.config" % (
                                             nf_name, unused, a["app"])))
    for s in sorted(s for s in literals if conn_parts(s)):
        found.append(("in the code", None, s, "It is written in the code: only a code change moves it"))
    in_settings = [k for where, k, _v, _h in found if where in loaded]
    for i, (where, k, v, how) in enumerate(found):
        if i == len(in_settings) and in_settings:   # the appsettings ones come first
            note("env vars win over appsettings.json: compose sets %s, appsettings.json keeps the values for your PC"
                 % ", ".join(env_name(x) for x in in_settings))
        fact(where, show(k, v) if k else scrub(v))
        name = k or "the connection string in the code"
        parts = conn_parts(v) or {p.split("=", 1)[0].strip().lower(): p.split("=", 1)[1].strip()
                                  for p in str(v).split(";") if "=" in p}
        host = next((parts[x] for x in CONN_HOST_KEYS if x in parts), "")
        h = re.sub(r"^tcp:", "", host, flags=re.I).split(",")[0].split(":")[0].lower()
        if "(localdb)" in h:
            problem("%s uses SQL Server LocalDB: Windows only - a SQL Server container instead, Server=<its service "
                    "name>. %s" % (name, how))
        elif h in ("localhost", "127.0.0.1", ".", "(local)", "::1"):
            (problem if k is None else check)(
                "%s points at localhost: in a container that is the container itself - it must name the database's "
                "SERVICE NAME (a database in the same compose) or host.docker.internal (a database still on this PC). "
                "%s" % (name, how))
        elif re.search(r"\.(db|sqlite3?)$", h):
            check("%s is a SQLite FILE (%s): inside /app it is lost when the container is re-created - a volume "
                  "folder and Data Source=/data/%s. %s" % (name, host, os.path.basename(host), how))
        elif h:
            note("%s: %s - from a container it is reached as from this PC (another machine), or by service name "
                 "(a database in the same compose). %s" % (name, h, how))
        if parts.get("trusted_connection", "").lower() in ("true", "yes") or \
                parts.get("integrated security", "").lower() in ("true", "sspi", "yes"):
            problem("%s uses Windows login (Trusted_Connection / Integrated Security): a Linux container has no "
                    "Windows account. Use a SQL login: User ID=...;Password=... (the password from .env)" % name)
    if in_settings and len(found) == len(in_settings):
        note("env vars win over appsettings.json: compose sets %s, appsettings.json keeps the values for your PC"
             % ", ".join(env_name(x) for x in in_settings))
    if not found and shown:
        check("a database driver, but no connection string in appsettings, web.config, %s.dll.config or the text of "
              "the code: the app may put it together in the code, or read it from an env var set on the server - "
              "find it before you set it in compose" % a["app"])
    elif not found:
        fact("database", "no driver package and no connection string found")
    # addresses in the settings files: a localhost one is the container itself
    cfg_urls = [(k, str(v), f) for k, (v, f) in sorted(config.items()) if isinstance(v, str) and URL_RE.match(v)
                and k not in ep_urls]
    cfg_urls += [(n, v, "web.config") for n, v in (wc or {}).get("env", []) if URL_RE.match(v or "")
                 and not vs_leftover(n, v)]
    cfg_urls += [(k, v, nf_name) for k, v in (nf[1] if nf else []) if URL_RE.match(v or "")]
    if cfg_urls:
        fact("addresses in config", ", ".join(sorted({scrub(v) for _k, v, _f in cfg_urls})[:10]))
    for k, v, f in cfg_urls:
        if not LOCAL_RE.search(v):
            continue
        m = LOCAL_PORT_RE.search(v)
        port = int(m.group(1)) if m else 0
        why = (" (port %d is what IIS Express - Visual Studio - gives a project: most likely this app's own address "
               "while it was being built)" % port) if 44300 <= port <= 44399 else ""
        if why:   # most likely the app's own address: a link people open
            new = "for a link, %s" % scrub(re.sub(r"(?i)^[a-z]+://(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?",
                                                  "http://SERVER:PORT", v))
        else:
            new = "for a program on this PC, %s" % scrub(LOCAL_RE.sub("//host.docker.internal", v, count=1))
        how = ("in compose: %s, %s" % (env_name(k), new) if f in loaded else "in compose: %s, %s" % (k, new)
               if f == "web.config" else "edit %s (ConfigurationManager reads it), %s" % (f, new))
        check("%s = %s names localhost%s. In a container localhost is the container itself. A link the app gives out "
              "(people's browsers open it) needs the address people use, e.g. http://SERVER:PORT/...; an address the "
              "app calls keeps the whole value, only localhost changes: to host.docker.internal (a program on this "
              "PC) or the service name (same compose) - %s" % (k, scrub(v), why, how))
    # https to machines on the office network: their certificates are signed by the company, or by themselves
    lan = sorted({url_host(u) for u in [v for _k, v, _f in cfg_urls] + code_urls if u.lower().startswith("https://")
                  and url_host(u) != "localhost" and LAN_HOST_RE.match(url_host(u))})
    if lan:
        fact("https, own network", ", ".join(lan[:8]))
        if "update-ca-certificates" in dtext:
            fact("  in the Dockerfile", "update-ca-certificates: a CA certificate is added", ok=True)
        else:
            check("https to %s: if the APP calls these (not only the browser), the container must trust their "
                  "certificates. Windows does when your company's CA is installed on it; the container knows only the "
                  "public CAs, so the call fails: \"The SSL connection could not be established ... PartialChain\" (or "
                  "UntrustedRoot). The fix: that CA certificate (a self-signed server: its own certificate) into the "
                  "image - COPY company-ca.crt /usr/local/share/ca-certificates/ and RUN update-ca-certificates "
                  "(SERVICES_GUIDE 2.4)%s" % (", ".join(lan[:3]) + (" ..." if len(lan) > 3 else ""), (
                      "; the code has its own certificate check (%s): if it accepts these machines, nothing to do"
                      % ", ".join(uses["certs"])) if uses["certs"] else ""))

    # ---- 5. DATA-PROTECTION KEYS ----
    if a["web"]:
        print("\n5. DATA-PROTECTION KEYS (they sign the login cookies)")
        if "PersistKeysToFileSystem" in uses["keys"]:
            key_lits = sorted(s for s in literals if re.search(r"(?i)(dataprotection|^keys$|[/\\]keys$|^keys[/\\])", s))
            fact("in the code", "PersistKeysToFileSystem" + ("  folder text: " + ", ".join(key_lits) if key_lits else ""))
            check("the app keeps its keys in a folder of its own: mount a volume THERE (a relative folder is inside "
                  "/app, e.g. /app/keys) - else every new container logs everyone out")
        else:
            fact("in the code", ", ".join(uses["keys"]) or "AddDataProtection not called (logins and forms use the "
                                                           "default anyway)")
            note("default folder: /root/.aspnet/DataProtection-Keys as root (the .NET images run as root unless "
                 "USER app; then /home/app/.aspnet/DataProtection-Keys): mount a volume there")
        kd = os.path.join(root, "keys")
        if os.path.isdir(kd):
            fact("keys/ here", "%s: leave them out of the image and mount the folder"
                 % plural(len([f for f in os.listdir(kd) if f.lower().endswith(".xml")]), "key file"))

    # ---- 6. PROGRAMS, FILES AND ADDRESSES ----
    print("\n6. PROGRAMS, FILES AND ADDRESSES THE CODE NAMES (text inside %s)" % (
        ", ".join(scanned[:6]) + (" ..." if len(scanned) > 6 else "") if scanned else "-"))
    if uses["process"]:
        fact("starts programs", "yes (%s)" % ", ".join(uses["process"]))
    progs = {}
    for s in literals:
        if len(s) > 200 or " " in s.strip() and not s.lower().endswith(".exe"):
            continue
        m = PROGRAM_RE.search(s.strip())
        if not m:
            continue
        base = m.group(1).lower()
        if m.group(2) or (uses["process"] and base in PROGRAMS and s.strip().lower() == base):
            progs.setdefault(base, set()).add(s.strip())
    for base, texts in sorted(progs.items()):
        shown_txt = ", ".join('"%s"' % scrub(t) for t in sorted(texts)[:3])
        if base in WINDOWS_PROGRAMS:
            fact("Windows program", shown_txt)
            problem("the code names %s: a Windows program, not in a Linux container - that part needs a code change "
                    "(or a Linux command)" % shown_txt)
        elif base in PROGRAMS:
            fact("program", shown_txt)
            with_bs = sorted(t for t in texts if "\\" in t)
            pkg = PROGRAMS[base]
            if with_bs:
                problem('%s is named with \\ ("%s"): on Linux that is ONE file name, not folders. In the Dockerfile: '
                        "apt-get install -y %s, then link it under exactly that name: ln -s /usr/bin/%s '/app/%s'"
                        % (base, with_bs[0], pkg, base, with_bs[0]))
            else:
                check("the code starts %s: the Windows .exe cannot run on Linux. In the Dockerfile: RUN apt-get update "
                      "&& apt-get install -y --no-install-recommends %s && rm -rf /var/lib/apt/lists/* (and, if the "
                      "code names a path to it, link /usr/bin/%s there)" % (base, pkg, base))
        elif any(t.lower().endswith(".exe") for t in texts):
            fact("program (.exe)", shown_txt)
            check("the code names %s: a Windows program - it needs a Linux build of it in the image, or a code change"
                  % shown_txt)
    if uses["process"] and not progs:
        check("the app starts other programs: they must exist, for Linux, inside the image")
    win_paths = sorted({m.group(0) for s in literals for m in [WIN_ABS_RE.search(s) or UNC_RE.search(s)] if m})
    win_cfg = sorted({(k, str(v), "appsettings") for k, (v, f) in config.items() if isinstance(v, str)
                      and k not in cert and (WIN_ABS_RE.search(v) or UNC_RE.search(v))} | {
        (k, v, src) for src, pairs in (("web.config", (wc or {}).get("env", [])), (nf_name, nf[1] if nf else []))
        for k, v in pairs if not conn_parts(v) and not vs_leftover(k, v)
        and (WIN_ABS_RE.search(v or "") or UNC_RE.search(v or ""))})
    for s in win_paths[:10]:
        fact("Windows path", '"%s"' % scrub(s))
        check('"%s" does not exist in Linux. Harmless if the code never uses it; if it does, that needs a code change '
              "or the value from appsettings / an env var" % scrub(s))
    for k, v, src in win_cfg[:10]:
        fact("Windows path", "%s = %s (%s)" % (k, scrub(v), src))
        if src == nf_name:
            check("%s is a Windows path in %s: edit it there (no env var changes it) to a Linux path, e.g. "
                  "/app/data/..., and mount a volume there" % (k, src))
        else:
            check("%s is a Windows path: in compose set %s to a Linux path (e.g. /app/data/...) and mount a volume "
                  "there" % (k, env_name(k)))
    for s in sorted(s for s in literals if BACKSLASH_REL_RE.match(s) and not s.lower().endswith(".exe"))[:10]:
        fact("path with \\", '"%s"' % s)
        check('"%s": on Linux a \\ is part of the file name, not a folder separator (Path.Combine or / in the code)' % s)
    for s in sorted(s for s in literals if LINUX_ABS_RE.match(s))[:10]:
        fact("Linux path", '"%s" -> must exist in the container: mount it there' % s)
    files = sorted(s for s in literals if FILE_EXT_RE.search(s.replace("\\", "/").split("/")[-1])
                   and not s.lower().startswith(("http", "~/", "/", "_content")) and not s.lower().endswith(".exe")
                   and not WIN_ABS_RE.search(s))
    if files:
        fact("file names", ", ".join('"%s"' % f for f in files[:15]))
        if any(re.search(r"(?i)firebase|adminsdk|service.?account", f) for f in files):
            check("a Firebase / service-account file is named: it is a secret. Mount it (not in the image), and the "
                  "container needs internet to reach Google")
    if uses["writes"]:
        fact("writes files", "yes (%s): what it writes inside the container is lost when the container is re-created "
             "- the folders it writes to should be volumes" % ", ".join(uses["writes"][:4]))
    if code_urls:
        fact("addresses in code", ", ".join(code_urls[:10]))
        note("the app may call these: the container needs a network path to each one it calls (another machine: as "
             "from this PC). An address in appsettings can be changed by an env var, one in the code cannot")
    if page_urls:
        fact("pages load", ", ".join(page_urls[:10]))
        note("scripts, styles, images the PAGES load: the browser of whoever opens the site fetches them, not the "
             "container - nothing to do in Docker (those PCs need internet)")
    extra_cfg = sorted(s for s in literals if s.lower().endswith(".json") and "appsettings" not in s.lower())
    if uses["config"] and extra_cfg:
        fact("extra config files", ", ".join(extra_cfg[:8]) + " -> they must be in the image (or mounted)")
    # Linux file names are case-sensitive: a name the code uses that only exists in another case is a 404 there
    index = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            rel = os.path.relpath(os.path.join(dirpath, fn), root).replace(os.sep, "/")
            index.setdefault(rel.lower(), rel)
    case_bad = set()
    for s in literals:
        t = s.strip().split("?")[0].split("#")[0].replace("\\", "/")
        if len(t) > 200 or not re.search(r"\.\w{2,5}$", t) or re.match(r"(?i)^[a-z]+://", t):
            continue
        t = re.sub(r"^~?/", "", t)
        for cand in (t, "wwwroot/" + t):
            actual = index.get(cand.lower())
            if actual and actual != cand:
                case_bad.add((s.strip(), actual))
    for s, actual in sorted(case_bad)[:10]:
        fact("upper/lower case", '"%s" in the code, but the file is %s' % (s, actual))
        problem('the code asks for "%s", the file is named %s: Windows does not mind, Linux does (404 / file not '
                "found). Rename the file or fix the text in the code" % (s, actual))

    # ---- 7. MACHINE CHECKS ----
    print("\n7. MACHINE CHECKS")
    if uses["mac"]:
        fact("reads network cards", "yes (%s)" % ", ".join(uses["mac"]))
        check("if this is a licence check on the MAC: a container gets a random MAC on every start. Give it the "
              "licensed one - compose: mac_address: \"${MAC_ADDRESS}\" (the value in .env); docker run: "
              "--mac-address. An env var alone does not change the MAC")
    else:
        fact("reads network cards", "no", ok=True)
    if uses["hostname"]:
        fact("reads machine name", "yes (%s)" % ", ".join(uses["hostname"]))
        check("a container gets a random name: if a licence or a setting depends on it, set it - compose: hostname: "
              "NAME; docker run: --hostname NAME")
    lic = sorted(s for s in literals if re.search(r"(?i)licen[cs]e", s) and len(s) < 120)
    if lic:
        fact("licence text", ", ".join('"%s"' % scrub(s) for s in lic[:6]))

    # ---- 8. THE DOCKERFILE ----
    print("\n8. THE DOCKERFILE (%s)" % (os.path.basename(dpath) if df else "none in this folder - example-stack has "
                                       "both kinds; --dockerfile FILE checks another"))
    if df:
        img = df["from"] or "?"
        fact("FROM (final stage)", img)
        m = re.match(r"(?i)^(?:mcr\.microsoft\.com/)?dotnet/(?:core/)?(aspnet|runtime-deps|runtime|sdk)(?::(\S+))?$", img)
        if m:
            ikind, tag = m.group(1).lower(), m.group(2) or "latest"
            iver = major_minor(tag)
            if ikind == "sdk":
                check("the final image is the SDK (about 800 MB more): build in an SDK stage, run on %s "
                      "(the two-stage Dockerfile of example-stack)" % kind)
            elif ikind == "runtime" and a["web"]:
                problem("a web app on the runtime image: it lacks ASP.NET Core and stops with \"The framework "
                        "'Microsoft.AspNetCore.App' was not found\" - use mcr.microsoft.com/dotnet/aspnet")
            newer = iver and ver and int(iver.split(".")[0]) > int(ver.split(".")[0])
            roll = df["env"].get("DOTNET_ROLL_FORWARD") or a.get("roll_forward") or ""
            if newer and roll.lower() in ("major", "latestmajor"):
                fact("version", "image %s runs the .NET %s app through DOTNET_ROLL_FORWARD=%s" % (iver, ver, roll),
                     ok=True)
                note("a stop-gap: test every page once; the lasting fix is a publish for .NET %s" % iver)
            elif iver and ver and iver.split(".")[0] != ver.split(".")[0]:
                problem("the image is .NET %s, the app needs .NET %s: it does not start (\"You must install or update "
                        ".NET to run this application\") - DOTNET_VERSION=%s%s" % (
                            iver, ver, ver, " (or ENV DOTNET_ROLL_FORWARD=Major: runs it on the newer .NET; test every "
                                            "page)" if newer else ""))
            elif iver and ver and iver != ver:
                check("the image is .NET %s, the app was built for %s" % (iver, ver))
            elif ver and not iver:
                check("the tag %s is not a version: use %s:%s, so a rebuild cannot jump to another major version"
                      % (tag, ikind, ver))
            elif ver:
                fact("version", "image %s = app %s" % (iver, ver), ok=True)
        else:
            check("not a Microsoft .NET image: make sure it has the .NET %s runtime%s" % (
                ver or "?", " and ASP.NET Core" if a["web"] else ""))
        if df["dll"]:
            if df["dll"].lower() != a["dll"].lower():
                problem("the Dockerfile starts %s, but the app is %s" % (df["dll"], a["dll"]))
            else:
                fact("starts", df["dll"], ok=True)
        if df["expose"] and a["web"] and listen and not set(df["expose"]) & set(listen):
            check("EXPOSE %s, but the app listens on %s: EXPOSE is only a note (compose ports: decide), but fix it "
                  "so it does not mislead" % (", ".join(map(str, df["expose"])), ", ".join(map(str, listen))))
        if a["mode"] == "source" and img.lower().startswith("mcr.microsoft.com/dotnet/aspnet") and "sdk" not in open(
                dpath, encoding="utf-8-sig", errors="replace").read().lower():
            problem("the Dockerfile copies the SOURCE into a runtime image: nothing compiles it. Use the two-stage "
                    "Dockerfile (an SDK stage runs dotnet publish)")

    # ---- 9. WHAT GOES INTO THE IMAGE ----
    # Docker reads <Dockerfile name>.dockerignore next to the Dockerfile first, then .dockerignore in the folder
    di = args.dockerignore or next((p for p in ([dpath + ".dockerignore"] if dpath else []) + [
        os.path.join(root, f) for f in ("Dockerfile.dockerignore", ".dockerignore")] if os.path.isfile(p)), None)
    rules = dockerignore_rules(di)
    print("\n9. WHAT GOES INTO THE IMAGE (%s)" % (os.path.basename(di) if rules else
                                                "no .dockerignore here: EVERYTHING goes in"))
    total, dropped, by_rule, kept, dropped_files = [0, 0], [0, 0], {}, [], []
    for dirpath, dirnames, filenames in os.walk(root):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            try:
                size = os.path.getsize(full)
            except OSError:
                size = 0
            total[0] += 1
            total[1] += size
            rule = ignored_by(rel, rules)
            if rule:
                dropped[0] += 1
                dropped[1] += size
                dropped_files.append((rel, rule))
                r = by_rule.setdefault(rule, [0, 0])
                r[0] += 1
                r[1] += size
            else:
                kept.append((size, rel))
    suggest = {}     # .dockerignore lines for what this part finds, by why: {comment: [lines]}
    fact("in the folder", "%d files, %s" % (total[0], mb(total[1])))
    fact("into the image", "%d files, %s" % (len(kept), mb(sum(s for s, _ in kept))))
    if by_rule:
        fact("left out", "%d files, %s: %s" % (dropped[0], mb(dropped[1]), "; ".join(
            "%s (%d, %s)" % (r, n, mb(s)) for r, (n, s) in sorted(by_rule.items(), key=lambda x: -x[1][1]))))
    if a["mode"] == "source":
        bo = [d for d in ("bin", "obj") if any(("/" + d + "/") in ("/" + r) for _s, r in kept)]
        if bo:
            problem("%s go into the build: Windows build output (obj/ holds Windows paths and breaks dotnet restore in "
                    "Docker). Add **/bin/ and **/obj/ to the .dockerignore" % " and ".join(d + "/" for d in bo))
            suggest["# Windows build output: the Linux build makes its own"] = ["**/bin/", "**/obj/"]
    # a file the code names but the dockerignore leaves out: the app may look for it at run time
    named = {s.replace("\\", "/").split("/")[-1].lower() for s in literals}
    for rel, rule in dropped_files:
        base = os.path.basename(rel)
        if base.lower() in named and not base.lower().startswith("dockerfile") and not base.lower().endswith(".exe"):
            fact("named but left out", "%s (by %s)" % (rel, rule))
            check("the code names %s, but the .dockerignore leaves it out. If the app opens it while running: add the "
                  "line !%s at the end of the .dockerignore to keep it, or mount it (a secret: mount it)" % (base, rel))
    big = sorted(kept, reverse=True)[:5]
    if big:
        fact("biggest going in", ", ".join("%s (%s)" % (r, mb(s)) for s, r in big))
    folders = {}
    for s, r in kept:
        parts = r.split("/")
        if len(parts) > 1:
            k = "/".join(parts[:2]) if len(parts) > 2 else parts[0]
            folders[k] = folders.get(k, 0) + s
    if folders:
        fact("biggest folders", ", ".join("%s/ (%s)" % (k, mb(s)) for k, s in sorted(
            folders.items(), key=lambda x: -x[1])[:6]))
    other_os = {}    # runtimes/win-x64/..., runtimes/osx/...: builds for other OSes, never loaded on Linux
    for s, r in kept:
        m = re.match(r"^runtimes/([^/]+)/", r)
        if a["mode"] == "published" and m and not m.group(1).lower().startswith(("linux", "unix", "any")):
            o = other_os.setdefault(m.group(1).split("-")[0], [0, 0])
            o[0] += 1
            o[1] += s
    if other_os:
        pats = ["runtimes/%s*" % o for o in sorted(other_os)]
        fact("other OS builds", "%s: %s, %s - Linux never loads them" % (", ".join(pats), plural(sum(
            n for n, _s in other_os.values()), "file"), mb(sum(s for _n, s in other_os.values()))))
        note("leave them out: %s in the .dockerignore (runtimes/linux* and runtimes/unix stay)" % " and ".join(pats))
        suggest.setdefault("# builds for other OSes: Linux never loads them", []).extend(pats)
    for s, r in kept:
        secret = bool(re.search(r"(?i)\.(pfx|p12|key)$|(^|/)keys/|(^|/)\.env$", r))
        if r.lower().endswith(".pem"):  # a .pem is a secret only if it holds a private key
            try:
                with open(os.path.join(root, r), "rb") as f:
                    secret = b"PRIVATE KEY" in f.read(65536)
            except OSError:
                pass
        if secret:
            fact("secret going in", r)
            problem("%s goes into the image: anyone with the image can read it. Add it to the .dockerignore and mount "
                    "it at run time" % r)
            suggest.setdefault("# secrets: mounted at run time, never in the image", []).append(
                re.sub(r"^((?:.*/)?keys/).*$", r"\1", r))
    for f in settings_files:
        rel_f = os.path.relpath(os.path.join(sdir, f), root).replace(os.sep, "/")
        if f in loaded:
            state = "loaded"
        elif re.match(r"(?i)^appsettings\.[A-Za-z]+\.json$", f) and not BACKUP_ENV_RE.search(f.split(".")[1]):
            state = "only when ASPNETCORE_ENVIRONMENT=%s" % f.split(".")[1]
        elif any(f.lower() in s.lower() for s in literals):
            state = "named in the code: keep it"
        else:
            state = "NEVER loaded" + (" (left out)" if ignored_by(rel_f, rules) else "")
        fact(f, state)
        if state.startswith("NEVER loaded") and "left out" not in state:
            check("%s is never loaded by the app but goes into the image; an old copy may hold old passwords. Add it "
                  "to the .dockerignore (or delete it)" % f)
            suggest.setdefault("# settings files the app never loads", []).append(rel_f)
    # folders that look like data: written at run time, shared with other programs - volumes, not image content
    data_dirs = []
    for base_dir in ("", "wwwroot/"):
        top = os.path.join(root, base_dir) if base_dir else root
        if not os.path.isdir(top):
            continue
        for d in sorted(os.listdir(top)):
            p = os.path.join(top, d)
            if not os.path.isdir(p) or d in SKIP_DIRS or (not base_dir and d == "wwwroot"):
                continue
            subs = [d] + [d + "/" + x for x in sorted(os.listdir(p)) if os.path.isdir(os.path.join(p, x))]
            for sub in subs:
                rel = base_dir + sub
                n = sum(len(fs) for _, _, fs in os.walk(os.path.join(root, rel)))
                if n and DATA_DIR_RE.search(sub) and not ignored_by(rel, rules) and not any(
                        rel.startswith(d + "/") for d, _n in data_dirs):
                    data_dirs.append((rel, n))
    for rel, n in data_dirs[:12]:
        fact("data folder", "%s (%s) goes INTO the image" % (rel, plural(n, "file")))
        check("%s looks like data (uploads, photos, logs, exports). If the app - or another program, e.g. a worker "
              "that writes photos the app shows - writes there, leave it out (.dockerignore) and mount that folder "
              "from the host - compose: - ./%s:/app/%s (the app in /app, as in example-stack's Dockerfiles); in the "
              "image it is only a stale copy%s" % (rel, rel.split("/")[-1], rel,
                                                   " (the code writes files)" if uses["writes"] else ""))
        suggest.setdefault("# data written at run time - mounted instead (only if the CHECK says so)", []).append(
            rel + "/")
    backups = [r for _, r in kept if BACKUP_RE.search(os.path.basename(r))
               and not re.match(r"(?i)^appsettings.*\.json$", os.path.basename(r))]
    if backups:
        texts = "\n".join(literals)
        for _, r in kept:
            if r.lower().endswith((".html", ".js", ".css", ".cshtml")) and r not in backups:
                try:
                    with open(os.path.join(root, r), encoding="utf-8", errors="ignore") as f:
                        texts += "\n" + f.read(2000000)
                except OSError:
                    pass
        unnamed = [r for r in backups if os.path.basename(r) not in texts]
        named_b = [r for r in backups if r not in unnamed]
        fact("backup copies", "%d going in (files under wwwroot can be downloaded by anyone who opens the site)"
             % len(backups))
        if unnamed:
            fact("  named nowhere", ", ".join(unnamed[:12]) + (" ..." if len(unnamed) > 12 else ""))
            note("not used by the app: they can be left out (.dockerignore) or deleted")
            suggest.setdefault("# backup copies the app never names", []).extend(unnamed[:12])
        if named_b:
            fact("  named by the app", ", ".join(named_b[:12]) + " -> keep")
    if suggest:
        fact(".dockerignore", "add these lines (names exactly as on disk, upper/lower case too):")
        for why, lines in suggest.items():
            for line in [why] + list(dict.fromkeys(lines)):
                print("  %-21s   %s" % ("", line))
        note("a Dockerfile kept outside this folder (docker build -f, compose dockerfile:) takes them from "
             "<its name>.dockerignore next to it, e.g. Dockerfile.dockerignore - handy when every publish makes a new "
             "folder")

    # ---- summary ----
    print("\nSUMMARY: %d PROBLEM, %d CHECK" % (len(problems), len(checks)))
    for p in problems:
        print("  PROBLEM  " + p)
    for c in checks:
        print("  CHECK    " + c)
    if not problems and not checks:
        print("  nothing to change: the app fits a container as it is")
    print("\nPROBLEM = it will not work in the container as it is. CHECK = look at it once; it may be fine.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
