# multi-client - one GPU server, a copy of a solution per client, one proxy in front

Templates for `MULTI_CLIENT_HOSTING.md` (in the tools folder): read it for the why of every line.

| Folder | What |
|---|---|
| `client-template/` | one client's copy: `compose.yml` (its own network, data folder, limits, GPU) + `.env.example`. Copy it to `clients/client-a/` ... per client, then `docker compose -p client-a up -d` |
| `proxy/` | Caddy: the only way in. `Caddyfile` = one block per client (an API key, or a user name + password), `compose.yml` joins every client's network, `.env.example` = the API keys |

Start the clients first (their networks must exist), then the proxy. A solution without a GPU: delete the
`deploy:` block in the client's `compose.yml`.
