#!/usr/bin/env python3
"""
xray_clients.py - one isolated copy of your whole solution per client, behind ONE proxy. Stdlib only, Python 3.8+,
Docker with compose on the machine.

Your solution is ONE compose file (the system compose: the programs, the dashboard, the database). For every client
this tool makes a copy of it that is closed off from every other client, and puts it behind the proxy (Caddy), the
only container reachable from outside:

  - its own folder (clients/NAME): compose.yml, .env, data/ - its own database, files and settings
  - its own network: no container of another client can reach it, not even by IP
  - its own passwords: every secret of the system's .env (DB_PASSWORD ...) made new for this client
  - its own way in: one address (a port of the server, or a name), people with a user name + password, machines
    with an API key - written to clients/NAME/ACCESS.txt to hand over
  - nothing published: the client's containers have no ports; only the proxy has

Run it in the hosting folder (or give --root FOLDER before the command):
  python xray_clients.py add client-a --system system\\compose.yml --web dashboard:8080 --api middle:5014 --server 192.168.1.50
  python xray_clients.py start client-a          up (healthy), checked a few seconds later, joined to the proxy; the
                                                 other clients keep running. Also: apply a change of its .env/compose
  python xray_clients.py test client-a           through the proxy: no key / a wrong key -> 401, its key -> the program
  python xray_clients.py list                    every client: address, what it exposes, containers running
  python xray_clients.py password client-a       a new dashboard password (active at once, nothing restarts)
  python xray_clients.py key client-a            a new API key (the same)
  python xray_clients.py update client-a         its compose made again from the system compose (.env, secrets, data
                                                 stay); --server NEW-IP when the server's address changed
  python xray_clients.py remove client-a         off the proxy, stopped - its folder, data and database volume stay

Folders, under the hosting folder:
  proxy/              compose.yml  Caddyfile  proxy.json  sites/NAME.caddy (one per client)  - the one way in
  clients/NAME/       compose.yml  .env  data/  ACCESS.txt  client.json
The proxy publishes 8441-8460 (one port per client; proxy/proxy.json "ports" before the first client) and 80 + 443
only once a client is reached by a name (--host).
"""
import argparse
import base64
import datetime
import http.client
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.parse
import ssl

VERSION = "0.1.0"
CADDY = "caddy:2"
PORTS = "8441-8460"                # the port range the proxy publishes for clients reached by port (one each);
                                   # proxy/proxy.json "ports" changes it (before the first client)
SECRET_KEY = re.compile(r"(?i)(PASSWORD|PASSWD|PWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|(^|_)PASS)$")
CONFIG_EXT = (".json", ".yaml", ".yml", ".ini", ".cfg", ".conf", ".config", ".xml", ".toml", ".properties", ".txt")
NAME_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}$")


def die(msg):
    sys.exit("ERROR: " + msg)


def run(cmd, cwd=None, input_text=None, check=True):
    # utf-8 whatever the console's code page: docker prints characters a Windows code page cannot decode
    r = subprocess.run(cmd, cwd=cwd, input=input_text, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    if check and r.returncode != 0:
        die(f"{' '.join(cmd)} failed:\n{(r.stderr or r.stdout).strip()}")
    return r


# ============================================================================ YAML out (compose files)
SAFE = re.compile(r"^[A-Za-z0-9_./@-]+$")
YAML_WORDS = {"y", "n", "yes", "no", "true", "false", "on", "off", "null", "~"}
KEY_ORDER = ["image", "command", "entrypoint", "working_dir", "user", "restart", "env_file", "environment", "volumes",
             "depends_on", "healthcheck", "deploy", "networks"]


def scalar(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v)
    if SAFE.match(s) and s.lower() not in YAML_WORDS and not re.match(r"^[-+]?[\d.]+([eE][-+]?\d+)?$", s):
        return s
    return json.dumps(s, ensure_ascii=False)


def to_yaml(obj, indent=0, order=None):
    pad = "  " * indent
    out = []
    if isinstance(obj, dict):
        keys = list(obj)
        if order:
            keys = [k for k in order if k in obj] + sorted(k for k in obj if k not in order)
        for k in keys:
            v = obj[k]
            key = scalar(k)
            if isinstance(v, dict) and v:
                out.append(f"{pad}{key}:")
                out += to_yaml(v, indent + 1)
            elif isinstance(v, list) and v:
                out.append(f"{pad}{key}:")
                out += to_yaml(v, indent + 1)
            elif isinstance(v, (dict, list)):
                out.append(f"{pad}{key}: {'{}' if isinstance(v, dict) else '[]'}")
            else:
                out.append(f"{pad}{key}: {scalar(v)}")
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, dict) and v:
                sub = to_yaml(v, indent + 1)
                out.append(f"{pad}- " + sub[0].lstrip())
                out += sub[1:]
            elif isinstance(v, list) and v:
                out.append(f"{pad}-")
                out += to_yaml(v, indent + 1)
            else:
                out.append(f"{pad}- {scalar(v)}")
    return out


# ============================================================================ the system compose -> one client's
def load_system(path):
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        die(f"--system {path}: no such file - the compose file of your whole solution")
    r = run(["docker", "compose", "-f", path, "config", "--format", "json", "--no-interpolate"],
            cwd=os.path.dirname(path), check=False)
    if r.returncode != 0:
        die("docker compose cannot read the system compose:\n" + (r.stderr or r.stdout).strip())
    return path, json.loads(r.stdout)


def split_expose(items, services, what):
    """['dashboard:8080'] -> [('dashboard', 8080)]"""
    out = []
    for it in items:
        m = re.match(r"^([A-Za-z0-9_.-]+):(\d+)$", it.strip())
        if not m:
            die(f"--{what} {it}: write SERVICE:PORT - the service's name in the system compose and the port it listens "
                "on INSIDE its container (8080 for an ASP.NET dashboard, 5014 for your API ...)")
        s, port = m.group(1), int(m.group(2))
        if s not in services:
            die(f"--{what} {it}: the system compose has no service {s} (it has: {', '.join(services)})")
        out.append((s, port))
    return out


def client_compose(name, sysdoc, sysdir, cdir, exposed, notes, writable):
    """the system compose, closed off for one client"""
    svcs = {}
    files = {}                                  # env files of the system -> their copy in the client folder
    unnamed, shared, taken = [], [], set()
    for sname, s in sysdoc["services"].items():
        s = json.loads(json.dumps(s))
        for k in ("container_name", "ports", "network_mode", "links", "external_links", "expose", "pull_policy"):
            if k in s:
                if k == "container_name":
                    unnamed.append(sname)
                elif k == "network_mode":
                    notes.append(f"{sname}: network_mode {s[k]} left out - it runs on the client's own network")
                s.pop(k)
        if "build" in s:
            if not s.get("image"):
                die(f"service {sname} has build: and no image: - build it once and give it an image name "
                    "(image: NAME:VERSION), clients run images")
            s.pop("build")
        # env files: one copy per client, edited per client
        efs = []
        for ef in s.pop("env_file", []) or []:
            p = ef["path"] if isinstance(ef, dict) else ef
            base = os.path.basename(p)
            if p not in files:
                dst = base if base not in files.values() else f"{sname}{base if base.startswith('.') else '.' + base}"
                files[p] = dst
            efs.append("./" + files[p])
        if efs:
            s["env_file"] = efs
        # folders: written-to ones per client (they start empty), read-only ones (models ...) shared
        vols = []
        for v in s.pop("volumes", []) or []:
            if v.get("type") != "bind":         # named volumes: per client by themselves (compose puts NAME_ before)
                if v.get("type") == "volume" and v.get("source") and not v.get("volume") and \
                        set(v) <= {"type", "source", "target", "read_only", "volume"}:
                    vols.append(f"{v['source']}:{v['target']}" + (":ro" if v.get("read_only") else ""))
                else:
                    vols.append(v)
                continue
            src, tgt = v["source"], v["target"]
            nv = {k: v[k] for k in ("type", "source", "target", "read_only") if k in v}
            nv.update({k: x for k, x in v.items() if k not in nv})
            if v.get("read_only") or tgt.rstrip("/").startswith("/docker-entrypoint-initdb.d"):
                nv = {**{k: nv[k] for k in ("type", "source", "target")}, "read_only": True, **nv}
                vols.append(nv)                 # read only (models, the database's first-start scripts): shared
                shared.append(f"{sname}: {src} -> {tgt}")
                continue
            ns, nd = os.path.normcase(os.path.abspath(src)), os.path.normcase(sysdir)
            rel = os.path.relpath(src, sysdir) if ns == nd or ns.startswith(nd + os.sep) else None
            if rel is None or rel.startswith(".."):        # outside the system folder: data/<its last two names>
                parts = [x for x in re.split(r"[\\/:]+", src) if x]
                tail = re.sub(r"[^A-Za-z0-9_.-]", "_", "-".join(parts[-2:])) or "data"
                rel = os.path.join("data", tail)
                k = 2
                while rel in taken:
                    rel, k = os.path.join("data", f"{tail}-{k}"), k + 1
            taken.add(rel)
            rel_s = rel.replace(os.sep, "/")
            dst = os.path.join(cdir, rel)
            if not os.path.exists(dst):
                if os.path.isfile(src):
                    small = os.path.getsize(src) < 1024 * 1024 and src.lower().endswith(CONFIG_EXT)
                    if small:                   # a settings file: the container cannot start without it
                        os.makedirs(os.path.dirname(dst) or cdir, exist_ok=True)
                        shutil.copy2(src, dst)
                        notes.append(f"{sname}: ./{rel_s} is a copy of {src} - edit it for this client")
                    else:
                        notes.append(f"{sname}: {src} is a FILE the program writes to - not copied (it may hold your "
                                     f"data): put this client's own at ./{rel_s} before the start")
                else:
                    os.makedirs(dst, exist_ok=True)
                    n = sum(len(f) for _, _, f in os.walk(src)) if os.path.isdir(src) else 0
                    if n:
                        cp = (f'robocopy "{src}" "{dst}" /E' if os.name == "nt" else f'cp -a "{src}/." "{dst}/"')
                        notes.append(f"{sname}: ./{rel_s} ({tgt}) starts EMPTY - the system's folder has {n} file(s), "
                                     f"not copied (they may be your office's data). If the program needs them "
                                     f"(templates, settings):  {cp}")
            nv["source"] = "./" + rel_s
            vols.append(nv)
            if os.path.isdir(dst):
                writable.append([sname, s.get("image"), s.get("user"), rel_s])
        if vols:
            s["volumes"] = vols
        # GPU: every client loads its own copy of the model
        devs = (((s.get("deploy") or {}).get("resources") or {}).get("reservations") or {}).get("devices") or []
        if any("gpu" in (d.get("capabilities") or []) for d in devs if isinstance(d, dict)) or s.get("gpus") \
                or s.get("runtime") == "nvidia":
            notes.append(f"{sname}: uses the GPU - every client runs its own copy and loads its own model: the GPU's "
                         "memory is shared by all clients (nvidia-smi after each start)")
        # the network: the client's own; the services the proxy reaches get a name only this client has
        s.pop("networks", None)
        alias = [f"{name}-{sname}"] if sname in {e[0] for e in exposed} else []
        if alias:
            s["networks"] = {"default": {"aliases": alias}}
        for k in ("extra_hosts",):
            if any("host.docker.internal" in str(h) or "host-gateway" in str(h) for h in (s.get(k) or [])):
                notes.append(f"{sname}: extra_hosts host.docker.internal - something on the SERVER ITSELF (a database "
                             "on the server?) would be shared by every client: a database per client is safer")
        if isinstance(s.get("depends_on"), dict):
            for d in s["depends_on"].values():
                if isinstance(d, dict) and d.get("required") is True:
                    d.pop("required")
        s.setdefault("restart", "unless-stopped")
        svcs[sname] = {k: s[k] for k in KEY_ORDER if k in s}
        svcs[sname].update({k: s[k] for k in sorted(s) if k not in KEY_ORDER})
    if unnamed:
        notes.insert(0, f"container_name left out ({', '.join(unnamed)}): a name is per machine, two clients cannot "
                        "both have it; inside the client every service is reached by its service name, as before")
    for x in shared:
        notes.append(f"SHARED read-only by every client (models, settings, database first-start scripts): {x}")
    vols = {}
    for vn, v in (sysdoc.get("volumes") or {}).items():
        v = dict(v or {})
        if v.get("external"):
            notes.append(f"volume {vn} is external: SHARED by every client - give each client its own if it holds data")
        else:
            v.pop("name", None)
        vols[vn] = v
    # the network is made by this tool (docker network create), not by compose: a "docker compose down" in the
    # client's folder leaves it, so the proxy - joined to every client's network - can always start
    doc = {"name": name, "services": svcs, "networks": {"default": {"name": f"{name}_net", "external": True}}}
    if vols:
        doc["volumes"] = vols
    for top in ("secrets", "configs"):
        if sysdoc.get(top):
            doc[top] = sysdoc[top]
            notes.append(f"{top}: {', '.join(sysdoc[top])} - the same files for every client; if they differ per "
                         f"client, point them to a copy in clients/{name}/")
    return doc, files


def env_for_client(name, sysdir, files, cdir, made):
    """copy the system's env files into the client folder; every secret in them gets a new random value"""
    sys_env = os.path.join(sysdir, ".env")
    todo = dict(files)
    if os.path.isfile(sys_env) and sys_env not in todo:
        todo[sys_env] = ".env"                  # the file compose reads ${VARS} from
    for src, dst in todo.items():
        out = os.path.join(cdir, dst)
        if os.path.exists(out) or not os.path.isfile(src):
            continue                            # an existing client's settings are never overwritten
        lines = []
        with open(src, encoding="utf-8", errors="replace") as fh:
            for ln in fh.read().splitlines():
                m = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=", ln)
                if m and SECRET_KEY.search(m.group(1)) and not ln.lstrip().startswith("#"):
                    val = made.setdefault(m.group(1), secrets.token_urlsafe(18))
                    lines += [f"# {m.group(1)}: made new for {name} by xray_clients.py. If it is the password of something "
                              "OUTSIDE this solution (a camera, a mail server, a licence), put the client's real one here",
                              f"{m.group(1)}={val}"]
                else:
                    lines.append(ln)
        with open(out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(f"# {name}'s settings - copied from {src} on {datetime.date.today()}, its secrets made new.\n"
                     "# Change what differs for this client (its cameras, its options); never commit this file.\n"
                     + "\n".join(lines) + "\n")


# ============================================================================ the proxy
def proxy_dir(root):
    return os.path.join(root, "proxy")


def clients_of(root):
    cd = os.path.join(root, "clients")
    out = []
    for n in sorted(os.listdir(cd)) if os.path.isdir(cd) else []:
        f = os.path.join(cd, n, "client.json")
        if os.path.isfile(f):
            with open(f, encoding="utf-8") as fh:
                out.append(json.load(fh))
    return out


def proxy_conf(root, email=None, server=None, force_sni=False, ports=None):
    """proxy/proxy.json: the port range, the e-mail for public certificates, the address for browsers that send no
    name (an IP address)"""
    f = os.path.join(proxy_dir(root), "proxy.json")
    conf = json.load(open(f, encoding="utf-8")) if os.path.isfile(f) else {}
    changed = "ports" not in conf
    conf.setdefault("ports", PORTS)
    if ports and conf["ports"] != ports:
        conf["ports"], changed = ports, True
    if email and conf.get("email") != email:
        conf["email"], changed = email, True
    if server and (force_sni or not conf.get("default_sni")) and conf.get("default_sni") != server:
        conf["default_sni"], changed = server, True
    if changed or not os.path.isfile(f):
        os.makedirs(proxy_dir(root), exist_ok=True)
        with open(f, "w", encoding="utf-8") as fh:
            json.dump(conf, fh, indent=1)
    return conf


def port_range(root):
    m = re.match(r"^\s*(\d+)\s*-\s*(\d+)\s*$", str(proxy_conf(root).get("ports", PORTS)))
    if not m or int(m.group(1)) > int(m.group(2)):
        die('proxy/proxy.json "ports": write it as FIRST-LAST, e.g. "8441-8460"')
    return int(m.group(1)), int(m.group(2))


def ensure_network(name):
    """the client's network, made once by this tool; compose only joins it"""
    if run(["docker", "network", "inspect", name], check=False).returncode != 0:
        run(["docker", "network", "create", "--label", "xray.client=" + name[:-4], name])


def write_proxy(root, email=None, server=None):
    """proxy/compose.yml (every client's network) + the Caddyfile that imports one file per client"""
    pd = proxy_dir(root)
    os.makedirs(os.path.join(pd, "sites"), exist_ok=True)
    conf = proxy_conf(root, email, server)
    glob = ["{"]
    glob.append(f"\temail {conf['email']}" if conf.get("email") else
                "\t# email it@yourcompany.com   <- add --email to an add: Let's Encrypt writes there about public names")
    if conf.get("default_sni"):
        glob.append(f"\t# an address typed as an IP (https://{conf['default_sni']}:8441) carries no name: this one is used")
        glob.append(f"\tdefault_sni {conf['default_sni']}")
    glob.append("}")
    text = ("# The one way in from outside - written by xray_clients.py from proxy.json; every client is its own file\n"
            "# in sites/. Change them with the tool (add, password, key, remove); it reloads the proxy.\n"
            + "\n".join(glob) + "\n\nimport /etc/caddy/sites/*.caddy\n")
    cf = os.path.join(pd, "Caddyfile")
    old = open(cf, encoding="utf-8").read() if os.path.isfile(cf) else None
    if old != text:
        with open(cf, "w", encoding="utf-8", newline="\n") as fh:     # in place: the container's file mount follows it
            fh.write(text)
    cs = clients_of(root)
    nets = [c["network"] for c in cs]
    lo, hi = port_range(root)
    out = [f"{c['name']} ({c['port']})" for c in cs if c.get("port") and not lo <= c["port"] <= hi]
    if out:
        die(f'proxy/proxy.json "ports" {lo}-{hi} leaves out {", ".join(out)} - the range changes only before the '
            "first client; put it back")
    ports = [f"{lo}-{hi}:{lo}-{hi}", f"{lo}-{hi}:{lo}-{hi}/udp"]
    if any(c.get("host") for c in cs):          # 80 + 443 only when a client is reached by a name (IIS has 80 often)
        ports += ["80:80", "443:443", "443:443/udp"]
    doc = {"name": "clients-proxy", "services": {"caddy": {
        "image": CADDY, "restart": "unless-stopped",
        "ports": ports,
        "volumes": ["./Caddyfile:/etc/caddy/Caddyfile:ro", "./sites:/etc/caddy/sites:ro", "caddy-data:/data",
                    "caddy-config:/config"]}}, "volumes": {"caddy-data": {}, "caddy-config": {}}}
    if nets:
        doc["services"]["caddy"]["networks"] = nets
        doc["networks"] = {n: {"external": True} for n in nets}
    with open(os.path.join(pd, "compose.yml"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write("# The reverse proxy in front of every client: the ONLY container with ports open to the network.\n"
                 f"# Ports {lo}-{hi}: one per client reached by port; 80 + 443 (only once a client is reached by\n"
                 "# a name): clients reached by name.\n"
                 "# It joins every client's network (written by xray_clients.py from clients/*/client.json): it reaches\n"
                 "# each client's dashboard and API; the clients never reach each other.\n"
                 + "\n".join(to_yaml(doc, order=["name", "services", "networks", "volumes"])) + "\n")


def site_text(c, key, user, pw_hash):
    """one client's block of the Caddyfile"""
    if c["host"]:
        addr = ("http://" if c["tls"] == "off" else "") + c["host"]
    else:
        addr = f"http://:{c['port']}" if c["tls"] == "off" else f"https://{c['server']}:{c['port']}"
    L = [f"# {c['name']} - written by xray_clients.py {VERSION} on {datetime.date.today()}. What to hand over: "
         f"clients/{c['name']}/ACCESS.txt", f"{addr} {{"]
    if c["tls"] == "internal":
        L.append("\ttls internal")
    for svc, port in c["api"]:
        L += [f"\t# machines: {c['url']}/{svc}/... with the X-API-Key header -> {svc}:{port} of {c['name']} "
              f"(/{svc} is taken off the path)",
              f"\thandle_path /{svc}/* {{", f'\t\t@key header X-API-Key "{key}"', "\t\thandle @key {",
              f"\t\t\treverse_proxy {c['name']}-{svc}:{port}", "\t\t}", '\t\trespond "missing or wrong API key" 401',
              "\t}"]
    if c["web"]:
        svc, port = c["web"]
        L += [f"\t# people: everything else, with a user name + password -> {svc}:{port} of {c['name']}", "\thandle {",
              "\t\tbasic_auth {", f"\t\t\t{user} {pw_hash}", "\t\t}", f"\t\treverse_proxy {c['name']}-{svc}:{port}", "\t}"]
    else:
        L += ["\thandle {", '\t\trespond "not here" 404', "\t}"]
    L.append("}")
    return "\n".join(L) + "\n"


def hash_password(pw):
    r = run(["docker", "run", "--rm", "-i", CADDY, "caddy", "hash-password"], input_text=pw + "\n" + pw + "\n",
            check=False)
    h = (r.stdout or "").strip().splitlines()[-1:] or [""]
    if r.returncode != 0 or not h[0].startswith("$2"):
        die("could not make the password hash with the Caddy image (docker run caddy:2 caddy hash-password):\n"
            + (r.stderr or r.stdout).strip())
    return h[0]


def read_site(root, name):
    f = os.path.join(proxy_dir(root), "sites", name + ".caddy")
    if not os.path.isfile(f):
        return None, None
    t = open(f, encoding="utf-8").read()
    k = re.search(r'header X-API-Key "([^"]+)"', t)
    h = re.search(r"basic_auth \{\s*\n\s*\S+ (\$2\S+)", t)
    return (k.group(1) if k else None), (h.group(1) if h else None)


def write_site(root, c, key, pw_hash):
    with open(os.path.join(proxy_dir(root), "sites", c["name"] + ".caddy"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(site_text(c, key, c["user"], pw_hash))


def proxy_running(root):
    r = run(["docker", "compose", "ps", "-q", "caddy"], cwd=proxy_dir(root), check=False)
    return r.stdout.strip() if r.returncode == 0 else ""


def reload_proxy(root):
    cid = proxy_running(root)
    if not cid:
        return False
    r = run(["docker", "compose", "exec", "-T", "caddy", "caddy", "reload", "--config", "/etc/caddy/Caddyfile"],
            cwd=proxy_dir(root), check=False)
    if r.returncode != 0:
        die("the proxy did not take the new settings (the old ones stay active):\n" + (r.stderr or r.stdout).strip())
    return True


def write_access(root, c, key, pw):
    f = os.path.join(root, "clients", c["name"], "ACCESS.txt")
    if pw is None and os.path.isfile(f):        # not a new password: keep the one still written there (if any)
        m = re.search(r"^  password  ([^ (]\S*)$", open(f, encoding="utf-8").read(), re.M)
        pw = m.group(1) if m else None
    ca = c["tls"] == "internal"
    L = [f"{c['name']} - how to reach it (written {datetime.date.today()}). Hand it over once, keep it in a password",
         "manager, then delete this file. Never in git, never in a chat.", "",
         f"Address:   {c['url']}"]
    if ca:
        L += ["           the proxy's own certificate: install caddy-root.crt (comes with this) on every PC that opens",
              "           it, or the browser warns - CLIENT_HOSTING.md, step 7"]
    if c["web"]:
        L += ["", "PEOPLE (browser):", f"  open      {c['url']}/", f"  user      {c['user']}",
              f"  password  {pw}" if pw else "  password  (unchanged - the one handed over before)"]
    for svc, port in c["api"]:
        L += ["", f"MACHINES ({svc}): every request with the header  X-API-Key: <the key>",
              f"  address   {c['url']}/{svc}/ + the program's own path  (its /x is {c['url']}/{svc}/x)",
              f"  key       {key}" if key else "  key       (unchanged - the one handed over before)",
              f"  test      curl {'--cacert caddy-root.crt ' if ca else ''}-H \"X-API-Key: {key or 'THE KEY'}\" "
              f"{c['url']}/{svc}/     (any answer but 401: the key is right)"]
    with open(f, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(L) + "\n")
    return L


# ============================================================================ commands
def write_client_compose(cdir, name, doc, sys_path, how):
    with open(os.path.join(cdir, "compose.yml"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# {name}'s copy of the solution - made by xray_clients.py {VERSION} from {sys_path}\n"
                 f"# on {datetime.date.today()} ({how}). Its own network ({name}_net), data (./data, its own volumes) and "
                 "settings (.env).\n# No ports: the only way in is the proxy. Start / apply a change:  "
                 f"python xray_clients.py start {name}\n"
                 + "\n".join(to_yaml(doc, order=["name", "services", "networks", "volumes", "secrets", "configs"])) + "\n")


def save_client(cdir, c):
    with open(os.path.join(cdir, "client.json"), "w", encoding="utf-8") as fh:
        json.dump(c, fh, indent=1)


def cmd_add(a):
    root = os.path.abspath(a.root)
    name = a.name
    if not NAME_RE.match(name):
        die(f"{name}: a client's name is small letters, digits and -, starting with a letter (client-a, acme, city-2)")
    cdir = os.path.join(root, "clients", name)
    if os.path.exists(os.path.join(cdir, "client.json")):
        die(f"{name} exists already ({cdir}). New compose from the system: update {name}; a new password: password "
            f"{name}; a new key: key {name}")
    if os.path.exists(os.path.join(cdir, "client.json.removed")):
        die(f"{name} was removed before and its folder is still there ({cdir}) - its data too. Take another name, or "
            "delete that folder first (and its volumes: docker compose down -v in it)")
    sys_path, sysdoc = load_system(a.system)
    sysdir = os.path.dirname(sys_path)
    services = list(sysdoc.get("services", {}))
    web = split_expose([a.web] if a.web else [], services, "web")
    api = split_expose(a.api or [], services, "api")
    if not web and not api:
        die("give --web SERVICE:PORT (people open it in a browser) and/or --api SERVICE:PORT (machines call it)")
    others = clients_of(root)
    if a.ports:
        if not re.match(r"^\d+-\d+$", a.ports):
            die("--ports FIRST-LAST, e.g. 9441-9460")
        if others and proxy_conf(root).get("ports") != a.ports:
            die(f"--ports: the range is {proxy_conf(root).get('ports')} and {len(others)} client(s) use it - it changes "
                "only before the first client")
        proxy_conf(root, ports=a.ports)
    notes, made, writable = [], {}, []
    if a.host:
        if any(c.get("host") == a.host for c in others):
            die(f"--host {a.host} is {next(c['name'] for c in others if c.get('host') == a.host)}'s already")
        port, server = None, None
        tls = a.tls or "public"
        url = ("http://" if tls == "off" else "https://") + a.host
    else:
        if a.tls == "public":
            die("--tls public is for a DNS name (--host): a public certificate is made for a name, not for an IP and a "
                "port. With a port: --tls internal (the default) or --tls off")
        used = {c.get("port") for c in others}
        lo, hi = port_range(root)
        port = a.port or next((p for p in range(lo, hi + 1) if p not in used), None)
        if not port or not lo <= port <= hi:
            die(f"--port: one of {lo}-{hi} (the range the proxy publishes; proxy/proxy.json \"ports\") - free: "
                + (", ".join(str(p) for p in range(lo, hi + 1) if p not in used)[:80] or "none - make the range bigger"))
        if port in used:
            die(f"--port {port} is {next(c['name'] for c in others if c.get('port') == port)}'s already")
        tls = a.tls or "internal"
        server = a.server
        if tls != "off" and not server:
            die("--server: the address people use to reach this server (its IP, e.g. 192.168.1.50, or its name) - "
                "the proxy's certificate is made for it. Or --host NAME for a DNS name, or --tls off for plain http")
        url = ("http://" if tls == "off" else "https://") + (server or "SERVER") + f":{port}"
        sni = proxy_conf(root).get("default_sni")
        if tls == "internal" and sni and server != sni and (re.match(r"^[\d.]+$", server) or ":" in server):
            notes.append(f"--server {server}: the proxy already answers IP addresses with {sni}'s certificate "
                         "(default_sni in proxy/proxy.json): a browser typing this IP gets a certificate error. "
                         "Use the same --server for every client reached by port, or a name (--host)")
    if tls == "off":
        notes.append("--tls off: the password and the API key travel UNENCRYPTED - only inside a network you trust")
    if "SERVER" in url:
        notes.append("the address has SERVER in it: put the server's address there in ACCESS.txt (or add with --server)")
    key = secrets.token_urlsafe(32) if api else None
    pw = secrets.token_urlsafe(15) if web else None
    pw_hash = hash_password(pw) if pw else None             # before any file: a failure leaves nothing half made
    os.makedirs(cdir, exist_ok=True)
    doc, files = client_compose(name, sysdoc, sysdir, cdir, web + api, notes, writable)
    env_for_client(name, sysdir, files, cdir, made)
    write_client_compose(cdir, name, doc, sys_path, "add")
    c = {"name": name, "network": f"{name}_net", "host": a.host, "port": port, "server": server, "tls": tls,
         "url": url, "web": list(web[0]) if web else None, "api": [list(x) for x in api], "user": name,
         "system": sys_path, "writable": writable, "created": str(datetime.date.today()), "tool": VERSION}
    save_client(cdir, c)
    ensure_network(c["network"])
    write_proxy(root, a.email, server if tls == "internal" else None)
    write_site(root, c, key, pw_hash)
    acc = write_access(root, c, key, pw)
    print(f"{name}: ready to start\n")
    print(f"  {cdir}")
    print("    compose.yml   the system's services, closed off: no ports, no container names, its own network")
    print("    .env          the system's settings" + (f", new secrets: {', '.join(sorted(made))}" if made else ""))
    print("    data/         its files    ACCESS.txt   what to hand over    client.json   its settings for this tool")
    print(f"  {os.path.join(proxy_dir(root), 'sites', name + '.caddy')}   its way in\n")
    for n in notes:
        print("  NOTE " + n)
    print("\n" + "\n".join("  " + x for x in acc[3:]))
    print(f"\nNext: change in {os.path.join(cdir, '.env')} what differs for {name} (its cameras, options), then:\n"
          f"  python xray_clients.py start {name}")


def load_client(root, name):
    f = os.path.join(root, "clients", name, "client.json")
    if not os.path.isfile(f):
        die(f"no client {name} in {os.path.join(root, 'clients')} (python xray_clients.py list)")
    with open(f, encoding="utf-8") as fh:
        return json.load(fh)


def ids_of(image, user):
    """the user id + group id a program runs as (its compose user:, else its image's USER); None for root"""
    u = str(user or "")
    if not u:
        r = run(["docker", "image", "inspect", "-f", "{{.Config.User}}", image], check=False)
        u = r.stdout.strip() if r.returncode == 0 else ""
    if u in ("", "root", "0", "0:0"):
        return None
    m = re.match(r"^(\d+)(?::(\d+))?$", u)
    if m:
        return int(m.group(1)), int(m.group(2) or m.group(1))
    r = run(["docker", "run", "--rm", "--user", u, "--entrypoint", "sh", image, "-c", "id -u; id -g"], check=False)
    x = r.stdout.split()
    return (int(x[0]), int(x[1])) if r.returncode == 0 and len(x) == 2 and all(i.isdigit() for i in x) else "?"


def own_folders(cdir, writable):
    """Linux: a folder a program writes to must belong to the user the program runs as (on Windows and Mac,
    Docker Desktop does not check this); returns what could not be done"""
    if os.name != "posix" or sys.platform == "darwin" or not writable:
        return []
    r = run(["docker", "compose", "config", "--format", "json"], cwd=cdir, check=False)   # ${VERSION} filled in
    svcs = json.loads(r.stdout).get("services", {}) if r.returncode == 0 else {}
    todo, seen = [], {}
    for sname, image, user, rel in writable:
        image = (svcs.get(sname) or {}).get("image") or image
        user = (svcs.get(sname) or {}).get("user") or user
        k = (image, user)
        ids = seen[k] if k in seen else seen.setdefault(k, ids_of(image, user))
        p = os.path.join(cdir, rel)
        if not ids or not os.path.isdir(p):
            continue
        if ids == "?":
            todo.append(f"{sname} writes to {p}: give that folder to the user the program runs as (chown)")
            continue
        st = os.stat(p)
        if (st.st_uid, st.st_gid) == ids:
            continue
        if os.geteuid() == 0:
            os.chown(p, *ids)
        else:
            todo.append(f"sudo chown {ids[0]}:{ids[1]} {p}     ({sname} runs as {ids[0]} and writes there)")
    return todo


def ps(cdir):
    """[{Service, State, ExitCode, ...}] of the client's containers"""
    r = run(["docker", "compose", "ps", "-a", "--format", "json"], cwd=cdir, check=False)
    out = r.stdout.strip()
    if r.returncode != 0 or not out:
        return []
    if out.startswith("["):
        return json.loads(out)
    return [json.loads(x) for x in out.splitlines() if x.strip().startswith("{")]


def bad_now(cdir):
    """{service: what is wrong} - stopping again and again, stopped with an error, or its health check failing"""
    out = {}
    for x in ps(cdir):
        st, health = x.get("State", ""), x.get("Health", "")
        if health == "unhealthy":
            out[x.get("Service")] = "unhealthy (its health check fails)"
        elif st in ("restarting", "dead") or (st == "exited" and x.get("ExitCode", 0) != 0):
            out[x.get("Service")] = "stopping again and again" if st == "restarting" else f"stopped ({st})"
    return out


def settle(cdir, seconds=15):
    """a program that crashes right after the start is "running" for a moment: look again a few seconds later"""
    bad = {}
    end = time.time() + seconds
    while time.time() < end:
        time.sleep(3)
        bad.update(bad_now(cdir))
    return bad


def show_bad(cdir, bad):
    for svc, st in bad.items():
        lg = run(["docker", "compose", "logs", "--tail", "20", svc], cwd=cdir, check=False)
        print(f"\n{svc}: {st} - its last lines:\n" + (lg.stdout + lg.stderr).strip()[-2500:])


def wait_proxy(root):
    """compose "up" returns before Caddy has read its settings"""
    for _ in range(30):
        lg = run(["docker", "compose", "logs", "caddy"], cwd=proxy_dir(root), check=False)
        out = lg.stdout + lg.stderr
        if out.count("serving initial configuration") >= 1 and not run(
                ["docker", "compose", "ps", "--status", "restarting", "-q"], cwd=proxy_dir(root), check=False).stdout.strip():
            return
        time.sleep(1)
    lg = run(["docker", "compose", "logs", "--tail", "30", "caddy"], cwd=proxy_dir(root), check=False)
    die("the proxy did not come up - its last lines:\n" + (lg.stdout + lg.stderr).strip()[-2000:])


def copy_root_cert(root, c):
    """the proxy's root certificate next to ACCESS.txt (a certificate, no key: safe to hand out)"""
    if c["tls"] != "internal":
        return None
    dst = os.path.join(root, "clients", c["name"], "caddy-root.crt")
    for _ in range(10):                         # Caddy makes its authority with the first internal certificate
        r = run(["docker", "compose", "cp", "caddy:/data/caddy/pki/authorities/local/root.crt", dst],
                cwd=proxy_dir(root), check=False)
        if r.returncode == 0 and os.path.isfile(dst):
            return dst
        time.sleep(1)
    print("  could not copy the proxy's root certificate yet - later, in proxy/:  docker compose cp "
          f"caddy:/data/caddy/pki/authorities/local/root.crt ../clients/{c['name']}/caddy-root.crt")
    return None


def cmd_start(a):
    root = os.path.abspath(a.root)
    c = load_client(root, a.name)
    cdir = os.path.join(root, "clients", a.name)
    ensure_network(c["network"])
    for x in own_folders(cdir, c.get("writable")):
        print("  DO THIS " + x)
    print(f"starting {a.name} (docker compose up -d in {cdir}) ...")
    old_bad = bad_now(cdir)                     # left failing by an earlier start: start them fresh after the fix
    if old_bad:
        run(["docker", "compose", "rm", "-s", "-f"] + list(old_bad), cwd=cdir, check=False)
    r = run(["docker", "compose", "up", "-d", "--wait", "--wait-timeout", str(a.wait)], cwd=cdir, check=False)
    if r.returncode != 0:
        print((r.stderr or r.stdout).strip()[-1500:])
        show_bad(cdir, bad_now(cdir))
        die(f"{a.name} did not start (healthy) within {a.wait}s - the reason is above; all its output:  cd {cdir}  "
            "then  docker compose logs --tail 50")
    bad = settle(cdir)
    write_proxy(root)
    cid, remade = proxy_running(root), False
    if cid:
        pb = run(["docker", "inspect", "-f", "{{json .HostConfig.PortBindings}}", cid], check=False).stdout.strip()
        have = set(json.loads(pb or "{}") or {})
        lo, hi = port_range(root)
        want = {f"{lo}/tcp", f"{hi}/tcp"} | ({"443/tcp"} if any(x.get("host") for x in clients_of(root)) else set())
        if not want <= have or ("443/tcp" in have) != ("443/tcp" in want):
            print("the proxy's ports change (80 + 443 for names, or a new range): the proxy is made again - every "
                  "client is unreachable for a few seconds")
            r = run(["docker", "compose", "up", "-d"], cwd=proxy_dir(root), check=False)
            if r.returncode != 0:
                die("the proxy did not start:\n" + (r.stderr or r.stdout).strip()[-1500:])
            wait_proxy(root)
            cid, remade = proxy_running(root), True
    if cid:
        nr = run(["docker", "network", "connect", c["network"], cid], check=False)
        if nr.returncode != 0 and "already exists" not in (nr.stderr + nr.stdout):
            die("could not connect the proxy to " + c["network"] + ":\n" + nr.stderr.strip())
        reload_proxy(root)
        print(f"the proxy joined {c['network']} and took {a.name}'s settings"
              + ("" if remade else " - no other client was interrupted"))
    else:
        print("starting the proxy ...")
        r = run(["docker", "compose", "up", "-d"], cwd=proxy_dir(root), check=False)
        if r.returncode != 0:
            die("the proxy did not start:\n" + (r.stderr or r.stdout).strip()[-1500:])
        wait_proxy(root)
    if bad:
        show_bad(cdir, bad)
        print(f"\n{a.name}: {', '.join(bad)} {'keeps' if len(bad) == 1 else 'keep'} stopping - fix that first "
              "(above: the reason), then start again")
        return 1
    crt = copy_root_cert(root, c)
    print(f"\n{a.name} is running: {c['url']}")
    if crt:
        print(f"Hand over: ACCESS.txt + caddy-root.crt (in {os.path.dirname(crt)})")
    print(f"Next:  python xray_clients.py test {a.name}")


class _Https(http.client.HTTPSConnection):
    """connect to one address, present another name (SNI) - what a browser does after DNS"""
    def __init__(self, ip, port, name, ctx):
        super().__init__(ip, port, timeout=15, context=ctx)
        self._name = name

    def connect(self):
        sock = socket.create_connection((self.host, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self._name)


def fetch(url, headers=None, auth=None, local=True):
    """GET url; local: through this machine (127.0.0.1) with the address's name - no DNS, no LAN needed"""
    u = urllib.parse.urlsplit(url)
    port = u.port or (443 if u.scheme == "https" else 80)
    ip = "127.0.0.1" if local else u.hostname
    h = dict(headers or {}, Host=u.netloc)
    if auth:
        h["Authorization"] = "Basic " + base64.b64encode(f"{auth[0]}:{auth[1]}".encode()).decode()
    ctx = ssl._create_unverified_context()        # the test only: the proxy's own certificate is not installed here
    try:
        conn = _Https(ip, port, u.hostname, ctx) if u.scheme == "https" else http.client.HTTPConnection(ip, port, timeout=15)
        conn.request("GET", u.path or "/", headers=h)
        r = conn.getresponse()
        r.read()
        conn.close()
        return r.status
    except Exception as e:                           # noqa: BLE001
        return f"no answer ({str(e)[:80]})"


def cmd_test(a):
    root = os.path.abspath(a.root)
    c = load_client(root, a.name)
    key, _h = read_site(root, a.name)
    acc = open(os.path.join(root, "clients", a.name, "ACCESS.txt"), encoding="utf-8").read()
    m = re.search(r"password  (\S+)", acc)
    pw = a.password or (m.group(1) if m and not m.group(1).startswith("(") else None)
    # the client's own address, sent through this machine: the proxy picks the client by that address
    base = (a.url or c["url"].replace("SERVER", "127.0.0.1")).rstrip("/")
    local = not a.url

    def http(u, headers=None, auth=None):
        return fetch(u, headers, auth, local)
    rows = []
    for svc, _p in c["api"]:
        u = f"{base}/{svc}/"
        rows += [(f"{svc}: no key", http(u), "401"), (f"{svc}: a wrong key", http(u, {"X-API-Key": "wrong"}), "401"),
                 (f"{svc}: its key", http(u, {"X-API-Key": key}), "not 401 (the program's own answer)")]
    if c["web"]:
        u = base + "/"
        rows += [("dashboard: no password", http(u), "401"), ("dashboard: a wrong one", http(u, auth=(c["user"], "x")), "401")]
        if pw:
            rows.append(("dashboard: its password", http(u, auth=(c["user"], pw)), "not 401"))
        else:
            print("(its password is not in ACCESS.txt any more - add --password THE-PASSWORD to check it too)")
    bad = 0
    print(f"{a.name} through the proxy - {base}" + ("   (sent to this machine, as a browser would send it)"
                                                        if local else ""))
    for what, got, want in rows:
        ok = (str(got) == want) if want.isdigit() else (isinstance(got, int) and got != 401)
        bad += not ok
        print(f"  {'OK  ' if ok else 'FAIL'} {what:<26} -> {got}   (want {want})")
    print("\nall as it should be" if not bad else f"\n{bad} not as it should be - docker compose logs in proxy/ and "
                                                   f"clients/{a.name}/")
    return 1 if bad else 0


def cmd_list(a):
    root = os.path.abspath(a.root)
    cs = clients_of(root)
    if not cs:
        print("no clients yet:  python xray_clients.py add NAME --system ... --web ... --api ...")
        return
    print(f"{'client':<14} {'address':<34} {'people':<18} {'machines':<22} running")
    for c in cs:
        r = run(["docker", "compose", "ps", "--format", "{{.Service}} {{.State}}"],
                cwd=os.path.join(root, "clients", c["name"]), check=False)
        states = [x.split()[-1] for x in r.stdout.split("\n") if x.strip()]
        up = f"{sum(s == 'running' for s in states)}/{len(states)}" if states else "stopped"
        print(f"{c['name']:<14} {c['url']:<34} {(':'.join(map(str, c['web'])) if c['web'] else '-'):<18} "
              f"{', '.join(f'/{s}/' for s, _p in c['api']) or '-':<22} {up}")


def rotate(a, new_pw, new_key):
    root = os.path.abspath(a.root)
    c = load_client(root, a.name)
    key, h = read_site(root, a.name)
    pw = None
    if new_pw:
        if not c["web"]:
            die(f"{a.name} has no dashboard (--web)")
        pw = secrets.token_urlsafe(15)
        h = hash_password(pw)
    if new_key:
        if not c["api"]:
            die(f"{a.name} has no API (--api)")
        key = secrets.token_urlsafe(32)
    write_site(root, c, key, h)
    acc = write_access(root, c, key, pw)
    done = reload_proxy(root)
    print(f"{a.name}: new {'password' if new_pw else 'API key'} - " + ("active now: the old one no longer works, "
          "no container restarted" if done else "active when the proxy starts"))
    print("\n".join("  " + x for x in acc[3:]))


def cmd_update(a):
    root = os.path.abspath(a.root)
    c = load_client(root, a.name)
    cdir = os.path.join(root, "clients", a.name)
    if a.server:
        if c.get("host"):
            die(f"{a.name} is reached by its name {c['host']}, not by the server's address")
        old_url = c["url"]
        c["server"] = a.server
        c["url"] = ("http://" if c["tls"] == "off" else "https://") + a.server + f":{c['port']}"
        key, h = read_site(root, a.name)
        write_site(root, c, key, h)
        write_access(root, c, key, None)
        save_client(cdir, c)
        by_port = {x["server"] for x in clients_of(root) if not x.get("host") and x.get("tls") == "internal"
                   and x.get("server")}
        if len(by_port) == 1:                   # every client by port has this address now: IPs get its certificate
            proxy_conf(root, server=a.server, force_sni=True)
        write_proxy(root)
        done = reload_proxy(root)
        print(f"{a.name}: {old_url} -> {c['url']}" + (" - active now" if done else ""))
        sni = proxy_conf(root).get("default_sni")
        if c["tls"] == "internal" and sni != a.server:
            left = sorted(x["name"] for x in clients_of(root) if x.get("server") == sni and not x.get("host"))
            print(f"  NOTE an address typed as an IP gets {sni}'s certificate until every client by port has moved "
                  f"({', '.join(left)} still on {sni}): python xray_clients.py update NAME --server {a.server}")
        if not a.system:
            return
    sys_path, sysdoc = load_system(a.system or c["system"])
    exposed = ([tuple(c["web"])] if c["web"] else []) + [tuple(x) for x in c["api"]]
    notes, made, writable = [], {}, []
    doc, files = client_compose(a.name, sysdoc, os.path.dirname(sys_path), cdir, exposed, notes, writable)
    env_for_client(a.name, os.path.dirname(sys_path), files, cdir, made)
    old = os.path.join(cdir, "compose.yml")
    if os.path.isfile(old):
        shutil.copy2(old, old + ".before-update")
    write_client_compose(cdir, a.name, doc, sys_path, "update")
    c["system"], c["writable"] = sys_path, writable
    save_client(cdir, c)
    print(f"{a.name}: compose.yml made again from {sys_path} (the old one: compose.yml.before-update); its .env, "
          "secrets and data are as they were" + (f"; env files new for it: {', '.join(sorted(made))}" if made else ""))
    for n in notes:
        print("  NOTE " + n)
    print(f"Apply:  python xray_clients.py start {a.name}   (only the services whose settings changed are recreated)")


def cmd_remove(a):
    root = os.path.abspath(a.root)
    c = load_client(root, a.name)
    cdir = os.path.join(root, "clients", a.name)
    site = os.path.join(proxy_dir(root), "sites", a.name + ".caddy")
    if os.path.isfile(site):
        os.replace(site, os.path.join(cdir, "site.caddy.removed"))
    reload_proxy(root)
    cid = proxy_running(root)
    if cid:
        run(["docker", "network", "disconnect", c["network"], cid], check=False)
    r = run(["docker", "compose", "down"], cwd=cdir, check=False)
    run(["docker", "network", "rm", c["network"]], check=False)
    os.replace(os.path.join(cdir, "client.json"), os.path.join(cdir, "client.json.removed"))
    write_proxy(root)
    print(f"{a.name}: off the proxy and stopped" + ("" if r.returncode == 0 else " (docker compose down: "
                                                    + r.stderr.strip()[:200] + ")"))
    print(f"Its folder and data stay: {cdir}   its volumes too:  docker volume ls --filter name={a.name}_")
    print("Gone for good, once you are sure (a backup first?):  docker compose down -v  in that folder, then delete it.")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".", help="the hosting folder: proxy/ and clients/ are in it (default: here)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("add", help="a new client: its folder, compose, .env with new secrets, its way in")
    p.add_argument("name")
    p.add_argument("--system", required=True, help="the compose file of your whole solution")
    p.add_argument("--web", help="SERVICE:PORT people open in a browser (user name + password), e.g. dashboard:8080")
    p.add_argument("--api", action="append", help="SERVICE:PORT machines call (API key), e.g. middle:5014 - repeatable")
    p.add_argument("--server", help="the server's address people use (IP or name), for clients reached by port")
    p.add_argument("--port", type=int, help=f"the client's port on the server (in {PORTS}; default: the next free)")
    p.add_argument("--host", help="a DNS name for this client instead of a port, e.g. client-a.yourcompany.com")
    p.add_argument("--tls", choices=("internal", "public", "off"),
                   help="https with the proxy's own certificate (default for ports) / a public one (default for names) / plain http")
    p.add_argument("--email", help="for public certificates: the address Let's Encrypt writes to")
    p.add_argument("--ports", help=f"FIRST-LAST: the proxy's port range (default {PORTS}) - with the first client only")
    p.set_defaults(func=cmd_add)
    for n, f, h in (("start", cmd_start, "start / apply: the client up, the proxy connected and reloaded"),
                    ("test", cmd_test, "check the way in: keys and passwords, through the proxy"),
                    ("password", lambda x: rotate(x, True, False), "a new dashboard password"),
                    ("key", lambda x: rotate(x, False, True), "a new API key"),
                    ("remove", cmd_remove, "off the proxy and stopped (folder and data stay)")):
        s = sub.add_parser(n, help=h)
        s.add_argument("name")
        if n == "test":
            s.add_argument("--url", help="call this address for real (DNS, the network) instead of through this machine")
            s.add_argument("--password", help="the dashboard password, when ACCESS.txt no longer has it")
        if n == "start":
            s.add_argument("--wait", type=int, default=300, help="seconds to wait for healthy (default 300)")
        s.set_defaults(func=f)
    u = sub.add_parser("update", help="the client's compose made again from the system compose")
    u.add_argument("name")
    u.add_argument("--system", help="default: the one it was made from")
    u.add_argument("--server", help="the server's new address (its IP changed): the client's address follows")
    u.set_defaults(func=cmd_update)
    sub.add_parser("list", help="every client").set_defaults(func=cmd_list)
    a = ap.parse_args(argv)
    return a.func(a) or 0


if __name__ == "__main__":
    sys.exit(main())
