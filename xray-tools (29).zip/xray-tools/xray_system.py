#!/usr/bin/env python3
"""xray_system.py - several projects as ONE system: who calls whom, what has to change, and a compose file that
starts them together and connects them. Stdlib only, Python 3.8+. It reads files only.

    python xray_system.py --project toll=runs\\toll\\toll.json --project fastag=runs\\fastag\\fastag.json
                          --project anpr=runs\\anpr\\anpr.json --out runs\\system

Each --project is NAME=its Step 1 map (or its Step 2 merged map: then the addresses the run really used count too).
NAME becomes the service name in compose - and the host name the others reach it by.

It matches what one project CALLS (an address with a port: requests.post("http://...:5000/x"), a database ...)
with what another one LISTENS on (app.run(port=5000), uvicorn ...) - by the port. From that:
  - the connections, and the env var that holds each address (or the line where it is written in the code)
  - what must change first: a server that listens on 127.0.0.1 (no other container reaches it), an address written
    in the code (compose cannot change it), a folder written in the code that another project must read
  - the start order (a server before the projects that call it) - depends_on + a healthcheck
  - compose.yml: one service per project, one network, the addresses as service names, no IPs
Writes OUT/system.txt (the report) and OUT/compose.yml. SERVICES_GUIDE.md section 9 explains every line.
"""
import argparse
import json
import os
import re
import sys

VERSION = "0.1.0"
HERE = os.path.dirname(os.path.abspath(__file__))

DB_PORTS = {5432: ("PostgreSQL", "postgres:16"), 3306: ("MySQL", "mysql:8.4"), 6379: ("Redis", "redis:7"),
            27017: ("MongoDB", "mongo:7"), 1433: ("SQL Server", "mcr.microsoft.com/mssql/server:2022-latest"),
            5672: ("RabbitMQ", "rabbitmq:3-management"), 9092: ("Kafka", None), 1883: ("MQTT", "eclipse-mosquitto:2")}
LOCAL = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "host.docker.internal"}
URL_RE = re.compile(r"^(?:([a-z][a-z0-9+.-]*)://)?(?:[^/@]*@)?(\[[^\]]+\]|[^/:?#\s]+)(?::(\d{1,5}))?(/[^?#\s]*)?", re.I)
WIN_RE = re.compile(r"^[A-Za-z]:[\\/]")
IP_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def slug(s):
    return re.sub(r"[^a-z0-9-]+", "-", s.lower()).strip("-") or "app"


def site_of(f):
    return next((f"{s.get('file')}:{s.get('line')}" for s in f.get("sites") or [] if s.get("line")), "")


def parse_addr(text):
    """'http://10.0.0.5:5000/x' / '10.0.0.5:5000' -> (scheme, host, port or None, path)"""
    m = URL_RE.match(str(text or "").strip())
    if not m:
        return None
    scheme, host, port, path = m.group(1), m.group(2).strip("[]"), m.group(3), m.group(4) or ""
    if port is None and scheme:
        port = {"http": 80, "https": 443}.get(scheme.lower())
    return (scheme or "", host, int(port) if port else None, path)


def live(f):
    return f.get("required_at_runtime") != "no"


def workdir_of(dockerfile):
    try:
        txt = open(dockerfile, encoding="utf-8-sig", errors="replace").read()
    except (OSError, TypeError):
        return "/app"
    w = re.findall(r"(?im)^\s*WORKDIR\s+(\S+)", txt)
    return w[-1] if w else "/app"


class Project:
    def __init__(self, name, path, dockerfile=None):
        self.name, self.path = slug(name), path
        with open(path, encoding="utf-8") as fh:
            m = json.load(fh)
        self.root = m.get("root") or os.path.dirname(os.path.abspath(path))
        facts = [f for f in m.get("facts", []) if live(f)]
        self.servers, self.calls, self.envs, self.literals, self.writes = [], [], {}, [], []
        self.reads_var, self.gpu = False, False
        for f in facts:
            c, s = f["category"], str(f.get("subject"))
            if c == "listen_port":
                port = f.get("port")
                self.servers.append({"host": f.get("host") or s.rsplit(":", 1)[0],
                                     "port": int(port) if str(port).isdigit() else None, "site": site_of(f)})
            elif c == "network_endpoint" and not s.startswith("<"):
                a = parse_addr(s)
                if a and a[2]:
                    self.calls.append({"host": a[1], "port": a[2], "site": site_of(f), "subject": s})
            elif c == "env_var" and f.get("default"):
                a = parse_addr(f["default"])
                if a and a[2] and ("://" in str(f["default"]) or a[1] in LOCAL or IP_RE.match(a[1])):
                    self.envs[(a[1].lower(), a[2])] = (str(f["subject"]), str(f["default"]), site_of(f))
            elif c == "hardcoded_config" and f.get("mechanism") == "string_literal" and "://" in s:
                self.literals.append((s, site_of(f)))
            elif c == "file_write" and not s.startswith("<") and not s.startswith("/tmp"):
                self.writes.append((s, site_of(f), f.get("path_envs") or []))
            elif c == "data_file_read" and s.startswith("<"):
                self.reads_var = True
            elif c == "gpu_usage":
                self.gpu = True
        # the Dockerfile compose builds: X-Ray's slim plan, else the naive one, else the project's own
        cand = [dockerfile] if dockerfile else [os.path.join(HERE, "runs", self.name, "plan", "Dockerfile"),
                                                 os.path.join(self.root, "Dockerfile.naive"),
                                                 os.path.join(self.root, "Dockerfile")]
        self.dockerfile = next((d for d in cand if d and os.path.isfile(d)), None)
        self.workdir = workdir_of(self.dockerfile) if self.dockerfile else "/app"

    def env_for(self, host, port):
        """the env var whose default is this address (host and port), or one with the same port"""
        hit = self.envs.get((host.lower(), port))
        if hit:
            return hit
        same = [v for (h, p), v in self.envs.items() if p == port]
        return same[0] if len(same) == 1 else None

    def literal_for(self, host, port, site=""):
        """the address as written in the code: a URL literal of the map, else read from the source line itself"""
        for s, where in self.literals:
            a = parse_addr(s)
            if a and a[1].lower() == host.lower() and a[2] == port:
                return s, where
        if ":" in site:
            fn, _, line = site.rpartition(":")
            try:
                with open(os.path.join(self.root, fn), encoding="utf-8", errors="replace") as fh:
                    text = fh.readlines()[int(line) - 1]
            except (OSError, ValueError, IndexError):
                return None
            m = re.search(r"[a-z][a-z0-9+.-]*://[^\s\"']*" + re.escape(f"{host}:{port}") + r"[^\s\"']*", text, re.I) \
                or re.search(r"[a-z][a-z0-9+.-]*://" + re.escape(f"{host}:{port}") + r"[^\s\"']*", text, re.I)
            if m:
                return m.group(0), site
        return None


def main():
    ap = argparse.ArgumentParser(description="Several projects as one system: connections, changes, compose.yml")
    ap.add_argument("--project", action="append", required=True, metavar="NAME=MAP",
                    help="a project: its service name = its Step 1 map (NAME.json) or Step 2 merged map")
    ap.add_argument("--dockerfile", action="append", default=[], metavar="NAME=FILE",
                    help="the Dockerfile to build a project from (default: runs/NAME/plan/Dockerfile, else "
                         "PROJECT/Dockerfile.naive, else PROJECT/Dockerfile)")
    ap.add_argument("--link", action="append", default=[], metavar="CALLER=SERVER",
                    help="when two projects listen on the same port: which one CALLER calls")
    ap.add_argument("--name", default="system", help="the compose project / network name (default: system)")
    ap.add_argument("--out", default=os.path.join(HERE, "runs", "system"), help="folder for system.txt + compose.yml")
    a = ap.parse_args()
    dfs = dict(x.split("=", 1) for x in a.dockerfile if "=" in x)
    forced = {}
    for x in a.link:
        if "=" in x:
            k, v = x.split("=", 1)
            forced.setdefault(slug(k), set()).add(slug(v))
    projects = []
    for spec in a.project:
        if "=" not in spec:
            sys.exit(f"--project {spec}: expected NAME=MAP, e.g. toll=runs\\toll\\toll.json")
        n, p = spec.split("=", 1)
        if not os.path.isfile(p):
            sys.exit(f"--project {spec}: no such file {p} (run Step 1 for it: xray_static.py ... --out {p})")
        projects.append(Project(n, p, dfs.get(n)))
    by = {p.name: p for p in projects}
    if len(by) != len(projects):
        sys.exit("two projects have the same NAME")

    servers = {}                                   # port -> [project names listening on it]
    for p in projects:
        for s in p.servers:
            if s["port"]:
                servers.setdefault(s["port"], []).append(p.name)

    links, outside, ambiguous, blockers, changes, checks = [], [], [], [], [], []
    for p in projects:
        for c in p.calls:
            cands = [n for n in servers.get(c["port"], []) if n != p.name]
            if forced.get(p.name):
                cands = [n for n in cands if n in forced[p.name]] or cands
            if len(cands) > 1:
                ambiguous.append((p.name, c, cands))
                continue
            if not cands:
                outside.append((p.name, c))
                continue
            s = by[cands[0]]
            env = p.env_for(c["host"], c["port"])
            lit = p.literal_for(c["host"], c["port"], c["site"])
            url = env[1] if env else lit[0] if lit else f"http://{c['host']}:{c['port']}"
            sch, _h, _po, path = parse_addr(url)
            new = f"{sch or 'http'}://{s.name}:{c['port']}{path}"
            if not env:
                var = re.sub(r"[^A-Z0-9]+", "_", s.name.upper()) + "_URL"
                where = lit[1] if lit else c["site"]
                changes.append(f"{p.name}: {where}: the address {url} is written in the code - compose cannot change "
                               f"it. Read it from an env var: {var} = os.getenv(\"{var}\", \"{url}\")")
            else:
                var = env[0]
            links.append({"caller": p.name, "server": s.name, "port": c["port"], "var": var, "url": new,
                          "old": url, "env": bool(env), "site": c["site"]})

    called = {l["server"] for l in links}
    for p in projects:
        for s in p.servers:
            if s["host"] in ("127.0.0.1", "localhost", "::1"):
                txt = (f"{p.name}: {s['site']}: it listens on {s['host']}:{s['port']} - inside its container only, so "
                       f"{'the projects that call it cannot' if p.name in called else 'nothing outside it can'} reach "
                       f"it. Change it to "
                       f"0.0.0.0, e.g. app.run(host=\"0.0.0.0\", port={s['port']})")
                (blockers if p.name in called else changes).append(txt)
            if not s["port"]:
                checks.append(f"{p.name}: {s['site']}: it starts a server, but the port is not written in the code - "
                              "find it in its log (Running on ...) and add it to compose by hand")

    # folders: a caller writes files and the server it calls opens a file whose path comes from its input
    shared = []
    for l in links:
        p, s = by[l["caller"]], by[l["server"]]
        if not (p.writes and s.reads_var):
            continue
        dirs = []
        for path, site, envs in p.writes:
            d = path if not os.path.splitext(path)[1] else os.path.dirname(path)
            if d and d not in [x[0] for x in dirs]:
                dirs.append((d, site, envs))
        for d, site, envs in dirs[:2]:
            key = slug(p.name + "-" + (os.path.basename(d.replace("\\", "/").rstrip("/")) or "files"))
            target = "/shared/" + key
            if envs:
                note = f"{envs[0]} = {target} in both"
                envset = envs[0]
            elif WIN_RE.match(d) or d.startswith(("/home/", "/Users/")):
                envset = re.sub(r"[^A-Z0-9]+", "_", os.path.basename(d.rstrip("/\\")).upper()) + "_DIR"
                changes.append(f"{p.name}: {site}: the folder {d} is written in the code (a path of one PC). Read it from "
                               f"an env var - {envset} = os.getenv(\"{envset}\", \"{d}\") - then compose gives {p.name} and "
                               f"{s.name} the same folder")
                note = f"{envset} = {target} in both (after the code change)"
            else:
                envset, target = None, (d if d.startswith("/") else p.workdir.rstrip("/") + "/" + d.lstrip("./"))
                note = f"the same path in both: {target}"
            shared.append({"caller": p.name, "server": s.name, "dir": d, "key": key, "target": target, "env": envset,
                           "note": note})
            checks.append(f"{p.name} writes files into {d} ({site}) and {s.name} opens a file whose path comes from its "
                          f"input. If {p.name} sends the file's PATH (not its content), both need the same folder at the "
                          f"same path: compose mounts ./shared/{key} into both ({note}). If it sends the content, "
                          "remove those lines")

    dbs = {}
    for p, c in outside:
        if c["port"] in DB_PORTS:
            dbs.setdefault(c["port"], []).append(p.name)

    # start order: the servers first (Kahn), callers after; a cycle is reported and not ordered
    deps = {p.name: sorted({l["server"] for l in links if l["caller"] == p.name}) for p in projects}
    order, left = [], dict(deps)
    while left:
        ready = sorted(n for n, d in left.items() if all(x in order for x in d))
        if not ready:
            cyc = sorted(left)
            checks.append("these projects call each other in a circle: " + ", ".join(cyc) + " - compose cannot start "
                          "them in an order (depends_on is left out between them); each must retry its calls")
            for n in cyc:
                deps[n] = [x for x in deps[n] if x not in cyc]
            order += cyc
            break
        order += ready
        for n in ready:
            del left[n]

    os.makedirs(a.out, exist_ok=True)
    R = [f"xray_system {VERSION} - {len(projects)} projects as one system ({a.name})", ""]
    R.append("PROJECTS")
    for p in projects:
        role = ("server on " + ", ".join(f"{s['host']}:{s['port'] or '?'}" for s in p.servers)) if p.servers else \
            "no server (a worker / program)"
        R.append(f"  {p.name:<14} {role}{' - GPU' if p.gpu else ''}")
        R.append(f"  {'':<14} build: {p.dockerfile or 'NO DOCKERFILE FOUND - give one with --dockerfile ' + p.name + '=FILE'}")
    R += ["", "CONNECTIONS (who calls whom - matched by the port)"]
    for l in links:
        how = f"env {l['var']}" if l["env"] else f"written in the code ({l['site']}) -> env {l['var']} after the change"
        R.append(f"  {l['caller']} -> {l['server']}:{l['port']}   now {l['old']}   in compose {l['url']}   ({how})")
    for n, c, cands in ambiguous:
        R.append(f"  {n} -> {c['host']}:{c['port']} ({c['site']}): {', '.join(cands)} all listen on {c['port']} - say "
                 f"which: --link {n}={cands[0]}")
    if not links and not ambiguous:
        R.append("  none found: no project calls an address with a port another project listens on")
    if outside:
        R += ["", "CALLS TO THINGS OUTSIDE THESE PROJECTS"]
        for n, c in outside:
            what = DB_PORTS.get(c["port"], (None,))[0]
            R.append(f"  {n} -> {c['host']}:{c['port']}  ({c['site']})" + (f" - a {what} database" if what else "") +
                     (" - localhost: in a container that is the container itself" if c["host"] in LOCAL else ""))
        for port, who in sorted(dbs.items()):
            name, img = DB_PORTS[port]
            checks.append(f"{', '.join(who)} use{'s' if len(who) == 1 else ''} a {name} database ({port}). Already on a "
                          f"server: keep its address (an env var) - from a container it is reached as from the PC. To run "
                          f"it in this system too: the commented 'db' service in compose.yml (image {img}), and the "
                          "address becomes db")
    R += ["", "START ORDER (a server before the projects that call it)", "  " + " -> ".join(order)]
    R += ["", "MUST CHANGE (else the connection does not work)"] + (["  " + x for x in blockers] or ["  nothing"])
    R += ["", "CODE CHANGES (so compose can set the addresses / folders)"] + (["  " + x for x in changes] or ["  none"])
    R += ["", "CHECK"] + (["  " + x for x in checks] or ["  nothing"])
    R += ["", f"compose: {os.path.join(a.out, 'compose.yml')} - every project on one network ({a.name}_net); they reach "
              "each other by NAME (no IPs). Start: docker compose -f compose.yml up -d --build"]
    report = "\n".join(R) + "\n"

    # ---- compose.yml
    C = [f"# Generated by xray_system.py {VERSION}: {', '.join(p.name for p in projects)} as ONE system.",
         "# Every service is on one network; a service's NAME is its host name there (no IPs). The servers start first",
         "# (depends_on + healthcheck). Read system.txt first: what MUST CHANGE in the code before this works.",
         "#   docker compose -f compose.yml up -d --build      docker compose ps      docker compose logs -f NAME",
         f"name: {a.name}", "", "services:"]
    for n in order:
        p = by[n]
        C.append(f"  {n}:")
        if p.dockerfile:
            C += ["    build:", f"      context: {p.root}", f"      dockerfile: {p.dockerfile}"]
        else:
            C += ["    build:", f"      context: {p.root}", "      # dockerfile: NO DOCKERFILE FOUND - write the path here"]
        C.append("    restart: unless-stopped")
        env = [l for l in links if l["caller"] == n]
        sh = [x for x in shared if n in (x["caller"], x["server"])]
        if env or any(x["env"] for x in sh):
            C.append("    environment:")
            for l in env:
                C.append(f"      {l['var']}: {l['url']}" + ("" if l["env"] else
                                                           "      # works after the code change (system.txt)"))
            for x in sh:
                if x["env"]:
                    C.append(f"      {x['env']}: {x['target']}")
        if deps.get(n):
            C.append("    depends_on:")
            for d in deps[n]:
                C += [f"      {d}:", "        condition: service_healthy"]
        ports = [s["port"] for s in p.servers if s["port"]]
        if ports:
            port = ports[0]
            C += ["    healthcheck:",
                  f"      # is it answering on {port}? (Python is in the image; curl may not be)",
                  f"      test: [\"CMD\", \"python\", \"-c\", \"import socket; socket.create_connection(('127.0.0.1', "
                  f"{port}), 3)\"]",
                  "      interval: 10s", "      timeout: 5s", "      retries: 12", "      start_period: 20s"]
            if n in called:
                C.append(f"    # ports: [\"{port}:{port}\"]   # only to call it from this PC - the others reach it as "
                         f"{n}:{port}")
            else:
                C += ["    ports:", f"      - \"{port}:{port}\"   # PC port : container port - the way in from outside"]
        if sh:
            C.append("    volumes:")
            for x in sh:
                C.append(f"      - ./shared/{x['key']}:{x['target']}   # shared by {x['caller']} and {x['server']} "
                         "(system.txt: CHECK)")
        if p.gpu:
            C += ["    deploy:", "      resources:", "        reservations:", "          devices:",
                  "            - driver: nvidia", "              count: all", "              capabilities: [gpu]"]
        C.append("")
    for port, who in sorted(dbs.items()):
        name, img = DB_PORTS[port]
        if not img:
            continue
        C += [f"  # {name} for {', '.join(who)}, if it should run in this system too (else keep its server's address):",
              "  # db:", f"  #   image: {img}", "  #   restart: unless-stopped",
              "  #   volumes: [\"db-data:/var/lib/postgresql/data\"]   # see SERVICES_GUIDE.md section 3 for each database",
              ""]
    C += ["networks:", "  default:", f"    name: {a.name}_net      # fixed: another compose file can join it (external: true)"]
    if dbs:
        C += ["", "# volumes:", "#   db-data:"]
    with open(os.path.join(a.out, "system.txt"), "w", encoding="utf-8") as fh:
        fh.write(report)
    with open(os.path.join(a.out, "compose.yml"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(C) + "\n")
    print(report, end="")
    print(f"-> {os.path.join(a.out, 'system.txt')}, {os.path.join(a.out, 'compose.yml')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
